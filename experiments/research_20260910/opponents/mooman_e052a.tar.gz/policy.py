"""v51: current-meta capital-flow hybrid.

The 719-step route is an offline proposal prior.  Runtime decisions use only
the public observation to repair drift and control market timing/quantity.
"""

import base64
import json
import sys
import types
import zlib


_V51_BASE_SOURCE = zlib.decompress(base64.b85decode(
(
    'c-'
    'lm}SKG2cvn71Kf5m324C>`v1{D1WqKIGs1B%E2K_sY15=B7$?c@8+<2@dk=+#YkRjpN3{LlaV&!b)c|Ni^t=#hD>1(9i;p8u_T@u'
    '}vXJX5#L|GwR=|9t19hv;<t-~aPJ|MOq}b-'
    'D(A6#w@@znLBQ_vw7|z2Ey=di%YN)4=@ukh!PBfBn~gsbagX4hI6Q3XAQUqW>HJ|9|=4N7L}H-#OfF(ElC#e;>N-'
    '|9p8gq5p#Z>%YIR|7FwyZX&%AX$M^fHN^D1J${akX|pbLp-ua;dz`r`GXBgIsmwIY;0@QRcm92-'
    '{jdLfz38qF%oV^V>fIZ$m(%Xmovy?Rx6Gs!`YErawlOI#r}t1KOC5wbJ!ff970-8H)78*rm(%f5t!=1Ni--'
    'rasGnSgim}WE3C-IQ`r@#d$iaV5N!cFk*xR`u>RrzqN-soTt<v?8JtIY>WwOsBGSjKrXDy7X_ihBJ#BKL6oT`ma`heM*&bKGw3D@'
    '4D(yet?(}A%*6Bc=1ns>7ITh654q}w^0yzLiVJv3eoVTR=k<#m}??fE(f#qv^^KNWelLhZ5I=I@e5YTezL2?alUbq`4}#IIYv`7n'
    'zYwgGB+VLR&2uF}iI_~b<`BboaxCr1S(j752B#e5gQW%4(N=0HN<a(P?8glw67Cbw66FM^lPxcIh)-TrnGb0vBE+)-'
    'S1qocc!T?01V!spS8L)PT%I&%#toNJEPfIYN<4bD-'
    'gFvPeQ*P|PzLL@@#^!^8>N~j-*=j{1{Hlzw2ycbmnk_dzB9nQ{2_IlAR`mLf}{b--l(TPj*hi!h=z{(mzZe9l4#$kDw0cRe16~{N'
    'T@Fb0fzMkeE1nM6YXSlk;?SD`~@`9nIy~N(Lr}qJ)M+WEH#eH{%f=qv#U|x7;zdMk?(^n%WnQ2$a<dU-tcU6}NgY=o-'
    '3LCh{r=cB2ST>pWRPnA-k8718l6K>?4rREzRzk494?Wm>%?2f{-;Q4G(r@H!?|Z>UBRb|mQ}of}*7^N1RdTaiPsS{|FAps)uQb-'
    'f$A=v62>7^Bv}*e`Ln)3-'
    'Ho~DJgd6(BuSC1Ms{86`k?O$H#6yCw5TEifC}_cB?7x=ld7JqSzg^%XZ~oHd?=iV1H6XTY(Nl`vpW&pqI7N$Kj2#A_$w$=s19N@p'
    'PdZ|IiDT(xSpbSHk2PnTl+iovkUM0n9&v^u#-'
    'h5~qw<PR&Bt@s8?U2(P}&^MP6Dt?u2fRVb|$mzc+53Mf$JK75u}24j+GDIoJ>v_(J&y1o0N9bq!9r|@ze|>DXyXs6VM;_WYF21n%'
    '>9)k|_Y%psD$g-aNqayYdgJu@&Jq-'
    'T|@W%6xXFjYEhXpcA}Pf%P5vEq#P6t9meg!*gKT9W9i|jc_#rkN4^+&d$*55`B;5op*NGh$#i#EkbA=uX5S%lqu$)I;|MxFQo-On'
    'TdtG6SIZQP#ax2am#p$;a)sP?c<N%d7cEZ(OK)_GxuQPVvg$`SHX`16x~O;I7as!5x;5MdDc!^9(ovq_s+h-'
    ')6{ROpThy(5VOfcmCA^Q4I5@@nOZy;4%%_yS~)8ZsCs?$`q^U?=hh|%de?>By3E*5TwsK*N}QvbQ(vsr;=X!q|3)o~`Ux5brIp%H'
    '4&}I#Y+w`=7e@jjV6ZVyhYeM}FX{F?&nqnY>h_c0m78k&*?3NNdeVzaDzf1_TLn$xR<^taED&5u6Xo7p50}2g&(0F0+3VMCeO7U7'
    'iqtn_3|XF%dKQ@SB&{3(xS>>fZ|3U}c8#@HtY;ETGhqE6R8;|=`>XA5E9<a(otDyGP?=v5xlaWQc?B==kr~hZTU8x<J6%S%21QTU'
    'ygl`r^Yy2j8U=B3A*;1}j`IdfALg6n*`O5fQ{xw}_z1m`^KVhoetvMm&2+-'
    'xD+C4!OsRy=Ovaz+yRn=4&Bx(9uDyQ$o{#W%QWZd?k31-Ic8DS!FIgxF3DN=sZpI8J4)yZs)q2)vUR-'
    '@xNvF^=i26R54zksuwMj0$ahm88s1idoEnRl^`fg)AbFLfoq^e8fIrk3=UAp=V0(wGKK86LzkZM~Cl-'
    '25K_VL?V`3fMN3M7Rk6=H7%T@o*%6!*L5Y4be5$!VkM;UF_}cuHXO>bzsVe@meEgEJLh7iIqI^2wGtgao)dD%lI{CCJ_VoFlOhen'
    '#%YOP%f+IdJIL>REmAc^m}~Go!iiPFR@e74#*+E~ExbXf5I~9sT(hwmOsNuddsT1G`h=+z-we-'
    'kzYUMfrt>O+<D_=9uuu)+97%eZO+>hdWB*hMN-bqJ=XXlpFg`bGlr#=6jT!tM|@)ISh8q45kgyCXXNGn*D>a4!2c(-'
    '<WEHp_TR!RtF38VGwXMv~Th~X>b+M0C<UI0xoh;TsSUBbE}D6kjZzaLUlMJ3fyK~?yQ}6z>e25!r8ux1+vg_`0|_VgpKLY5C1_8*'
    '59~rf36hlnLEctX@8RP2U5Mh(c<fpl^$tVYxg)Z&qvh8Q)hXGbolAhnXQtMzi1TuA#TyScpUZ?+ZkoR1I+SIez*P#FX^ULf7x>5r'
    '2foI(t8!0YZdSqKjc;R)xK!ac%qMb4!^**W2}B&yNs|6*Z#B8v}+7#B6X~58t`?mJN31#nZLcDi1bx>Fze45n~?och8+;23tW2ab'
    'r1J4W^yDmrk?ExU6WpOvrD!gT#u|Cf?1glUbxwtI@fb{fo&!zPt(m?C>tBp8u)^83a(@&7Xw?0|3M+=`*v}aBzJg!H!nMoKK29Xc'
    '&rR~L*ls89J$An`BLf0+|}&lb2%8xz8BJ3Lj<~~$f6$uYpNaM2Qug2uOVHBg=|+ySIa42wnvOt^Zl3ii(dWyqi)O_ethY#xz7pFQ'
    '&oLULy(^tLvyiy9Mx7h6Q(B8#p6kx-ni;<I|mxnqjY&TNc(+6nrz#eZH+b!tq-(vSIt{z=wPRCgU1Q$;m6{Sfq5(7`n}R7t-'
    '<Vexh>ptyQQ5EEe7-^(NpPyo?O{JAK><J=f8%~-J+7gTFY9w)=mp7S=iiud$EQEP6X~-'
    'rV5n(OYicv+BLMCFK2hJ&}irx5A+WD=IkxZ?kMzzUjmBk@#ShMce2XHn=B^{#<GYKlXUj8)_ir{UKBZC4h23Ml@6Kw>U!PHKd2(r'
    '8Y{b|0LI)tD@4$0eKv;Ui(-'
    '{+&sg4#G6tGkMc(p%e8U+uCjOU=LweUQGDNv9CV`;(C3LH)V%~FS0^0%=41oA#^91J$Ob`mA{&o3kP2@6^B0^!W&OWz8C6U_grj0'
    '0|b#FGML(%yt^E$s!j1v5t9KO0PPv!NjpG?UCX^v;lC|pN7tC~jcuDfTEcvIS!w3R#C59pqi5d1KFO{`Xtl{%$eI@uhGC_6s`?0b'
    '|bsdC^c?V*n3wtg><hTsIRK7XXPkh;4?^M(!78n{9{H6jq8Lp=I+`x~bKk&Mvr^1B09K;JeHEWfAlVsNnRMyK~2!}HMszEn)9#5X'
    '&>zW3_7c%d5Q4=Mw)Eo<FDR1s%tC-'
    'vpSkb8|MG-^(g8+Gq@a64$>tERdmXmY@O-Tvt|`3F^Rv)UD?110;x&4XN_@6FrPoKr4yPFScyNW_^KIjb-El??3pZhG6<*U@epSe'
    'p(eX3ifD8dnsyZqMsyFsH)()iVL)a%PQFgVCeY*KM7D&RFgQ4(jFp!hYp*XQ5zmqokc1ojRzEM^LHv786n-'
    'Yz)1AwNKx2h5aCOV@4J(q2HM<FbP=&52oPU$(E{}dyo^ljUhBcH@5>am~zSF@eA3nLKLa_3GEih=bfAfr(`Oq-IM(vWwL`6cFM5z'
    'MS8`r^7-!a5NV&edvP(^s>o9LjN7RONn((XCd<>!G$-dsElRmTLL#(%@3-0`VKS@q<IU!MP(h?^Htqh&l=m!_PgTXGc3t-'
    'Eo#utp4bdOQ=e2g?N4ayBcA6rERHqeI@~*W!PuDE6>wCbiS9L}kq4buIs(nMlZM1w*UFU<iA5oHBe1dnLVewYFP{Kc`n#QAji$AX'
    '278`eS?mm>pWS3pPT97aG`dp52o!7Si++w@SnEp+$^uRV-;{@RFv-62z0>dB@tCqwiT-'
    '<JD8X~s4YOC3)h7C}nhnGu=Jg&sMo}>3<u%YzHVm8Gwj&@57=qx!tN~$AeWHoO|lcg=#DYPoxAMZp2{SFKE5)Q8oNU#lvTJ%{d5C'
    'CW(uKCpoB=*JUk?N$CvOrg<kVR*sERZ${hES{dTPqX_XLJv=P&O!hP0f-|u5c`r-'
    '_A9g?Q!JsSqJlfP=MOKCLN1K?Q{9E>S~lYZ2FX2RGrC*>W*)<JRb+UOD&CwmuOC=ij6PE%jtR5dTQrewOGf$+;`Mpsm5JUf<3U@t'
    'fq-jMa4n&j7SHWSH;dhC^J}M{o~R)44Gk%8&hOid<>1SeLTJo{(SYSmmx**ziM=NO0tF9gY)*M*J?lFq=JuD?-'
    'Lz+>}Utg76Ga=xIcV8&}xCLZf2`S$Qtnmy>9ORpjtz^JF1V1qthleB>AoglUieegQwqScAxG5YA<&I(XiygH|QE+G93<%ORC%i5u'
    'x7@3Fo6~%95N(^MNQvB+nJPxU?UTpwT@|>%~5nGVZ7MnF&^<M7i^_DK|$#9TX&8sPH-'
    'N%KxAq`s=lw);M2hZ!5VL3&hQ6zlz{~;J=U4GOo%COWFig7_T@W`M9JNb3e{^8?C-'
    'FInXO*)7wr#7l&7wD2&}VUKP$@+tu#jzCx~!q`o1a*I$I{ZN5%N;Tt8JTcW*r*f>&#JSrp2-i^;%F4L9ydPj;@*G-'
    'yG&0gC_Prwl*gbqOXLE)8A<v4pHV5zy9+pm=JQEY4lEk3xzpZ)NP%$WJ~=WVg5cX)TU%M7`>=KYdj>&_HsP^W2q#PJ}u^Hv>6<4c'
    't+_EqjdhZiots**MUDs!VxQT^6&<D9;;O2k?J>nH$*q`usUue7+3Ewyh)OSJw$@jPii@#7q#UU#X8PeQxpN2Av{VBryt@ig-'
    '|+~=aUb6UlZen73waYbvE?P#R9s0H01FLFIX9fz&eZ})MZsS_KKj;qx4SlKr#^ex<J#M*#M=X!n_1_)buGACU+E633esM03~x65('
    '0dexGBc^Su){Z>v{a%0w6+-g>ktMrCvD}4?$@vqGlZ<81P4@ypmz26-%^op8uFAg*D_`o8=>oamkk9FUKd)AG!-'
    '0w{~tBG7XXZj5P;N*IKf98cQ@Z|@u#^O9*Tvl0kx{!SFQZ+hYwKOR#^Gcy!2dTOL4@!}z^RDX2z@i%Mv~sWAD{@VzxVl3#f1Opm;'
    '<{Jz(t|n5Ko_1|@`Z_-{xG#SAWvFr7qh0NVsNh9vAW%n7tCO`y`x3hpygYwmRc38$qPTPagm;BXyulQ<}rJ_O*f@Y4f?=-'
    'O@ZgIidNmzQ)-Tf^FQI)6t5h%zz4ljr}`}JiuMt2g2tf1-aq-'
    '!B~E^W@Z>Rhq0PRA6#4oUZ5aa9S%eotJ1)wbN>*agmfa_&cxkt~R8=tC<V3gZmRAt2pu+;K{DT7NSjo1V$R{v#CnDsBE@+P_VD!@'
    'QXLBD4fFO=nkL3CRS~}y&sqZD*&%^E|<ehBRi#)8P`lfMMktXh5K|s2JlY}beNrE5uK?$}NUE`Oo*l|gZr-oBl_8zyZyk>X9>OL4'
    'Eji__99p^4qM|?05PZ%VQL1gKc#--8y=>Tuuvj~f2rX@}$Ti9ebRZH>+t~6#s4`OBJd|k;t?e5L8Q2qx6OM6cC-bB3L9h%grUBYf'
    '0XH?u^W=fRv!rp~r=6-$F`T$^I?{kw%9r?W2BJ<j~Pw&AB(h<NzwPQ8w-'
    'nBgY+7dCm&jzDGZ^kbb=+7>Spd4>uUR9CkI;cUbU2+8Fs)3EyTr#?B!98kV8gcN6VIA6C2Iek(4jr#`E*;Gr_8VKm##tdV``3^qm'
    'gxJi!tiKOMIglaLEK|6uauYJVkb`En}~8Zr_{nO#Wadl0RIdu6s%mTx41C=3UDE4^NRt$f+%XUkGQuo;LI3MKg{{k?($tcSvNlV5'
    'U%i4@uNI@z0#+v{(z9JKDid;`z)$S7~&K4OWC<T)8VL_P5^CLaOUr2dnVpRNg}+RdOy6IeMu6S+^$2GU3G!i<vD&xaycLRgG1J6)'
    'Jug2+#fkG^8kypC0m<3f84vPYdi4R)KM^mH2Yi$I`#XjI$A7=Mg%@6zx$FG&l?~eVnuUiv?EsoPTRt7maf9Cx{*elu~~#fv;G;22'
    'kLtRO7oj?donh{tt+L%*D3#0?1C;#T5HBIrWNvjKegk1!?l(9<T?|?LaEe=i6@&k*}gGQR5|GReCsr%Yvd($z%h!DvUf@sjP|$TS'
    'f&85&}}f#(45zStXQY|J2s6Sep5O!3L*Jv79dArfKZ@xSV5Dhi%y`sJ@RLL?@-'
    'ue8?>n5<C6X5To+<RjyqL}_}hVTQ#`iNI{(;DDR((e#_xypu0TPFv}xqzMV-gjk*%A>T`uFaOb;q-92e>;GEC-'
    '=1ewD2t9c7MdQ6ZPZ8Yt1J0FlD@QzwGw=%l)<K!SeOH9(QF98s+dR@bA<?@LGm&)$~*#~9dxYasq&JzdZL3WY4mzAi|5%F#g{Edp'
    '8^%6a9wDe8$ub$=gJ-yekG(gi^4bZMn^Qr#WG)bp;wtrBU?L6bf_DjvqGkDo|d4R=a?Snr3u{7!JGradSB=3+znAQ>a(<@Pm70<<'
    '&Hy%rlQl>w!WA!>(@2FKiv5Kg4ZdEpoa=Uq5k%c`^v4p|@gR+bBh2A?{{JT;Ytv5GXj!WC8lmX^4y|<y}<^Eu%^pGRApl86}Klxv'
    'd&ZYDN2pJwmSNMr}fh=ECY@kv?tRa)7Ml%1>EH$;<GLf#){Kw5I@S;g(ZKgV39hvt+u-Le5yN~l&)5KSzK?uW-'
    'd<BeS6Q4F1Eis?asx^svLBH}`mfRqQwUAm(Yi~NAgb&2~oq_QRx!g}H^U)a@bkgWGIsh{>+izow-'
    ')fK3$}zTA?8~36^+^b8_;9K+-tjK(g)nu*@^6%sWvm88_NxH4H4cSiz^ZGzK5Vuvy?fB>kUcrqCt6WVi>Ka^m<^=;-'
    'uS2$9kYzvo;`*0Q%OwVy@0mQ3%K*@?$<hc<MdJ3-$J$N4`ncq@A!-0k1e4+K(qV#*o~{^`E@*Z*jgnx#;=dza9>rlHKfLHMS$Qw-'
    '7T5tdSBJAa-$4kw`-%Nd?oAk&kLDvEc5qkXXAX?VO7-U$~ahyFL@3&nkkaJi(<`scJ4hF+a-'
    'RjaF|vgv*fIvt>w<ND@`Kn4Hg+(|9{C}-MLpIYh5O{m8jlusv66KpfZryha<hcB^h6?MasT5)*0HF(LI&n#>lh7E)Dcm-'
    '>KyFNEYH0*?(5pqmGW+4=lLHMIZe%e*i@*kzh4wy-t4_Rt4v;+ZQ}tz|b=-'
    '5O}gQ9!0tdTnl|WZ7}2Zp?L7n=<ztwqvC&#%xKcfD0**#ZpmeA^&E5P4R%^(>o8zZp>I5i8@DSps%vgruEKUv?EJaXRb|}PTTrVR'
    '0$bJDq8n-6xHGeJIVfXO0P;;KxF5isJT>Tb49w5h>2Q>r)&Z($7zwcCc~e3p)`-'
    '$}1(Q|@i_S4Jh><=vYId#}odMBLBXHBT1zu{klRO!$(w7F622JC$?!y!y6aFW-'
    '9Th^g%AfJ0<$#yL2Cug>bG{K;JNP+kU)@)0Y_1>cG|h%@ds!j(pDRfk%ur1h-'
    'PufYmmT#7wSB#J?t@;5jqYcY@qgiV>Qskf2FwxjHeMf3Rm9ESa+<QCnQfOx47Rf7JGRBIO1G`SI4xY6eonlmt44(>JIjqTZSR5ek'
    'v^%bclv5o908xTDq}eAOgfcI@iaBj^*^XieGWq}K0Jd=5!=NUy%%FCTJN8)#x&T4dz<YpPX~|01(qJ|Z^5S8eXE+MJIMa8?m}GME'
    '(h)7hMi>%-'
    'RT2F!9R2Ac@C|6CT8S|%M%RPWxWXy)ps@(H}1tSCFwO_*t%>1{SS@5H)6zPufJ@(`stRJZDnb(NvGL9Hj+<E>6|!ejjZ-'
    'g2|#ujRT##fk7x9rz2HSgOS3UxsjWIvD~;E%4%Tk5JQImsS;juT(fW<MLnv}k6bK7cJ{4ci>tGNysZJT(4%91A#IW*Xk<7cDObPo'
    'Cy1Z4Yz4<7!?~M|r^?}cFdE;&~qCI_F?^BY;S*<{<Xtv?JnPe)g1>Pg-KY3T$4LBNTBJ(neUD$&r>&4~u9KE*n%g3MJ!+D-'
    'eMsd*AC08u;@2?@fANAit8Q(MVU!CY9$ore-N+<j|#jHz{c1p{Myo*+JhsoypTU}lNE{i83x?L+P{coL*9WfwbY-'
    '@HeqxLwgvY@h?Z)Su)dW*;7#yxzA0R1>-d!sR+CMG#roomSY{vs8%`atq^AQ!59b72%hF?BsW^^x-'
    '0eekl{N>U?0H$R+eU3bMUFCx}UpH!;!8UZ-H-'
    '*&bW|A@aQRLjF*L0z=KLM>SSF6v~iAc0vqUM<Cs@0){k_?=xcVDs;xxrdX7TC9G&vlYFC^M&i(!nYO=oMX3M&?v#IlwlXG4%Eb<Q'
    '~ZywR9_>jClwE^3V%Hbt`b!iV{s`8Rj+3>+~41r{`dTU@8du@_tW_V2C-'
    'Jid&?(3b>?&81Pdeiw(8!`*sAncQm3#4?jSHOCJ$$Hf8o`B7_1-'
    'nAT36XBU%|flm$j|cxxGb6)2+B#mQ$(oPPBrq?WV?oux$d>C3jiXqiD(?teqs`682gmr{2|WY;U^>RMNV;?d~8&w0I;jB&wBE$6R'
    'MfC}7lRxeZq9KN6VXyoKk>!YUdb=NLe!RHCqpTvyl0hb3vx^IN6iPkP7lSbtmE4ER*gJ(^c-'
    'm$kUS3A4UcKtela`F^9A^r9>3xLG8{Y&#TM8$V6igR0$<>TVz=GMR*?kKO=xn8C-'
    'o5HjNDVCONmxkl3GNJ}G;sP0;_o|C!t)t_ol>8ui+wzAcPxMjRgUY!3vR|KmeY6SiUS9jHiOi3l*BK1KLAtdIWh1G8bpoFd;ATe@'
    'vkv!e@WQUDVf;bK$>RJBmq9A*pzZPBK9<V;WV8{i_g%$vm^^Lv(wrKJt&6s4-B5qF$x?7^b~+Hb=7t-'
    '3xPYFZU<#it)G9ee@~R|C<u5&K<?T4T2=RU(O~7lFOTyWV(UHd!@O&mXCxDn2!Y9`lD}jeL%S$k=3JH?{EiikXw#YELV~v~9lW@x'
    'Z21vWSDv<5RB>WPvp1=<adyEZ!70LQeVKOmOT0X_Ndf`@DvCoM~jdNs6!JoHV+xEuLv1GaO(D<_Z>XJf-'
    'm)k&Z{U_fE$iN)y<x>%}8wcci)5gzF`BubG=oH`nEI(hi+@-y8m(d)-'
    'ixvSOUEZmisoozYc=>jOutcg)?BZvb@L)y3E(h&4@yk0aJ>D${tFOk&5IYWeshLby<Kg9<WqPb0XVLK^#>zRq6xko+C6b_h7I3_d'
    '3(;^YcOOMY`H)d1@bT|ax;B@{raa@FX%<b8uS^FD*i-K-ZWC{#bGo`ITOZxK{^tEQqoyLxPoCvav%o{*SJSnua91$~-'
    'A}VV9Guto!Xct+_6f5-'
    'g!%oJv!;(_bb|$WIFcHJc6;7aMnlE;#AZ_~roWNH_L#!SXWjzIa%?PGqxVq^SXUTwCp%o!jy$Awi_K|5x%2&s0{gUYELP#8KSPg_'
    'V~jT^jTIH^(T6HSxV~<fU!&ph!jtNS1$cFEnlkApzjQ`FK3~?5EpTH^udu%vH0ImcCpsn|jBMzYUx@kwmtY~bn4Z_q3p8IC&`=Y1'
    '$0?(pu#SljLa6h$%Sx5K%6)$3RNM1KK~O#m6GXTL0dQsVvEN&6Qw6*C!;<43P4k!KXc5~_=LH#Dq$N-'
    'KSZs^~?*f6<`XoLt8{OyhtIPf(cOTqHE!ZjHSz~`I(yzmN&1;9=vwvAQ;ig_h>W5+Lgid&5z}#aWRoO!{k&O)#R9Krigo6bbeJ?h'
    'Rii-'
    '`}#mok8Lv${*&`BgvkC#54QvaZimvTrzp=Lao`v4X9AUL9cH_>{_Kpx`$((0}O?O;V7rG2h&Ug<>5ZQd<YC(7K`cg;}XyJWZ}8#6'
    '9$bu%xGxhZzIc2?eDHy~cycrSi_wPSN3z6Il}XB!9iOti*TPb4S<V8QvJ4W2rBsI*1@^ogn+@Ccq;Jz++_q04q-'
    '91NkY4%9pKpEj5Bpt#Q)<>(G2WJ{ihFV9JcPyA&>yV3dw6<t_qgYnxfl5wC_g(^XD$u1wj2_R6QP!$z^#b;4}e^W0*pTYJT4S>&`'
    '$^fF6KRyRO`$~(;Yo}L_(vzd*cVRU{sOO(8g9dE1Q>ETo4~J}RuurL?KkA<RBe$ErCaZ4G&He5P86BJLoX8i&^S&`!e)g>;)m{oP'
    'Pyd+!2HaMnP2zj#m3I{jXwj4Hc8&7&*SPHo=GKYRMTu!*W?E`J#`Qy4^CU5b&)6EK5tUA+;?9_~w#=g|n!c&RdJCKD>G)Vay;V*='
    'oR_x!YxP<#Ps{1>FOiUs>zvA|_r7N|79Pvzi^(FOb*>t5vm$>#?KSkaf%UVXw2Uq@oVK6arBfi(+wSw8j#P(Oj$nQSX}834(;YiL'
    'H|qF972qbfsGJw4Bh8`1A8VFR*KDetfbL~}@dYPpUtDY4e+KFGw3wHccMc*;HoU>BI3YH1kTtGl?KEFl`<MuTQ&nlD0+SRwb3<EE'
    'a6M{PuOC0SK4l18V$Y&e$1XqKj#KH&9v6k|N^KYi*zko513|pDob(}!g^)lM*V`9IiqZ2uE)*8~LmQegL$6eXyQjKGmNQ=?CB4&{'
    '82eLVpAQ4_5t2rml~|k-a#?Oe%U_q(WQ*o|gvJ~x@rl<><?F+^k9B&ySRA9hX>mB-HVR!`@Aa}(9m0#pi7ehWdSuLPztA>=Q}SIh'
    'M{Cucf~&ckh!7=p<VQ&?R(KxUq|e8%sCuA`?cs#+%?Z_ZtF<SSu=?TeFe;x&s8GaZa_T;Zr_F4@kGc5d8rfCb_0+8NHQ42LznO2v'
    'o)+kRM;m<@w2sX#lZ?^dV%(|gOtzP4+UrZ6&I<r{n(CVd(v3&zo}?<4lmBk-SoOv`rkXvaS)xa)PuXep1NiQ?qF{*Mt@eG{e~-'
    '7XYA(9ozy}6&KdQT#X%il)3-'
    'e<c+IUM`NrukVx$?_3zT{YacK;OJ`)O7hrl)4|pnnY8+3!Z!xXh~&O(iT#>iz3#1T*WsHM}pY!v4niBkg6B#zH?Bl0~1(JYjp7NQ'
    '^foz%VYirroiKVC})65}q_82M>H{$*&OMP;o!E4&I>MUwhV(YLQaCaBN%jt~{{=?GezEnFTamY0?jgsV6%R+C6r+{nd*IeQeYL*A'
    ';#KxqPV?XZ`l!spWe4_SEOaI;k=wbtA52&(t$$`SGGfqp`4Kg>Up87vV%*OPfz0g<6X8WeWlz?yKEQ*6PUf5e`JL94*ugD)rD^{D'
    'J!0rZsrk=wmqoTR*pP7)aRm)54GCtFScv?tX1~cC!TpmDF)iNo{3eXU%q+4)Or<(fli_J6&kB9=^fAJ|Kq_KIt^J@yU_|jV@9=aB'
    ';DsPwLJs2xr^BERJ6<Pofv=wwYke>yTgY#f5NK{5AHWtINi(yD*DX*i^`jIbF&t2pi|)f?MA{liRA%>X5Jy%`xB@bUU;d6?V#+Jx'
    'yVv=K))c5c9zqJne$q-}GOF)Gqq(952U}Lq5fWAI$Axai>XV@rpz|Gj2dO7#nNWI8xo_^mMLJBW)S1sLBK^Lu^-'
    'puC1gkk545at#sOh`*n{qr1U@`7aiOBnnFMRAW5R@gL|tkI@gl)ZcKl1<0Cbhg>`$@!^m*4zi>R}2iJ18t&E~U;I{H;fA7ZlV9}`'
    'r*A=_y;pE65idA-*FcEi;LohFHR#7EMG1^@OWAw!~l`9bmewnUTxEq3>P3)`<$g23+>Q{;kj-}5(sD5KGd7a`NuW514-'
    ')c<IzwLGJY*+Z!qf=Dy!tQB_!1&3_=Yb}*wpXKOa$~2$0C0r2dq#-8nqr(lcZ^>U0R#D>Kg}la>Tw75{HZ7y>z`M-'
    'M{*^fRi@Q|)Tq<@>fP*Uly%49yPei=I*HWnQZnryC7v*4ahF%@V<IYD7g^q>SJI&{W^o8%Q2jXaffnF_u5WIK+`l*FcX}F8T{3C?'
    '3W6`)H!riLaPbY~S>sn{D)@Z4a#oTCEg?&UE>aPFQSZ~;`I@q3j5u4>>1kZZgXg4K^a-'
    'e&at*aqXm75q(K48_N>a;huQhTux_rN{b>pvjS^*x78N%wZR_S<?<_NY^uhDAKVqDoIes$%~=q`xldTUu;**)+X3RnA+fA0GXD|E'
    'uoHAwrXWw?-}VKD7G?k2kLST`-5Lmxdj+A%0zqMsF-kC$K0TVqfD?5-*@j6WTSzsV*dhW<pZ0MD?z=%~}7-'
    'LG`TPovsd)lV~UJiR)F?n!??d!qqcZr62ZWakekRS+j0)YJMndo?sB*YMDs{3?Zwa|@VywZWR5Mp&mZd|sBT-'
    '7*6AfOC<tlR^<>sndHKIv2T-VQ<S5*L$G{Z-UpRZn7V!0<OGg7*^$+N@cg14e#+E!SDFtx{8osqb|mTG!sm@O9ABi_jA41JG$c)-'
    '10-'
    'pT#RPXB4_S1dbhVp)>~wKa>o~6xX=V2>r3Ib9iaQpiki2cU8hf4=r_{kycKb2aPMds*M&bb>gGV<OpzOH;4a8v2a$fc#N|MqA2tw'
    'mtB!M`+HX``e0N5Y@HOm-'
    '&7wk#pDOweeaR}F`1+hYJWpqLr=Z8%=2NN9;gC5>?XtOh&!0WW*`$*blr@s57+BDy_u}kpGFN{6EV8~i%n$55Z&lNUqef~ETyFfB'
    '(N9kdMUE_Vnt6HV<YdPg(FLV=#`1k+>=#pRV*&<E&XWOghfeI^PbSTW$y|U{Rd}uaCw(~YjMl7NF$Z#W@`MN4hc5X!{)D#|<2=L$'
    'ukLV`*wbFimsXL04$^)o*^7&%)#Y$A4iDRsGdmFWRnN_D(D-'
    'X;E8yA$t@$m8+E^(zOvWasJzC|GAxtnYc}COt(ets62srfVoJnY(9nFVT<~V8#7O%k-d^Ekzt>`l>-'
    'oQ}^Q6JIU)9xVJ#j_$xsB8W&ZA~CCjCBv*eIyovv993D&%=zIxJMjH(~7n(Sy%JHEr8o%+pCRNt#(IQ7ZRBQ6!RPA_O;n#H%Lm^f'
    'VFmIap?bswbFVe>k`xk0t}~JgdJ=18r(|g1|AS-sa9=0r+ZnY3yvDD_LT?bkA%1G8gQU=RvYlqW}n=8f79!1IT2kT_l*uLqy6Z6a'
    'Mkst=BL$^Lw{R*`WW((8=gT|Qy=UosrqI9%r*0insZf2PZNVK7(+cTv~T+pTP)vE`4Kk?93K^gb-'
    '<dFTJvr9p_Umt$X5GLR(m+<+^=r;xF7|;5dVeAQt^zw??7Hkk?wK6-h`icyE|T|=`K-'
    'dtg+fQF0DG=b77Fb?PaV|tgyng*c_Ddw^><j*M1;B%5TjzhS)es$5_Ag`D`CuS8w&B-'
    'J7w{`%kTf0Zv<1bsV#eomLtK;XU1HM}HBGXUNScRM*?TssO1Ko{iN^f;wdJgOPG#Nz{tE`*?C)F9yRe3#ZoyXF#l)Xf|ORM&2nno'
    '>kO^<eZ{sttZwkep9FLJvjA{!sup=ECnwXcYhj4zfr!`5Zz`?I`2!fw2lf5U$aTs=FMY91WvEBRsw?VImROG=Df_e#Q&F^o?no+c'
    'd;mZwC$`pCc3}frJ<M00m$YH^IG95@qwM)tE7leUj4b*<EPbi1DcVuMTPt<Ki5YzK*kf`8-'
    'XRHF}>JENAS^bQhwiVXJO?v@MZOvs(WZ_McIpHNMd7DkeTK3J}hH~LgeKNzoANpW28{lUC1c6+uLnSyR`D-'
    'vfO1+o3tFTc=+sjbZ1YB5BQWfo0SPa8(2nfZ|wWXVYI}Z`Y)ymNQFEz14*dKWw2m8taSM{TUQw{X4&Bgz-n;Y)>c^tQ;6Ujd-'
    '%^Tn4T3Lh{sSm(Cu+z_KxSRg0ofbTwI8-'
    '<bCw>MYuf(&VCoOrz@uED4nDWpQ#JOSuofMU<LK!$JF#R&rI_X7GpMhHMayW*wRFR)Jb&sHMm^Uy{SPFkDOov&37ij4fc`?w+dfQ'
    'WKT9iqI%QaY_{NoYQ{aEvQA($vTrp+>^Kkyw;e7NiZoK|j?uB_wA5n)#XL9ga|nK#!@qVdaUKR~ci|=@e>obGk5*hPCjHYJ1nxE1'
    '$G3p=Cq=W0*wo&NW^G}rzKD7tb6P0P)w0Q^17^3Fo(Jt>hu%SYrmx~j<!NqD0Si?t&f(l?RBx3lLxj+SAJ*P|LOvD$(%F|ju&hp<'
    '3mTW)G_NG}9e&ecp!vp#i5^s5t<CN+b$T>3XgJ#EN_cIXPV=L(MXuZ}q(j&z?XK#c?fBAN?R#O`UYt7pWm2sB%ZY+_r_c4Tk83Fr'
    '$(FC!F55DyP`_Au;ti70q&=6efMTdpT_T!3sKOcO#h<_vOW+Bm2u$KdaP?wJ=MP#OY~DJinAfi#k%4h(pG+`$*y;?QtY4sT9{8Q+'
    'TJsgcYBwUBo(MI-Nj<HMkG|>crqFf8&)~G&j>K<ls6mCW3e#HNSy+5whzwNa(Tj$+3s5M{d(oLCyoJRSn0-'
    '_K%m1z#QT?j`E(fRujr3)5hZ0m6rWtBJ`DF>&J2hMB3=JCXSw_zKRn&OerBWQf$>MC;9t~5gJ&NpS<FA@}YlI{<dznuXux<qe=u7'
    'zhP12wCaIRi2J$~Oi)QZjIq?Yvkgw%#}mJ)5I_AK3`L+M#sFpNCOpG_@d&Q9+BIS-ucl}s;=sbMk4<7nP=c3cfx1}b5iB7Iu8dm('
    'nKjmb%-t0Uj5T~xI=z&n$jc{tF-'
    '<Km!y6SPw(8;QfNNtJI?Sa^t1Gk9pr$8$S?N$MoX5!6`Bi_Kv;YW2=Vbg2U+c~~vSg;$R%ybV82xueqAedLGl0nMjkZJOQn8JR5A'
    'jose{a^Xig(Af|4m_PQQxO=x2N*7$WMmMGGwzJD?mgDfzT~d@<g(~CnstG#Myy0YBYFY12w6CWD18i;x^gx)A^*#cg<K~f>^Mjto'
    '%@FV7%S+(|KmE5`Ui`KcZ+22HFMC(;)SpkgR3G^(93P|UT_$r!rFd+wUX%h)0v_=hVrgz>)^WNTpo61}T)T8@#Z>H1_3G(~2XL6Z'
    'D_5EMekA4{a1L{~x_?v?ij?_8Au7k?R4z33$9XOE!N0r=lY<Vcw)|;ND3$i==lmSj)nK}d%z5}JWm92nopaj?+DB%Kk8TkBiLa{o'
    'I2g}Yt5XH~_xom7<@xOxk94$G*?R1HT8!Sac2~LV4_)8fV88xYTI&-=MKNg);h0z5Qd`q}Vkwq2hV;^>C0y%Q4LEJnrG3*8+-'
    '5!}5}T0B3u^|8NjLe*EN<6=FU+|yI?SjY!<;eRF@Sv|CFgf5`6S2Qk2&-'
    '3Q!CMr_NE<hByPTpUJ}T|n|7a=t(HLgl?J25D^^%wcjBCd`*tVSfrTCd7es+mqPoTV;?)XN=x*l3p-'
    '~ND=Q8fvAbnju&}rO6@WF3Y`@MdtG{$*#(BZE}JspP8dhiskP8c{(Oq<edonB6B;dRK9Z@Zl+S9M(*zGVAxr~aOP3?I+7RzUaTOW'
    'e9lUiO_!O|RXE9x*nBxp7Y~^@cuus%k(*nO|5q$&QE1gjMRZJrM7suW^F~3cYV_Cu&Z{Y$=L@ccUGG*Fvn?5ij*W(_gEdcdg{rvi'
    'zER*c7_s;^^KKIwTGD59{^y+~%A?_7z&Y>A@X8+c|>~Fqa|lv|L#{LmhKm2YNVH8)pu!TXiO7q<bj`)ff;*<3IP_`Ff0Guz66$v`'
    '|uamUnh8PA3}^J@4bXymC#Q+><-'
    'y%fXv%Dds7I^@8N|k24R%<K0Ao4a=QBp8>h^lr=H^T!(i+elyr`(%t!Zy?w6#o~Q&%6J?sFbwMJ-pmJhH&g8ZwQ)3$~$UYZ8_Kp@'
    'HA0%E$3l$hRK_wR<O3lrY#Q}W54&YwAd3vA4j5?MvW#8QIa(b}W9v2mZ&(xzdDv5``7R9X9xw@0%ahOjtNh1zvqj3)_P#8Qe0#!p'
    'UZEDr3HcuQPn#YAYu3VMfJVNe&eff7&CfiJh|2&s`xEKB2DBgCO@#KM`lGF?8=LIze6`-^R-'
    'Z#~FUFtN=fFnupDV*r6d2hlEu1Jexk99ReI;Vk=0sWBS+Ly^q*if!aSCalOiF|7Mp%v0xX(-'
    '%~9%r|UaY&C`y;sjJWZPTFtr3GFjc3H_^QAYq41;I!6iM~2I-'
    'nAFde++R$L@RVkRJ9WTQ2R4!lVEGdmQsB5Ho%nDf{}1GFh9|vywPlH0sO#A`(7#$>z-'
    'M^Sp}JKzAf7zRfSl7Q_e=7K`Qs#WaP29>Au;z36DgB(nN!j<mlHSLjd&Iv6b|IOoU3OVg<1W9B}T(qpl3BEpmPbzys*91cs<a8TS'
    'vzW=C<57pstSBL2iJ;W;?L|9J4TyK8$*1W0G-Hn-z_)7Nlfk($|_kO(`Kt2Rkt4n?mrpuc-'
    '5n4j!UOd!H=3u_M+xLJSm+b1M)bxPcX!z;$*Ks1=>W8ALfviI3lG%wWQzEEEXGgCVM)Yijr9dl2|8!w}YxdlhOU;{u7%qV!y8PTh'
    'p_nhc{k;|T!Ah2}E$i0Z-'
    'PbHYXp6NMSlo>4Vb>3Zo`lUH)n?(0cvi<%3fPNymDG>r1Ci$YQiYb_P0HKMk4)d0lD{kG&U8K;)N9_eu{oce1iO1S)si>5JpSB{?'
    'p<4_@L+3B5S|8_tx!`Hpbr*xX9%uQ{oqadw<V`8^j^QTcnn7NxU#m{tcm=sh_BlWrw+4c2Yc;5y6o`w{L)!c;KkUhym}rBPZefg;'
    'z@VDVY4|}nQOM)Xkb^HLq}Sdd%`y<>-'
    'T;0c`g8*((&9s7ABPEmqy%$bya1YNcoSmZwFVuF*z>JtM+v14}wtJs(o}{9~XC8q^I1B4Mc>%W?iq%Y=&?0NEG-'
    '+Z;ZdLBj_zX&O0Fbqw)T1uvu0jRgaZz1hClPKDv&WLV2^9gCaJul|K$MSz3*?<z@YcL|l7iYLON3qxk7@I5LD!X&pn>7w+&#`h9c'
    '|dypZXCR|6=^my{7+`>KEkd5JOtRt6jq*nDs+3p<q-U1(eJP4ZEpF$=eKg!sd6hpWWZoWz^Z!Ehu<KK>zijTVq-`Vv364-'
    '7PNZYAw1?5=-R!p#jZ?JYb>ZiJ12KQk_#@kf>VV%{rP_@ZcQXdw)q~!IdoRmq`eVN9Fad-'
    '884Yu&uoM#sqw65^0H6W*OW8@uG{_)uU3JGTDZ1Hi>a_hTeztFI~+j!}IZ+W_D0_`^w51Fw`<ma9tTYK)MRiw1gFX9b;VX&-'
    'bK~~ghiDYGyU~!_T+l&2oaBh8SofuYOb*R?ENCF+|P?Jwlxx|wB9hAnWDTO=asD7U1q`)hDD=ZhE^Z91I@>Mb`Jm-aN^<3|a%Rx)'
    '*&N*as2GWYS!l|!&b5OiG>9W6P{>oQ(^_N9Mj!C;x4neMDZ9JJDQVI|K=b3s|hkUfuI+W|h^^_Us!W0@uQG==WL((PL;rhGU$3Sl'
    'J_tjmXPxNhF*%tQgg+xW}Gv3zc9Rj)L`mE{2jbEYR{zgu>tXWXa)Z*`I%0Ml+v_03((Ti${GYS)=)9luDv!{7<vCC)QUwQS;+!F7'
    '^=6bptE|QR^hY=bl+A{N=-7Jr>*I5O25>JjbyTSbyH5=~P18LQxUN7e-'
    'wXIU<ojN!ic=q5mCZC1<<$;t5&mhNDeS4bA2rd}J>7f4ArqE9V*cec|*_$_(SvqNWmc19AFomt4Q~h?t3vaYZ?1r$Ztm0R}TTVA4'
    'jlhdlv*x)}b!-o4*FJ2He~njo&&9#?r2unI)8<a>-'
    '^W#&V<1N`M<uD;5!J@do;BWsa9!J)wKBR%v3qB8yonDepDMX{>bhFiX_aNepr|fPuRW02axKyWm~(t+{I$K4zQEtxLshT-bqlnq^'
    '#(1DN7_V+s$kpa-|7d5nw>i^Xg_A%_<fkR-<e@-'
    '<cvDEjR`yr#;~Z~j?=Zh?Q((k6?s0;7}Cm=MJKs2>8Z;nZ1hYS5+64Rg3edqm+$>6Dis2KEBIFSa<c<tDwEDssdpOBrhk3_UN^No'
    '%N=^048@kwGNAbxT{*(1g@Qt~XlYhP#bI3wB#Mt-'
    'b=Kt>@aBWDjl2Jcs4H7imRW+&Vz`7t7$Jfvfq)8vY~qf30mvqxhzlZu`s`=Eh@=1YI5S9hRcBUZWuq_0FSeYdbX_;UG(5iP#z5!@'
    'aO@zH+Y8EzJ^FaM)V$dmKc7`)dl=R9i<xwU9Q|>bhOTx@LEp(qkzF9=kGYP^K(U};oe9?(3WGAQqv`o%-H6`V^3MB8@6ds(<dFQ-'
    '%H0gindf<eth^TWx|`dNv-CPo+zbC8&f^Zg$!=>ea@8-S{1KPJQoJI1b<@pdJ8%DS_krNwkX_Q<oj~d|6poY-'
    'q<D4o3@iN67$TBWYKj=WQ@P5ziu9P1v2qo?UpP;RE7Fk<O)!z@HtE34ZtW;DXzeF&-'
    'FYE=?;aBv#kYK~89$TvL3XdN8#{MY9ogNCO2c(t1SOZ`;t6GoT*F@!`_E;|-'
    'wbwbxqIz3gR^tmG>c|`H<?`1D9O0nVES$y><5{N4fES1v4@-'
    'rNP~i5%vwrFLCS38v?ziL>42kxZKx=>_q4c!hDEpBxactN#q&8z?qJ=RT$WTdpW%G?9MVPn;`YNl=lKK11v0T*5Jhl0?ZZX?OUFK'
    '?-B6g#6vGn>-VPg=x&t!c?B}B+V3mvy$))c}OG!0`86>INBH?eJW*cuk02BXE-'
    '(@Ha*qW2x6deZA;Y_WtRZ{G}4)Ab`f<UkE5=4x@hr9grDhkLDLlA&(zg~Al-He}aEb|KC#4S`-'
    'y|KM+`2|7no$Zm%<2#ldLL#dctlsUr^oK#XGEUljw>`DGdCM`EBX$|TYD1Ch9?*ETUuVeF?x5G(=Qi42c0huM`6a)a#Soa%D|XRB'
    'c}mx^<g}P7>ub50AWd_6e`xFDj=nTK5&qfo2v8eth7gT5fulNlFta=0fX53pqA{VSCF<dUznaFOtTT)BS8T<z=hPM3TSm5~wV|&@'
    '?Ud)yLIo6HqPdtS#f{zCQ-FiBdJ=t{saz`?#~OCI+MR^u2)yZV&*E&%_QzK71#olmJVRAKLN4lWUi@7!rb!mL!TFV~<Mz;oPHJHf'
    'N0zS$$31~PYXa!4*8qMh)KZ8@f^C!^=YdwJofoFr>Y>QAIv5<6zv=iXkq#WJ@es$n<ur?V%Yt5S9}1xcRSCtC2{5JUSf8!cXX$E8'
    ';i?0#*uw2Kt?%VV_y9hcwy=vU#=KVjZFdMV&x0_0gI;MWy@oTH-'
    '2aL|<*{?P)Bfy9t*Kgk8|!{3X^MyXj}rc9p3B%Mus1E%o$HdNGsms{9CbW#z}`@|h@&-'
    'eH}x*#`{q<I&%Lwn@;Sk8`|M_;vi0zsszv~$tN;Hi%$%IEq#!XhV0V4yf;rn}==mqwJk27S1?@RV)458S6yK_D;3_qA_@37s$`6@'
    '85P&2;kjiu3f}wnw+_w7YH7i`u6Y-Lz(Y6S8s?%58gTT!ccDd2Apg_1gV~+MV2`W~j-'
    '1$yG$gBBubzA30Z@IldZC@tG8)v_t%rxN*EAKh&7hk9Llx6q)gah}qgRV>4QhS@!(P-'
    'nNjUP@tP^s41rR1)`q+T$lRqwnE!ZBz@hwa75Mh~&sdU)HM@~7!zt#&$$u&fDv(IcA^Zc`f8Y3EM2U>8HafAS2Bp&OCVT_LLa!vc'
    'KltSZMOq-yQ``brJ$9`cT`b3A^RU$M7)oF4QnI}2c~a~*Kybu-3FPlWxQ@gO-kUvEPQR;Hb&kXNUr&!@N?><Wu83~mGGsU45bF<6'
    'GEu5Yd5f<GKEzbL(oz1CMcJ=BNnPJc9j@0V@Aye2NONF^fw(Kn)lSDa11<Q%@Ef?bKkB0#|KnfzAv(<>Y|md99pm?+l5tWPMK6t`'
    'cLd}<oLMAFw5O~0eRjN^n)0{2coN+ND}X_VgW=4-'
    'bI5ous<2XXniIgg2fR~#qZP4zdylH+2#S&kbusac!~E$+@PMwNxQWANG1I5*^|DC5;}%M7^Jy4-'
    'W4&4)7W2u2!4ZK?Io<O>pkQ=6=&LZF@liT^QAiLUb7%ei={6prAm+F`KuRyXqcfn8F9KFRItmSy(Wf?8Qn*ZD8qN*GgRCct7#*y='
    '{D0ZGBob4T8HAD=5#t&YxnrgC<DVC8}4gER^+a(GjfsKtiDGQVtY<q25u9-'
    'DENs*$o{$wpB=+7JJ<+9kJ&*i6tr*8A1N9<X?AA!NaQL~7n4Pqlgou_O%6SAXm{$`_MO%UDYv@HR;?`SO#qox|Q{^a$s-'
    ');KCgA7N(~TkYB!lUF5XAIc<*$Jgn$UJmxl?)pS(&tYO;cSE*o*TZ3ROfV`Sgcr~OZzTUqu9IVcD5V$G8YJy(?4e%Y?jmKG>#)sR'
    'gzNP-P+v~`<x(-'
    'UQgtY{u<Vs8t%R$ul*S7~u;L|s_s*qv;c`>hCbh9{;F)fTW32%*wRk!3xYaj(H1?};vANx2Gs4+k8$uy+%96}U(`Qitj)-'
    '<0Uk?MDtVH7r+2&Vx)(NsCUjm)OC}&M<PLJDh?E)I7U7Ud`(L6KcXofYDCRF_l%jJW6s)*kc%@dOmiGj;q3mic5wN{%)ujEte*-'
    'W9><;R7V=F+uEi3c3jyBPHGVRB{eUg|77e`f5$rBY4&$}ZXl?Bl$*^NBufRkYez+t2K-'
    'eLPuV_LWj8tx_+LmFD0jyxYuBiDO6qJB3AVRxPj7wqK}k^CLMw^mTtkcj4*cmwPmk3eQ8qd5k(Rm$Z80%FxM(r+t#O(XyQpNNK{a'
    'Aw+IBL#d4lOKaaOASdxPtaMJ{LJIob;zQsGd#m2YqtK)uFYo*k!HJ%q3imLWL`UXZOXct9<~32b_TXKx%6|(*h8gXKq0R8!JH_Bi'
    'R<N@59=_%CRb!%o=@o8-'
    'RyDP0k6%46aw!CMCv#P6Ptz%}zoGD%5Rf?8q@xz#ZXJWW4i3L&jqJ<KZm(SFYsu+X98HtZ+E(ojJ7D3i;<hCUk4blQ-IUD4;f72D'
    ')7y4Z5#Sd${urY8iRi8v9fENFJiD{D93?$zf)Sm47A^4=%+-'
    'XM37pDTXExA(%HCwZb2<4o$S>R|sVD2HGA=&k#vJ#d@p=3d>{{+YXL8o<btR1djbrageKor6LEMuL6o<E#fPe4$$4ppo=V~!OWZP'
    '#2uO18C>gaIHcTf<`)XDXEEc!P}D%7O7=Y7tt41<eDKz<cVwKO+!y!iYDS*tY+cf^Lo#t-'
    'q*aWZc@)M&CS0gzqY_MA#SM)Af)Z1uq_KTb-QWq9A{DLzJFD+Rn6wEIicBU0&A&30>*^nN3ycaEk?Ro|pR?o2%V1fVPPN^i3JFs$'
    '9X(7;l%m1-PZMO?kkM@K?nTFBz^{cS*rscPku2_pkLWF2kRDMM75XW1Aa>{_!^G6^<WET-KXR=l<t?a4h+0oeq0b9QQ`ZWd1A1i4'
    'pN7Tf|y?MrQ1o8%jJLOSLqzN}Ysr?vUktBD=6^iX}MX5^Z>r_D+cjHdfu=X88W0J$EUZ4Xko!fd&DOd?{iV<#n3-'
    'j!#cYDP7#`fwZ5+D$KeMxMXoKfXWNO&7LxkgFOc4+^Z^j_zMO9t%1pVeg=_{R0TixfgYMF4KM+5^x7dhRW?SLjIsT`W)TS<<1bi^'
    'm8b)KVe4obWVHtoR!VZP*47l;H+a*i{%4LY??#9O%d3;^a%KkMD4F9oh2C>-'
    'aVyW!{x1xlvX#<qdK%IeyjM<Z{Y&Ci$u|P4!A?#q|x6;FPflzXH2U|KqQ(xRM-'
    '8L)G1Z#sJGb_?_6+$qS4v?6v@t@!Nv*s+oy#)vj)hqd3~}QUq{?ob@J|lyJN1WBWSl+%?!2~Dk{_e3&>DExBDOf-'
    '6+3=z7DAKy0oUfFg(V1AAA68|L^TNzKkTd&iNBE&|Ge}t~=~2g&@TvL;Sp6%pUDbw$Cxz$fVKjaw2sI&bS%lix@YNqt(=^1(~YNs'
    'tn}hF}R%j!LE$SE#bb6MEoI;@~l>4pbNIj&h4coRM4DH#lomxHQi3J)jhqzZ!6}Gl7eWmNgdyZgmptOad5FN{j!5CwCu8@M?otLN'
    '>`1uJGfDRG*|0iUPCWGKOJvgAQN|s__v|AdL&UanGq$DxaM|L=OZr}qX#0X-'
    'rU=F0Vocb*3a6x&H><V44@Yx=Q`7~snb<hF61+#duUwd&otNJhG@4%_`F$d+@u5^h3&Z~z~s@X><fvqy!QxWGkgD9z1WMZe26Yw2'
    '&-^=e{NnD)T=gyMq>9&qlW1gYgAtx-5<hbfBeHCz9b4lbt%$ZOG@rUk{-M#sfyJ~W3?bQMd;)|^0wZt5oj6P_WcG}_-'
    'QAbj*7gEWa*wxiL5QVq8!_(s%Lg{II6u)=uN-*?g^=)gDsCOg3oC=4K`X8I|+>=)4m68nit`K8xqF)Wgx4nbSN4t;!2+V0Ic-'
    '=8EJj>cww*6Ki7Ip<JJb~X@cfM848H|Tt3tyJb%^t&;8+$s>0g|`3#?N`zKSTcI2uN_#f@sE#gLneeP`Y#c<KfkOvp2_2{O2nwp1'
    'VB=ifZ-'
    '1}yW_MuEDGiTnM$U5)Y;87pRF*jT@?I(Vq*VB?$Yk<^LTt?Q0RKYds)ZQ)aI(+a#ZFglhI3<;^i74#n?dfcDRbJX+hh!k$GyMO`P'
    '3%WmI#(w1|DY|CFN)tE3?@>;a;<qYrt@;7P3?so-3jL3)XPe1*YbFw*A{Fy-OZrV@)1w>OpA&bKOx)%;+rsiz6Omoi2{F_=k>U``'
    '^v30Dw&&tP<TEQPS~(&^Xp!)>%O&dt)(){WuZ1bt|uY0mEbB!*C(L=SjIS>ti)-'
    'MW)H&Ijf@KilyA1!D%8Lw<PB9x)hf%vHko=a<1@?K)_Pf2c44mr#5&AF7tmzd-'
    '&bl{P%AZyso&FL#~SVC!Q~JrSaV*ESt1&3cUiwXy#vL_UO68O;79%P3F6w(kXUF|a0(X0BPy2N+N0SNh}v5#Bp5=owfocUlA(ClP'
    'bu;(psKa~$gMNj#gl+Ph|T|3%d+=QxYJq~lCR1&@IZ-Bxj9Z|k%g|h*FmA_k^%iuwoT=3zUf0ehLc(8fQ2I!Zcqnj=Y)H1fRC)SF'
    'T_6BN(1gnzpJB47!2}ljb8?bFVdu}cGHUI(J)z~{d=LctxN|)j(_u<Q8X-mkqr)Ss(saqL%M^U`;y;*qiuSK1-5-Eo{hW^Jx-'
    'O=tf4MVOf6Q2*CO(8dRv2S5c+Lzm%Rb`mA5;8feeM+U{i>vTdX)+Pc5t(pGT{Q=$ExdUino7dY5Wp+gR}XUY^~Nc}qgwt$oZdo_b'
    'pnc4<lMM&*9>eFyN}9~XHq&VMu@wJ13h&?k9|@quKKFYm_e<Ht1}AxrPoD>Yk)Kab#9nc*DmtbcV0`n;g$HItrZGh8Z6T2fR^Z(X'
    'BjxSbl^;!r{3%;hNE3a5dxZ}IRFv+RClwPdC3R+c;IXu}qoGg8SFhaQhN2p+}KAE3h~CMN|-'
    '?BMt37ygoUHLes~v=!Cb@GZ0+gNl(QcTkAl_Yz=hhH5xt>AIF~r<42Wy^P(VA7gPc9`6=|u&*py>*=*O95|~qXAN^#f$!;N-'
    'I%nVzccyGuRpbSw9|X%m-'
    'WP#5ybU|tx^N|<=diE3xOP)Y8<r3N0Sn?>ni#m8|#QL=4K*bnP=n;H}B<1B~ATk^oK=Tv|a^WGmnw=Y%g^9gY=w;fohv?e*!HqI2'
    'j>*bo|^tmch9?yK`R+`@VxsuQ##b!TEDo9Wr5m%vhCpa2_uh$`@xXeK470#PKGk%wuC6+s&$Sa9b<%ewFWyQE@#lyr50!noa?F(H'
    'T}-RW?`o+>+np`-h)pl%jqmEf01J?{9OveqxG-'
    '&FqNPwd$T1=lKFVlPPlO3R?(owr;(5B`w?(wbIOj9=a9rPosHNiCX2zytE#*jUkPDQ~GGXATEA`0)$i0pNy5A-}!t`-'
    'GS<ur<jL6T4hqoB%#1<%$Hnqm5%Sjjl~@nZ-phii+tlgcrc9*T09Q-<=3{+-0!l#^Y+SMliA$ZlvQp=)ez-uZkv||f6<9z$d1OQL'
    'X>*nwc?sD5`_qAn6CkY?QMUp_2sZ({5z}s_JxC!=S98ys&wokdbir68^sRlW%=R{9$3ui@osJveL;)qD+RKh7pq77)EZIKzUpk#^'
    'Ptb|@%y^$?pHnbZkBC;1+n>A-F}Crj3ei%joqi-?Poh_DnH~I2^lLzW_{4woT=7rW<VEp1tHq@Cqk~}L|*j!@J{oPWpZ7vmc0w-'
    'v5$Wy4cfN6yv*N^*P0xLgV{y@WBpeIdEBkK-o^i*U67-6yP~7g6ade^uUy$I8bf7|8{#Tke`e3-'
    '*qMac8m|p&Y_18?J(sP0Td9xwWMN@!?j?cUz()CnB`G+A2_4ZJ<Oy#U2JtV=$mtOwR?C87PVxcOn@=-wk-'
    'c4xAHCGu)?Po`0{cXv@^Wh5O4i~MHgz7E4yoqm^m7Owaj2(J_-YQ?)bK*QOY5z+&Z6u9@A%ELw%OEf{nfF_UXlj7;!zS^#dX;~LC'
    'qt`@;7{L0^7W1zd&SIiSoZ7G)Kwm_EYqhKPl8D{Bv`h4a<71YzPvg-EPCF303(;5!pSPt960eEHh896bX`8)jMo&Xpi=<!xQ}NmL'
    ';`mT#mg<&l9$*Bcz`F_7PxTr$g+v=HgPjUgKYNC+N1uz1HlCOi^cDf#KckBamenS#DKc)(nq5g*z4+PywV0z3KLlSyoHbz-wN~@|'
    'L{speJXaGKG9FA4flB<#Iz7NPVKLORgkkZex8*9yin6c^Zi7@>Z&^-'
    'FnFeL`@aTefNp}gcsNNGiZ;mi;O(Zy<S?X_~|uB02PR5om{NFhW0|}8mmKAtMma$RR(PSBW+F*qRd_*+psJGY%Dh$(|LX^8)&b&+'
    'S-'
    'Qqi5}Ud@FY#NwkYp)?$N7FlFj7JOfNk1#=P4=${yp%A6(kWjbWvlk4J|#a?SnebGV#69#yIK^|ZSUw%U<oIudGB?X9ze2XNeVXl1'
    '5x%U*&v_vI3gz1NG*{*JXr7C3E68(YUhvKu2hTyQoek#EHVtX|u6fvP`wQUUvu$GzvZ_|wLKw8d7m^oD=@b4{&H2E(j*{VbK)?2o'
    '}M>?=JzGAmSYy~?MhRFcC?<cjC8>|^1UC98|mR@p(L?Fm^~*vTn=-'
    'j_wpWTSlc94X_kH@+o|M#NFuEWnU&OD%fzV$fxm9l4cKUwjEOrk_*S1ncqL`Vz@c^MOsw4<qbq`4{<lf4qSBcw|4L4)OQyaP7yv;'
    'a(WSOkn|MkiDCr`t06{b*^2f<8+evY}OR_(fkM$Ue=`U!yzUCjkXxEjqEtOH@ZpMTNCW1K90Qx!gRDkgE_0EETEf<?!~u<tMjAtZ'
    'JNln>6ytXR;=#UP+1*yU<=#WM7_DG+%<Pdh?1Z7+`^7ntnY8kOk=vR`=yx6L9W@o3y=fSBeECWu6h>;HN?#l;t1DdX)V=1#GfN?V'
    'T;azxpyNr-BziWmAGkG$5W90bekvZp}ZSSYP>6~`QKLbE<UZnqGGWOfGItyzC!L;wKk?|5`TNQQMPkHj?@x?B<Vw-0BPJ0Bv-'
    '<5a{0OF^~8BT%UZmWcw&VOO4FMb@_7CJ$%cVdA5J3nSnkfgT)6?tInb*&yV-aG%p$r&mUQ$$mCoy9T`u{h*G0QAs~!OF*r2`iDrS'
    'o*w>YN=BEX<jycl~9Rjfw|VpN|lFEqbB`gMLrh97&|KXO}$AG1As?+kn=!E?TQ5Ns*DO#f(@!yd+^^J%(#v7Z4EGLPPKm+r`EK`9'
    'FJ^{e{8II%v=xP!Wx+HwWJFPQ=$7En>+Rbl=UZNKq=YTW5zZqU{1k_UWIZLFdFdhpO@#N_eG9<QL1+(02l#Ls^0AQa!ETSv?keo#'
    'mjKfP1=v|I*Q6{p~sHV@iH+XDNPYLK-UHs~>f<N0TRN(2b~nh1naYZ!&Fm%+N5Mq917QgV5`wx!mqg-'
    'y#UBS4P=E9LS8oD8bvB^wAL9oj^dl-'
    'U}o+}rEMZdi(WcXXzhHvqRd>{T4!!v`(UjZI^*qE_GLr#syBOXQ+|xg^B?C0_717ZgGNNOG4b-'
    'S>+*#xsqyRaE*5$*hf^KwEi@aJCFq7w2fvLCayfkRO4w#@44!+h&?kcD})*YS9V6+?NK69s1oA`@Ilirxz>i3&rU=YM+`sVPM5%h'
    'W3JCoOStGMAdKQ8rLj&U}-)3)cvq}iOS`@36fH*1;-}Z@apPfJE3V_A%9LCTsdQBh1TRO?zQ)1ROMg$tN>Fv2ey>|`m=!-'
    'ot%`@g^zm&@v&N6C1bc~&9|AHE0zBAu_Mo#&1KSiH@imk=%#-'
    '<<TWd5yay+h=((aNQMsp>$ZC5xTf%srWH!B31{|5ZywP&I?tSeg*)Rp2Kcv?qNGz>}zBO#cqS%0F!SK=RO*et0paum-'
    '7ZzmR$M4z|PVL%6@Ou1WcJOO0(6E=M2LEBMeDA!67RLrSEK^Gzj7Noq?2VycOe+R^CYOa923;qXZ6GE6^oLzXQy2#n@!;f&)zHDF'
    'AinI;yk!_|Pc0vp^La(4a%gA1PmKDzy9UAb>q~Fcc%*}!?OmJ$)W{dsFf|D-)F#0Bp4@?7Z{yY05mC47wRHZ-'
    '&ids)Yp}63guPZiUB~GM>@M11wYR*qfYArJC@RU2MRF@rnadSczgSMAgwFTt;P%*YCcaVUtNvJ?u9!!-'
    '&?}D`$}e!W(MHKzpWsE{MS9Ji4UzC-vR~DNX)obcm(SW64$hSO3=`cl$=G<g^vEQb?jUC5ZueUb8O%Kv<C{JB$U(XhXhPvMarU+1'
    'QOjs2l&^jcrm73wmg^#ZRYE@nJAY?N59!I^v(mkCl?T1KQo8+G@r5>h)igYw`T5OQAZA4}&b0zk_?8LOPU$&Kj)FRS#XUo=#hXl-'
    'H(+eYyeFkXCx@u&Vf(plHeOICLij}q#o1+nw~l^))$TU7CxC{Q&`8gLA=SQ(u3lJl@bq@w#C4vL<C0GHci-'
    '^`1Wk$Q$iD#u950K}pz3z9k|R|d^mtN^S8yj&vt3dfK2}E^V5%ZX4xHTPghTI9cBs~sDT*k|U*GM4+K-'
    'bWACyiMe7J~FOHo*v=O5JQyFI#@gMM!7%@uNudZXN?eO54n%HIQo*oJ0Dv^3#rq)BeB%wII(F?7jPWo6w@`?SN>+JNuyi=ggAgtD'
    '{!%)8{r0d1xGgYI^gLV%CD?zbheX?m5?<`EdSMj2~|*o(EXaXsS`K7>5;(x*TJ{Pa4}Xku48(zw$^a4w}P;Q6-'
    '1Unv<*B`bn^sYp((;yY?}3)A2SW)}<Yuo8PZQU~!sNh+sOH>`VFZP1XsKm>Qg^Vt&d^ip5M#qGP(<DRxyI1zNpe|}=c<W?I=#|qL'
    'LmpVs`y7Nf2r?Bp=s_z<IjVsie^LFX}#L5fEnU0YKwRtkYA6Q%JJduC6Qb`%|;O4Q-D7yBrSkK12%i!dhD@^%h0M-'
    '7@><pW2)6nK&xtDuHD8Ta()KMh5W9Vmhcs)Jp*?K5x$3Q+HGa?o@eFtkT3)K2OQkfyYR`1rt+38PY>t6c6`$^6>p4l*)@(&Uho!k'
    '7J?k2P|l8_HJ*vzJfN7cBb0hSF#q>4hGMibB`J8d?CrH;D^Xi$@x_Zl3-'
    ')Or#3)3vr_oY%!H^ALzToEoH~+qF6Ao5kkw#aoBwx1xn*I&>&X%j8Y8M%6=SFqWd}bdV+M=HR_5O~xk=6qwBhv`F@FqK^e<Bm_y8'
    '&y+z}nEb`rAF2jjmmHVM`1^SkhXe9hJ5rm>mAjwfn14Mg>i4ywFgBgHVG%y?-Lh-'
    'Z9!rKSCM+MbpeilJj#DA#KbNK^d>8xZlPz{(d1l)B>2s*|M91AOr-!X35@N8tjA6F((C&}3Iu-'
    '~0DYPW3HLNWb_ctM25@pbs_qAxocEr*enc2!2C_SpNdz%R9R9jo>S3l)etFw~rYn;|Oef;~e4~=-'
    'DHR*6=yVHtMrgZD{N7thO?3Gp9`6XLduVJNetyx`O_o6zyEo^=^UNsjp@cPt`W1AK#$Su8W9Un}wLb-'
    'n7iWA^OJ`mXRUI&3HMo4obU+7}0K-FlH6ztyE?>p;dEq|TJl-l0w-'
    '#&tV*Q1cz@Q65GM>?3CM(b?~{Td4p1U6xOj`1u!udKV{#OljEj1kw`)3XZ5yb9|X28!Lzpt{=a{_rDceP|Ut?V57Zn20WOv?I;C#'
    ';>x}4<=KLx~)Wq_#*{T{I{(Je;|ba-a>-5vNv>CsQty#+OFNe)E~Vp)xFWUc3@c+K5BA#*{-'
    '(ZQ!DSh1_N17@rZKICHmYcfyh<IUx!Okx~0xCjIMwMhjZ&_A2rl#EZ97lognY4HS3Y@HZnJB)k|Ee1sM7O*|htSIUwHA=1fWb)jq'
    '7J{v4=uRXg7g3LJWpovaZRXYru)yjdE0z?7yxnLKZ2iLI)4i3a9ERo_T#vx>9LruEa@Q2kfST}cmFT$L)_g*~!*t-'
    'tJzek4#c>@_275Y0lOBEPR;tZ;SX$4D4u^m=`_OThCL-g^tyTubTc7%3m^6a^EUS#4%sd(+9vof*;qzC}gIyE;NX0Y9yINO-'
    '(#bhIL|+*OHXaoWAS<)nFA_4pG!+a69Vciwo1-e)xE#S@Oal;y&ZimIa<Wdyy_aOj?!D70ub?q1f7a#OZIn;ZS5^RKXV-'
    '>D<PfYy?Q<@Gx5M>)qHIeqV5)!S&r=0ZRmtfCO_0<GQKaqPI?YA!xZfP`Q`%3iUu@%PSu!qNdfd*AwYsi02nVPy|<bND&lrY8<4L'
    '`zVs9*>98s9ssb5O_CAaXo9ky+00ZKk?#9o@J<n&W;)!!>AGrySZrpC?H<hH4gh)Hw}j1sz0PAQ@d}Eu2tPEqRR2G>?j-'
    'kqbDn>_ID1tr$Mm2Om(JRJ}lzqAJUdO2G3?PutmU2v^+96-'
    'v*ZO_|u)<@Ad|QuafnR^f2C#sIuziW1gxj=0bqrUU}yCC+p)b#haDlTPa|-'
    'nNgdE&+Q=P7_?s}v*U^hYr`3V>r(Lv@b>$9?*O9N`FyPENOF8?K{tYmS9YViGV#9h#pDlLU;sWHUts%wJFuod$UyPb2h5zcDksF8'
    'uaK9D^1!)w*dG8``^kE5>+2eky3w22wTjlWh<>76+gvA&d7}`=!&lhwTv$?MUFj+1HdK*sR>dE3ZQKRPgQHw1^Y2s1bGezDr6wU}'
    '>nkZ9YVM=g|67PwpKnx*;<tB#sLkqWn_NZzdcmvDqx-gGK`^u8YO=vxsm7z~`>x#e`^VbuCHWAaQPFFst_TQ()3vPEc(K|7V5w@`'
    'M4D$m+m%kxjjko(Bp+Uf3|=WSQ=T#3A5z#K*tfWl+35Cm@ARJ^6e`RDk~#iCp><<;F9D}RL^R=OZ=U)zNsJB`XM4T}3(<#awA6&R'
    'loDk~H9^q+*yKjPoQ%wbUO_tCufs4JMW=W5CL+#s4my`shIfB8$Q+ZDCAKpo7au>t>QKEjsAb#ir0I6FdS=%<+tdi&US_?C)oqq{'
    'iJPgM?E%ppz3#*#5*L(?$Ft6{Bvr$71){=p!QSFUUb7!uN7qi5hx{`QeRG}8PGow}W51m)<4$V#q*<Xke`C_>e7WEBXQ?qPYsfqD'
    'i{q#?#@{a7;6)lOC+Mmz-l9$f&PFKenqt^^5o&E@ZysUbvzIP*+R-'
    '}w9ibqfvsz~R44KSy;Hii!wrYgkmN5a7`?MhKn7=%|CHqwHioEc?JjAY;h|R8lIE<M+1)cWPdmS_fPfYu9IH2;B)r$`vl9KcM<Fs'
    '?-'
    's0?>=m_nq^b>PDswm`cB&!QU!=7JgqhlNwIZtl)kHLwzuetHCL`l@bqepS)(=9yQ5=BS$jwiK+(WNJ9HoZ9z$<pKXa*(NEO4P^_J'
    'RdegQ3nBHImn&<FeXllH<xTJeYWa`voVy_UkSkpZ1E!r7x^%k*Z9TvVp1Wb@{84d+-'
    'uxZyxMq#Oh@@N*hqOX%tA#!Q;MEnWpN5^$AMk3ovLMs=$3Btb$1LT&Rs@8s4{~GuJ4SY(4-'
    'nI$UgzDUKqVU)Q;BidDUypU*E{ZlI&qwWpVuj{@qR^Qrh-x+GE5KSX={o~94p31x}TbzM&)C4K)<zIhmLyI*5DCC7h#C<wyNR-'
    '0v(fS03XWFVSHi{>Juc8sT{mmJ0#&+e`X>2Qpi`~sW6@I?K7>{yn{4ndJAq%nF_7CMrm2v;RXDmc1XH*<g~dg4?}aG^dC>1md@Bg'
    '%|~2-Yg}u&dJAN-qTO<~t3NI?bo@FFlDIZoY0IXKpALaNc!I|FN-'
    'x}KtI*(;^fddlm6iE45vR}@OJ)m{H&F5~iL?szZ1N;+@BmCU0l(iLj4KB-'
    '(z^Q_MLC`oty`1(j}{4T+_SqM#rVO1i?zaPju~u@>iIe!4L>vkoEKr?jutK}pt~S?Y{o(B)@9JkY%KT-zogrj#rW7o4PxD<0IWYs'
    '4{xdOt%$FUy8*Y&;_<vGMeA$3-x@BqUCt|B@JFDW>r?qobQ^NtH5bNYQyHe3*{?U-'
    '9_E*Z4hW@;RB2rZG@NzS*%%GIeq~d8uKMd)IR0Jyv8~kdDYPLUCfS_E)5crOq4`g40(Caq<LmJd^xX>pDhSWD^>*W?&$#v2ug0Pr'
    'NSNy!ZO@tTg?MaG=k>>-$yv?rZ6lU`U#IBAD6AiMEqnwb1>V#sF$*NCQbu2HUk7Ne{6=AN(`n>KHdNDHVb#Wsx5-'
    '{9yaL`&MjVgRK_$%fxm}%CpUfYYHLn{IFuSeFv3dO!xmt($en?~a`V14D2~WIhvsnfSJ3)Bs`&#Xe8Gs4DH=c1h_d<6z%qOLTus7'
    'JcwW5cnJb7%~5j<50q0}4OIDI|=(gmU`?Db9j24qGXVomh~=^c|u8LPl0N9OLWwDZB7hABS_xtnB@YkxaV>)O#QWUIPn7~a@Kt;z'
    '$E?;e-b#idNO<NX^N84KC27_4=-HaKE3xR?X;`}ymDXCE!>q*$<7Mt0M|VapIPDI2!$-'
    '~tUZ1KZZS`egs<SVGk4$fXx{0EJKR0XNMLU&5wq)HM1yZO$c`2zw)8%l0d8rO$(Db~l>A5yn>C?^!x1vLzA%(X&aHZ*iyknDkm$<'
    'zf%SeP=w~<Jll6J?^|#{JjSt>c|n^dYXF}xOWZ*mrRz}k&LP3`+x*!rS@pXNHFOb#i71D^fO-'
    'e2FSUhb#`p)4?pzJ(X=I(dF0{b`+O$NR-'
    ')CF{uO;5@AclQp<Yw{dUl!JlRRzikS(x|9&@hO=`$V7x+3G|D}$e6;5Ok}CoF98C(2lQ^U`K$Q5wWr@$!^=w{4p(%AV!+M&p**Iu'
    'sqe64dsa;K$b1m6;xs!bEOHvyZ&;o@J75uJ~yEIJ!r24EgZ9igjP*TEG-'
    'K@or|aGxI+q=!g<@A#=F5|AEy%$S@@$N~*w@ClRjCL;Iuc$$i{Kj`8BvY(ImoeXv*f?yw(itl9gw`xp5(XsD+<L!^iOS+zi;+IJ('
    'VofL|*{es_jO~K9J$@$dhgyMKzC>+3QW9wJ+X+=8HIak4NQ3)KETT>DpEtXHar{~^z-~oB}xl>-'
    'ka?zfCE5Voiwphy7oknw_PAFyv)7icZ>(9mRA$X0)@j+`eFO_xnQ#$=K2CQ{iAD^tVpn;V@id|W!+tf*|Z0g$O#-'
    '(b4*TssFs8R7Yi|u0=+mD~?bmlCnQU5W=(@oCQsSdTjE!c5<1b02<69mUakbom<Dz@Idxf-wjaC(a}1Qk}NQ!d^8=HwKAOzNN=cI'
    '|V)c%<Cn%o8D*@HQE2DGK9-'
    'DM%GlS2=7RRb1OQGF64D<}2~k`uXpr6sm^vEELHSVldq{$Fw6tW=h<{m~|qC=<^l&wffEyZ)^j+wta={KBm<rTN-UY;R?tmf&NN~'
    'YYx2nEwp~4r)xR)I+d0X>a1~Nl)XD-O?|npAD>3^F++!klVtqC(H38@p8K-'
    'N05UF5AnnnwKfhHytB_yY743sOi8Wt=fZ41}Q@T(~Sme3-'
    '`2bmM7|HM5R!yXXWWlr>omDlr7N4v+d+d}1+McF<aju~|v0pyH1h^k!;~V9imnZ3YL$AlB4sf>@PZcl~zX9_!bE{@ywH7q|CT<an'
    'iq_@t1093=DNV|{S=+jU$I%Qy$<rRIyEPZB!?h`I4@!B0b-'
    'O!^8}|8@+uS{1vA1tIjn6`hkomRyNiTIT5r58pt@pl@o|Z}Jyq=}!bfc7BHGmiacEzi$EYISoxpNQb#s^jGR$2(bzLM-'
    'j;9WulD<1{L!TA+-'
    '9CG(k8cnS_4XsUUDikdR2W5}Bk=TTD&7a4#popBb`gF%}_emBL$pl}5Pu~Gub%CmT_EQyMTw>p+B4*Ex=j4TGL<pHVbG0V*KGpe9'
    '68NM0vkU@yH11W;^4u})8(y4Va&iJ{4eClF_e~O7GCWO3)}*4(*ZxrQ(WL_}C(hHK(~AU9^XYK(>MN7joj`J@qZ1y+hwURg(<5<q'
    'LwoC}2W-B9g3_BrBC1QjbAg7bV&jF>Q?>PkI*migyI3e^)MX86`y3`#nfJt9rDxyZz}95kQ`7-'
    'fnNc!F;9Yf|mG^6@FWNJVaf&`62_E8cm#gwCkY8^&aARbCn(TyE+L;DN^v-'
    '@hF0FH*04^Mik*B>mwWx{HL*wFo`f5;rm!?0)Ym<^}{T+En0HhvLbzWwlYn_~DX9m4IE4?a0G|R-'
    '~VJrq+IXu0>V`X?=I5*_NBV8ws+Q}ZTY}qb;y_dzpgnFQ(4xLp8mCDbT+<xvy6W=f{dvg)L+7o93g~xOSP{QAeqM{y`m0m*}{^hX'
    'y!d1W~F^(o@-z4V)*`59RWJ9mCqc*u6hutUPM6cU%8sqr2nJbzd-'
    'PyTQv<9C6bG;FMtFRtVXW4SsisCnYvmC30PPdosXUG|>sQ)T0S=oyBjZK#~H&r3NAelrE4yNx~4b{3gnpd-'
    'cRAD|oga?H>VL`t?2=o%sp#>WJ=QT24qVE)j-$!`8ZL1o)oY;p-aQ={FRonzK+?<xL!tX-HBCe^^Q7N<O2_SX0k!^p{u|}Qp`i5_'
    'd``tUbsqCP=bZVOf%9_^$l!8yK^nKR3q+K@?Es#2$V(U0uc-'
    '&Ikbo%I<N2Mf<vSDiBLY!0(C6%^~HG=}z&nJR~k~MhVar!i!kyz<CnGF2ws%+nlGh)0wbTycrHnu>lU%dSIVh3O~>|FGRlrzYlwF'
    '#3uT0UAzMpQSOG#_C2w+pvm8;2&TyD#!;*UCossEqu9fl}Yw&rBe0wcPV=yn49GCB{GlT}iq`(d#GnX&B05iiY2^S~RfE;Udr|sM'
    '8vlQ*ta^5DKZ4ik-xIR#Yi!1j~G+RQGEI^@7uppLCv&+k3KFojVk3o>w_ROX=OHnDa^y6(S@A|M)M#H)Xe4(Icbtf?wZnWp|mGsx'
    'bm;@$22EsGa*+)ry7BkHFy#ZR1@H96R0d##t2#OGqW|<S<)rv*@+Tj#=bx#V5?&p7V{5`VoS_=%PIzUCzO05s6+h)`8c=-'
    'FRkkc+d$5;*QW32WF*1)@h1|)h7PZfc2tIr@Q#Z3&8wiS?Q;7+)hO0+9Mz3vU{1)!LtU%vm^}J1~xtgPlsmrg3*Cr_$TG&TV0wPI'
    'Jmsyp1v{qO-'
    'O5FcJ4nWVK93Qm<C8*t6xcUeFnBruVkS06FX8&TJJF#h)<F6LiY64iyL3dpGGvhSvlN1Hu^eVISY=aPIgD6OM=>bJsH?9s7qZ<Xc'
    'Km=xM}~c6Dowv*_E;*<*bnkqjulU2Qb+6d3<(52RDWfavN30D^lu#bA47_l^xVy81_}NaPX$IUmR>hP{r|0oGSy|9Oxf>Xrp6;X0'
    'VH6pdGcN^7o>sN#^Yz0oXe=rf<=YVwM<8S8B4RMEf!CQ!RU56tEGVZ;(NAa?o%^Pbv>aDfO5)lHUSh-'
    '>P2ZM#W~CiE)g|2R>I=r1*D?tGz;h=^m4Q`VG}xW4_%k8Mvsfz}x9OGJP~A*Co5*-'
    'qro`4@Q)YX`xU&u$`HFQ=rvrqMB3CQM*#r&W?AkHc{uum7=0KAlXnc%h9IbQ>{@0Ud~f&mc#P$d&{mm6HU16ctF3EpPKufF&+Rv^'
    '7F8)k?J&-&U4*}p%Y_lve8&RJE}d$2FqqPeT3|IYjkpAP76nY99->be<Sy^{(0heyvZ0vpI2nG++@1<IqkX5u{3N&7}=F-'
    '0<dl~EsOcqfy+TrTwtMNp~?$tmhJ=-)UAQ}JOkqMrrhaTrI4J2w|3HUuhiDv77ra8`^>-'
    'APyRBUt=MXD*`&%F+|^Y!bj3w=3lxcNid}9^L!Z_!-iG<o!tLF1!`{@ahz%iRU(nntPEJ|gGujX2I2^J_DOtGH)ns)T-'
    'CZ2M>ob$1^9e!iu8nCYDZ71hNIdBBV)ulG<=ScUj9SHYLhlyG)L#vQVPbtPQRHr6kO%wI-5-'
    '#~t^VEs5*K$o%c2L1gX^zG_PE%^K6rOA?`c)neH-'
    '1`<S^>*b{oKiZiOIY_d}d>dd3O3%|&keJ2?oobRwA6LAAsiU$ZZFZ_*+_7F4k8^ZO8O<z=xV#8-{iXranG#aCN)L34!-'
    '1WSDR)aYgnZ%U;YukYDoJg9EH{{5-'
    'oJ+duMxp0DZl5xo`40oOCGL0+<ZTGi8w@|Vd6WNHRm2X7fubPd)Ea>hk!SQ$i`{(yPE>6Ju)GhpWQ>N|n0Dld%+(30je|D>Pd<>|'
    'QhG(z!UTmt{w+pbtJ$>nM7vbVz-DjI*=&qySmbUAS4Zc|}Z8H(d!1lJc<AE!5=WZmuVAKDq3+nEij9w`VZDX+x9>jASbSvxn9dxt'
    'mp|3V<?%sCM<6!ZC`-'
    'x?^ZyPzLuq6ql;U9mZHhR?X&g)y3I`8|^OrJ#X^U~eCRdu_IVjEEAzpi9s*I^~o@ARSuFZDUG>p=dF?g(6Iu*Q*c_^1pO1zIbi0s'
    'f&g4PQ=%;=dW3P$-lu9KE<j{B@=SGYVx2#{M$)-'
    'iPA6YAMV9eZzo*i@U6S{n2u+F|CwJe$40*OQh7jVw(fEMZe;L0q~SR&gI=zJTvt{dOh^XE#_Z?M>XTyeRH|MKNdQJuRwc_^H?y9I'
    '!3LwXqEL6y}y0N=~4S3>vcaHH4)|JFT+K;O0BmgVQ_!aFgkrPu^ef)wtEoHKXoWO)gORKp3BGHt}H>Z_nCb1Q#grBJIrca!4{HN?'
    '$B>~HnNK4hCeuG$ay-'
    'S0K?~P@v_a<MOwGy6m!k+cV+PHBR!|gu~vGI(Al%pZ9?7W(=Q3rSy1uB)f>LhC8Fkl(WgHO+;dYsZM!@_4%Fte<z79VTwXFc+83G'
    '78ZW1+dvTw81g;s?8uqhDKjfG(SW#D@+8b0~ks(rs!xyvDbF}ARs?R4q)eH66Acp(hZS^tVS45aBkC?qp{N=hE)(42;9~rXwn;k#'
    'ODfuE6Eor|?`W0R7LGr)RpYM_Jd{pY?b~mt36}}FEyW+D9t%A)5&4S8xk+5MIvY<9W+kP!Y^m!2oCzo1zzQPwe$q)kmbi^g8Hkx2'
    'lR93%{cngVYau+cy>t@-J4@p9E9}m64#QQMmNP1a%gNB1x01fwXnUQko4|v4QTptf#BV^ZLiU+M2(>;@umU<aHl1N-(_P6{DYQQ-'
    '&CLXfCe(NNvdrL0_Wj^8_x+yQtbTyeMsV|(sp5w~fsw~#|QI4!qy!ZI*Dm875n5RB=tW1Sx2csQ(@X%>mkQ5B>^<JxDtky3a{!F`'
    'C>E~fI?R1p^S<UFFR0|C!wH-_jv&nGe^ku?WG8Nm8D$`+bs@XDhdU50-xaT~u+}dq@-'
    '9n$+{&sJib8L7Z^|llwT_*GxX|lR9H`E)|I?$W>iZ&m_Yb|oGbg@dn6dIJo5~FY&TYQg=@I0)RuFKIAR5k<O%BcgfI$u@~iGW@C3'
    'E&*q{tH17V?T3YLsn~jgw$_H-jKCb`LbG6mPT+?-mm4?On@M`fJr5Pu)|Bkh3Pg*VORFluzS9ApR;-'
    'k02CmEFU@DYTE86z>(kk+PXQNVl%pKdRSAkRl$!|U^4>lNqw9+tS2VWpv5A`dpJA{W_cmonfWg81$sgca^LpQwZ`QSO3F>*8Up`R'
    'YL2FOv+|lG-uO11&dmAgYDN&!=ceLDR2gPMz%isvMTZ_Z8r~?J>*RxXO9MWC9dgZD0W<$ty%?Ku^iOmVzNZuz|TFZt{fLLScogL@'
    'hem#aZCjg(=H}@C$G<R9gdXqGDYvf_I>cD)q;K%{z0Yy+Q2Cq(VET8h~mQF{_Cph8M{}FYq%j>aG^jaD+Vwy?kCQ>Ph3K8)^$)V8'
    'MF&(b`{k<RRe+7#D?7i3CYpus-TDxQH1=oaHXoCYuB=?${t}Cy>v>yEBjbaXqSEyqP%(M@O`)MYMKikYXCe(6z2zQ88!nX>a$Q-'
    '@a$}@AHE;8)8TB}OcK`Wp0#BYsTw<hM3Mrwb30vL^LnmtT6l&9=H?i?1Ghn%3R`f;?X$!!v4ARo^c=D;(|f#CqXs`g;TcRjweq*z'
    '23t;&ec!*pD#=a}5A%UGkO3q)7{YFcDHQt;HspYb!9?mp$PUw><_qOMxxo?S}Q#vapD(oZAfGAWw(lK$FaWwcygPHR&<-'
    '~2xM9;z*?Alx0jgtPLfkKH)67?fpN;Mq!9szNg;JRLXM&W{g)I`F<NW&2ODx?4{c2fwt!lh+5wX?jC&{I>gm$9<6ZO#J;S)jFe|6'
    'gHY4@x?qI=#j0zM>4xVx0v26S`bWL<Hp1V%~{lxY6QkEriJP;`kI7o7TeO`(Ww^21yV;{96F`@!`-'
    'F%aoo?yGph~v8Qbr653(+J)V_F~VA`zi4-(Wz9;4%RAkrUa{uo_DHT(-2<TY`@Es2v2^lZw7=Vn-'
    'XebptBpdEW-@qJ1!Jr5edr)Us8;U&#2DDeufZ--lJ1&WBR9fI4Z4!0atCHn6nTdgpXyi{k^TNkvb<}x-'
    's3OFBSq8k?_IHWrPZ<o&-INOBZ&?2`*Z~Cm9$y*$Vt;U0-'
    '&2dJVzNU%waRQ;$30u0TyXtbJtl9F?koeNu4z^jsP5j!g{~5a!LSS{ZzpA%7C;}XgIx#qnnmw5ZkZZ5?;4`0Xmc0erDNFC&oh(h4'
    '$r&6HqSCK54B|AU)siZme!_IIM<@+*<>(?tBmF`FJGHX6+i)W%g<=wVYin-PCnjh1@;2>oZu=|B?=e^(ZxnkVTQD-'
    'J8$1dy9a^cl`*=3|mrfM7-Z=8w(FKot2Qk0j)k8CA{P*)5q`)O@q<-'
    '^_`2cq7&TlyKTAW;Rc`s1fykf;o`dKG*JEZjqzV)Wleo!BE#)wxu?Xz+3UAmZsXQtO-+&?0h-'
    'JET}i`jz^`bkDU$?{|>$Ki5PsqfP>Yrv<S^-t!JPR07AYOH}Jwq7#vpgMb&OX}_Y=$w!-'
    'qQ7px{1pwEebqbA{ZrofJnb6{VpA<16wwvQ)5ER!T>AJ!rk*IcR`xDC7&zu;;oQP4=0MhF1hgOUvJGU(9qL4lQY|>&^m09K3kVn}'
    'HK_mFo*&6|pRT?Vhr2Mu;Zttj-'
    '=qYus69Hw7qX(3iL!Ic<NJH84WQvC<$@jw?DWnN1BZk8!=iuc6EB!frQsf*HtG~bVc062^{Tb*b69M~VzoVpqS=1zpLEv46lga~3'
    'SRhnOtz#ro(^jteZAc}`)$RynxR$iepUo=$%5Awy{z<j=cq2Nfg1Q#eC$tC0l(gv#`eRWU-'
    '=&LpUJryY_ai*OACE(ytot|8(ViFEG<45#xNu7vGzAyl_38x^jJ2uS2sAZ_JgdV(g8ibsUt$P-'
    'U(QRU94M(e;!~*d$b3v<v1cTxyMY7=S!>8Mw->pxuYDFDKi<e$8$~D3)+3LABged-adAA2VGtzc?*19N2hwX@>#LH>U5I54y)<|J'
    'T5{GUeHQKCtkH%WBS$6k>E8op+^nhTgBwv1{;d<R#|US!beoSHxH>%yWgqx<~32N#&&Db%`UTN3=L%BAay@nE!ZHZe0`fZXdzTS9'
    'dcfvSM3DuiE{=Ohbqd@^Do|E?v-nyN<*jhU$xVYtJ~)VU2u!;x=8CWDNw}#ESDEn{ENmr<WFWpb23!;agi#w+66-<Aq-csfMbZ)9'
    ';xO0c752Kk`G^aH5yIOXcgOIWHIY43VY(p;JUb57JH8e<!vTH*`wyA&Z=7(8=K^(S-'
    'e!6QB!70Z&G=g^<pjRvpsdbH|nRzew^V(uj3zJ<OMXcay{yw-hGf50ONxAh%}on*2OKI@9?#X9+*S6eEv*DkSHJaI)c`Nyyt7gAk'
    '1Ybj|S&`exMG?-'
    'r>nufc<N=xf_pCEW@_U0*!~=(=&MdHry~r6C3{mGq<}bU9ll#cPa0f4pVM;?(n;u6)Cw7L66ALhW@l$FJzx<VK)=9om7A1ORMz+1'
    '9qHQjk|DXls?mxESrM5acA9Ez@(C1!_BwLTho;;dtb~(fqmM4Ak$b%-SKP!k*x3x5#FEUiy_V4?E#KHXZMF!7u-'
    'E*{!XE5v^?UpDpp^eL6C>%+?*dRc%1s`<bhxd^2vyGDMa^>8g0=XxL4BwfKPN-3-'
    'N<9W!gQ1+7Ww&vyM>E|2*E+=k3Oij>W?hwm$u??aJuaj*@*U(RBAPYwsy~BiZy&9a|+g1loO)Qr5-'
    'Vv^i*%uKgNZ7(jTh(OB_tbqg-'
    '=`ktyzmoqa{8oYn<_()<V;nqX*+aL}42m4yt?!@2?zJuGB{igdKx)R~2ESOy@p@kl~E>yJDX!dEr4)oKLOhFMng2K?amw>>rh-'
    'r>Vjf-ZsEeM4)e5B24xLreLMj}=G%9E7#J#t*U&V8d%x#vU?k?mBX>}I$)QDhHBrIKn~Bj6;z_akjJu0O>f`8p3xZiRUco<Ci&!o'
    'R~eNB4Goak>&G?rUD+c%WJtv^LHDg?q3sb@JIiqU``5J9|QekyeMiEzzwt9ZfgGBS2DKUyDTsxRA?3Zz9beS$jLRzTS+JhMCkyd{'
    'p?TaG{1W*UT*(9w2uO2<M=2^?4aPhOCFs-Ep~c8x9^R;KaeL9Mvacs9*4j+SrilJh2Zz&8gnGN13m7=K!P*eVh9+uB)D0OYz4z^*'
    'E&gbReE$rIX9KNwB(U{YUK9j=&S)X2YsqaE7;8B2P4}xf`987mK7IFG1|QPc8etwxQN?Rs%u{9CkIOv`)$3?zvm&^5waMF+KUi_!'
    'PamHL&Tm4U?cypTZpVYz@x$N%>}RYcyrwk$W8Z=s<drU1Y&*{~7{dR4kXmdHS<@14sBn+sxrd5}5OrcSl_oL9A|cxIq|IHLF#g^X'
    'qTEVp!2*v_SgHBfDExrtg^|zl&JqwgtiMOt!1ZNGY2aU^y37K}JJOuMMIl>^$<yp8chs)G>Jv{FTTrv0LRrZP36%l_CLSCV1z4Rj'
    'O_K_R%M`zIqQIl=|xRuV71aqY2!(9ctjEdl__*G;R+q@8FMoO!9iG-tb=E2h``zPaa&nZdr06-l1G$pMEdoJ<yQr-__R`Y?#G;%1'
    '+N4a6P*5Wt|ksqJWo%5&zF;n%g}|@9(7DM!Pmz>5Y-G@l-xt9BWQ4#pCSoK$dWKc*&xhb3bQk^04D6bwBy%ZA(r}WMLca(^y-'
    'J`k@i{+Z>&qpDN)D70l!Hn6Oi|_T6+G9I9^6HhtX*#Rlfpn7OjXkS1Wy^kTc{mGm1PJ8BOK%Apv&Y8M9W&4nYWC#7;%b0x3il>0p'
    'Lp0&8Tw<z=44WQM*Tg&M1b#0iUREhiF3oo)>ZTWn0!$n%IUFMBP4tA&~VVyg=i><h-'
    '67$CRtPi7OxEtj?wuy#bm7n1UpS@AQtch7hyT)7lwB(A9<ac?O^9lrpz;H|R8rJUPx`BJ}7_u_s*X48XFLh%dpqpR9)`X_j{<{5I'
    '=F%AwCSds@5clJgC~}RT7xQTISEB}>eWh}#pX{04QPiD%+})v7M;W64r^@m{k6MdV0IIuY)WMbNd&1An;!%0OcGE+7>UU(J`LWw;'
    '8=&)7jFxKm;|PL;haPK|YLdd&VgXPF<VkmV+sU=v#=3;wHfRq@XKI*ZHE(9*6M>7B<a0fT$7&TR4+VnV1>Ts(zzy{rY3Xa|C`lG<'
    'Tz<K^$nIIq+vH(l{v?3hrT#fDkTvwwYts)7EyuF0`cTc+)8?!FsI`n_vTr{utv#RfWR)2g#$i3b9}a%8`CeVSYunrs$`Tk3bfXXM'
    '`4ya2?&j(`J9a1I&x7)>^{*ZFxwhVSritS+*M%3qJML08lm;vOJ&Cpp#$qw3Z&uJ4Vxz#y+;J>7tAbt0lUlcCo$JMC!7(mwR_d+X'
    '9X>|vJ%%=q1z-0sP5kQJl7^ph-$&IBR`bDD!CtwWwU(`0eXFOBtzbVH!Uk5UY67P^-Q)Ks27%jIHBXN;-'
    'K_5_;!Q(|PO#hLbD6=ml4sX#yV=IaRGGPNcQf<#3D35uPT24(u=$A14Of(!vqz3|O@>_=_oPnuFEqF&L3G~^OZ%>YRu5v_GLy!Bz'
    'a8lQsquPt%ZJ{&r`*QK^_Cglp#JMYibD~*oT5JNwcQ<S@-Jg<ds0zd-WqWdjN@JV^MsHY)SrMK=5;?$o;kg-'
    '9%Niar1SBwf)+>?<rjMQ1o4RYIdc=ec6#S<bFHQ5@k6i0;PLH2j8^GAoOOP5oOCSl&nALCFSIl`I$`wyJWr^C0*ldjoAHZIPYz(9'
    '@AP<4zCOKT^;$DVPYNg4mDCS<r+S6m;GeN?$4FQjFMHClx9n%TQ_Qry)lWZc=(MbiZ?$JDmZ4MStVICX=h4HFyi4wU(;uhPR@3aw'
    't>6+)-fg`5e{)_LHt0R9eR!Q^yX9$J+shj&As6+PD3+tRrsH#|Wly6|a%{obcQn|H1Fhd$ou)1|#-'
    '!Acnc)z}E0lP?#OHT)8C~9_(G;;70&q{)mq)KoQgAzPcYXYjWtM)Qe(pGXA$2uU?auo=r<si8=_^SXI?ig3dy7&pI~9=9t^ana<K'
    '=q`M(uU=pskl0<pj%WgcQJi-gQ0W4<aFyliwu<^sgn{d(efdI~k3}et^BcCNATMTbB>B8C2Y_4o6~<VPMjh((S4Tv<9PjC!DXz38'
    'UAsm1|`Cq<{f_w0xqyhCN=rxGE0XzAcXaIz~N*^hTh9%HnD~fWoxeR{O2H(G!_3)miDTDJSi6@hbi_RsuThg1&*fF_J%wXY*N9-'
    'gD#1Xrw<GPkgFp5@Krytk97#%R#+X#Zre1+m^Z$xr<xY*8BB|nr)(Bc&i{2e@DKGjm-PXmXz8Uj_AkYu!vM^SO5q3b)MsAb+a&s`'
    '>n-+t3>JZbfG|eRIEA~^F`^=+GS7l0BPd*e#EM3C`iL)FL_OTdOSpK?7|tKn=LfJw&`ceZ@(spi-mGdh7lw_;Ep05OBFLX%9+twy'
    '{jjB0+gy58e!Y|Y$mw1C3sCpI6jBc^1ggDMpJnvDuv=cLq_8YzF~H|Cf=E!hP1dF#27%V3-'
    'Be)r0*5)Gma>zEPW^Cp;Mri5uL3{_LY0C<_*6OflISvhW$GozWMX6zpvZ5rku|#GOd6Eo|B8iYGv;|TJ_I0!asN})hY|z-'
    '&6+h2HWidU{xqAT>b09!6(^LZ7}Oaz8MxLi#qxtit;O#R+4$x40)-'
    '6?zR~Vqj8t&_qAt)pxD$p@P4k$|KLD4QX{m+f|cNX7){H<Wbvw!VsG=Np9+l!%rk6cU*<GTR;(K&XcRwLI1*9gN@f8bY)RkVjXAY'
    'ZelX(to}W)*!OxC$g<x-3L2K*fN~4B)W!Ko3i7|{Y=nLK5x<AuCf@tXS7<czIIWw7uh%oN!XZZabdOa_M-Kd2z*^}JIg$&jjFQPE'
    'e8EcWX8aNQP4=no9kkxFcb`Mcqmch;qhugZfv+d<)Em>B+_c?3OIdy^R#YMU~ncZHyLu=3wh5q16D^Q1OfY;~N<>JT<bM!7@J4kV'
    'F6yGJfK&>Gv_ZIIJ;`zv*(OYxKd0UtrAu~|1g8ojgs84Cm!3`7`L*bdIZj}vQ*~@Qb?~iM{r#@f*RmU%)QHs}A<<tfQwdKwS@q#R'
    '#R#RtS4zbT<CJmn-`WBSDMQX(NJ8Ah7G&a*YqK|=<4tB2|3mEu8$~QcP>+6-'
    'jYH*cyK5zABTctNg6mI<}%)WH;%oy6(;rLhGQa2;wd`Gb2?7H+qrhX}o7p-nj`K#w7wYgkt;Cs3|ZKAa7dX5f);XPaJ-'
    'x%~E#uNCF7qRK;2|`abNfvaMCi0QnLyuIcz5YTKJ>sMhqZt4D+pF}Q&#Wmpe=bjd(IV0td#yv}D{@wJ6gG&z>^7y55`Qvwlbce(W'
    'aAKCgqL=d5Y8|v!BZgL_rLy35Y4<=SxFAlSl*cLP;W9PPsGvxG%JjJ-pn0oscZMgD>-tTv|6k5rg!|fcmhQ-'
    'y6>9nXi*(kJtF0^aEcVhq?NAm{cJ|R;kD&quP8V-'
    '(BkYKcf`0`oNe*r#D&E#1*8|Q<s%$ZIdtnaS{bcPcSfQhxAEv&4b9I57+0m^G9GQOt#uo@F}l!SlSGO5{4<bGkzO(22e+mZe|j>1'
    '2lxQm7Fxynixf`@VAN@=XJx3oo%Bxq-3cy+)#J*c23u~`SDK;MMIgmMVYj0dv{V0nmIGto4VZb4V&A&@BeMyBcI!m@7IT|jj>eD-'
    'yJx|tFU}SGkofa>aJ;$S1csHUPfEs8I%UJ?wg1fy0JA!5UEOw1*6P*2W=eh5Hn;1hb*Y;~A%*7C$vT**DhD5kLbNiUhu15rM~1{s'
    'mRFs%5VPeEI<2=ivpif_q!6N_9mWA`9QSXH?&{fL*rS@T&Xxvhz@8fKct*8T+!%_8B+WW+r<O>#^p~K3j&OTmm1`Y5f(q+)TKxt$'
    'j+(*oNq5i@tYcufWK6EM=@JXkE7aqu%+ZeYC1pf;TPHe1x-'
    'K7k*=8aQo_CgBLESmMBGvMi;g_1#h+pM{P~VmYI6RY=$*l4!;0iK*5H*~AI7`)_4#d05{RImxV%u}+AnzuF<L|E8oohDT$+_&P>?'
    'n2c%rpaXYT^R2i0XBg$Mwo9ww@>aeNX-wPb{^0a$#c~_`Ki_)FCKXA0?|+0{2Ehl{!FrWIOk4p?~moQ-ayrk!B10W_egcwq`l~HP'
    '4U#I(K*?6z@M$tXIV91lKz!kIyQtov$g%5;KkKi<E=tHRV0*wNBt^SbVPkx}3u#S{wIR#-'
    'r<~Jvf*|PLVfa;8nKWzt>Bm`)gbfM~@TIob)XD!48J@K#;#4TxA!6tLtKjhW%S@@ao7hhf1xY^RTJHU+O$<3m2pqWok!%oL>~#(r'
    '>A<3J`2}epCXUOLKg+n}w91Gzw#7xDj-~mDAn$nI+-Ss{_8c)4u#3@RYqZN}91viu^4O!iR5R64f;>&}^cHc?y{}JD-'
    'f5CfObbatYX1)WK5KV7Yy_t*iocZ%S{U>35=8%(9wyhSsrBtWN?EHF|d)y5I4OBf?nywDL>tSu}U+@0fI4?4PdfmpW0InLdgh$H;'
    'ikNsQ>i<Hvb%+y{QX7Oi#1nYN?j$<f;t=J=Y7Vn*}(nMDSyC&Pl@39pOiHk||wDeDllY_qewR{YuiR0gLHyL@JMzJ`{d1K01Ww_#'
    'iZE4+nxU2VwDf&nm3Xz#kFA!s&IIbnF*Uh4Pd#F{4Up8z4-'
    'k17G?Jhx*y7G18ks&1S8La;gxEH@C8Fg+<<JD!Oc6aA>ALZ3PJ9qgR8v(jd@`ulIa#NP<-$xXOnli=Ag--'
    'XqC{oc&?l`9iGo&~d3Xt-6b{#u=Y=_xPag$<RG1)jt=73aoXR|S25ixqo1S<qG-tgP?AY}RP4{I}3L5zX_Z)34SG{Z^*Cp1VL_*R'
    'ZXvFvDuDu2g!vtAW2%>fp;G7Zz6OWwYJWyHj#+Xo1n{FT=KM?>VGzw|OoxZf5B|CeAKvl>WjzxswbABf~qxr^&T(8(r?x$hAw0aW'
    'E@>;P+M$n{e43*0P(J-^q0epk;)apR4x>+*rx`#$w8=R{o{M%UUNI!l<4*uhRLGoiZ)((phm@s;I!_LUprfqd&{@GY{@pn-'
    'S|c;$m11Lv|gQ?S^^_r+;}Qy#OO?o>cIMN3y_zO`Xz#(*Ka|>%spJUe9Ie>ZyUu?UBq}-'
    '^BgxNksXYbM?y)iB;uO<@C5&%XPK|f@WBi>h!~;g(WkE+SmH$FPX#uavUyRu4nJH(&75*+~?vTri7=~U|eP+Z6}AHxrx2qCew9K+'
    '8-'
    'K?K_lFx(wTZPDs}8`Pk40&<n7(%peV0U?1RN)pp4VoFwbA7^070k6rsyc9{1N{Zo^fzx1HO8ygzgcbQiw}oY*A8q)1`(xp?XEXm9'
    'xRJi*j~$`kZV=ai|<_1THh#?yP8ch{_#Up|rA2EAFbU*0gD-'
    'p)|#^SZ?|az}peS+2GEs}e(3BP|s)tUcD2kFCDfSz3Bd%1P1&74&`n@q+3}Fmw`zFTve$XOcS2robPaQ*~=AN`5fIi+Aj`*Bx>W8'
    '$@P9e$8Lzj#&Uz3b5MFa>NufxLu;@Mz+9X;xjJa*1vsT4UEXBh`C3T368egx!OH9u&`cqN2$-'
    'OiDzyJ%o{|Xs9^Uym2XRzj#rB+1xjyJ`YtH(54>TsvAE3XX3Pb(`QU+TX$^elsq`+rmz&;iwCzjq6CTxgE`yu4kxzV~89b`@^L|m'
    '_uGOFdjHC5rZN~H3Og0O#lJY5hx#`)!H5C`V9uE2DFdZ39j-'
    'EaBFbL5pvG5wL;+&2bMgZUXo%B1N6&=6m?3lYprt0e82Ord%rjJvbTbkq+N!00mP+W1ZjfmZnpA5La8&=2X)dqMD<{IC=c$FqsSD'
    'rqIz3QdQ`r>uL&NQ10s%gHo*SR#%IT-Uc)zK`7_f0vG`7zsS3&gy$Ioa0XuC=;dfu0lw$l<TXc<im&{w}mbTW#s5XZQT{na7e#PV'
    'BW^@OOD}`jq!M-e_2*!R(~oQ8_j8Lwg?@D_+PRhcLdASCZw8jt7MY;nkR-MXtzjL0H?TT_oUUUXO)#C#jHp3(#0E#nCjG3@b}K@u'
    ';qHjl*$^XLpU#iI{zqQq3Ab*V2%w2I2lJHC%Jeg~R5iIU~|(v3Gf@f8D`-'
    'Yu?iU>vZkwqG*3wtz>L#@^I&6@dy}wQ7~PPH=K;Babt}v|9S5ciBQ^mUSSnxG10{LyD4m}KeZAyt^4?8w5$Ocz)!6z^qEZ5aetxG'
    'Iv?TauCcnk@4M;q092xzt!M4R1bWmw;a%%%xKj%cv@)UlR0*8u-+P)%?b%ERtg{B?BK-i;OV?~5Td%dCk3)Ukn+L-'
    '+iA)nUo2{Y#eSNM~xsu;#OXI)r$u<XATJnhENrQ*W^@s7q#QXPN*TsvaOY&CbQ3};&-'
    '%I`WQ((|Mpi0UTIGCG@B3>L|R}Ax<U0UZ7xha-b**b6*F0aM#PZ2(6p;bxS9_vVFY2MsLoj7eCmuO!ZgRHZ8bYNZ2Pms{=kkjd7-'
    'H+ZRw4ICbQkx)!&by>N)^_T_xw>4@Keb!Y%Yn^?bs`O%o{NgqLeA%4RH8oJB)UFrQSH)52;B`K$d^o<sMg`blx(GKc`aT%AEJusI'
    '9`MC{jjhkW{%L+D9CAU+m%8)pr370A~5<JO&4CgO|Bm!kay#T4oFk*UbMFge_8Ce8|}uhYgyqGXPg{X6T3r6eSjRn?qWKJ#-'
    '#W}ou*v7lm=jYrRzKJj9sV6d_7nmlIvl;ZqW%-'
    'fxo+Ci8$gEyBji3D}a3HlWzQ3?%<Kt3W@wB>!gS!uD;az!EiHE7A20mkNE%ZDtsU(VSa-;D-'
    'hd`!k$#v>XVDK?uTQtzQP9M0bOV9o|61LjN1+9i8U`qyTu>&?3(8Nb(XrHzy3O|ho+aD$=J-*0rVg$-'
    'C+B2%=0xK3hRx17(rw>rpVRq`LIwEgg~>gd-Xr>WxaRQNBV^4=H*LyA+5jYa@ik~r*g|2?xd+2z2-'
    's3E`2h<*bkbzybl>pn$%iBi=X`5eYUy%G*2%oyN`z<ganl-a9{Uq72Aw9-d$VsqJ-NELA+V|K#8d<csll~R(i?ak7xom+2SBGq4S'
    'lY<AS%ft3`$ZS8Z#f|A5_=`|FnFU2%h#b5gBPMsp||B;5Gy<JrL*wzjX0zZv{2w(%#<1?0m1U}N+BSymgZAxt&L%-'
    'J=`HmM^Ox7W8AOUk9wn(wF@&CShiaeq-UUq?-'
    'zJ3o%WY~v8m6_KyTuXPnK1Zwpe>aQVo*>pB(^!XmK&$9}cvm0g{kt(rn5e?(+yw^|La4DxQb)U`ABztzQZdp3R(<9|;H!1{B?H!L'
    'Qduzo$RwJMxw%w<1&tK2ul2aeb%byvSZ7qH+&i?o{BfeR3e%}*OoIXk>TMItB&#U?&+8f$WO~_a`c8*K5qkwxinr;ifKWz#+Tr5H'
    '+y4}xD(Ae3>P!V8JKu`TK95&caH~f19J}Gf0Vb#7ELGeLDIlFI8-'
    '}7Quf?5~xP=~Kop;n6jaQ|n&+5a8U*I?6XW@>|c7s)^cJDuY2EPkLuQa>NQ*UlADW&07@#JO5s3<>niIRd?S-UlV2-'
    ';}wPvOz}q_Mq;^oW0AT@@oSOo?M3WeC+F=LbE@WOl`Ad2Rt)R#OsHIo;*3057pm^P`xAMqu5p5E+r#vZ=U<=>!f3QZEiI;3P2qB_'
    'R}TY)55DqXu%^s%YsheY8oQbw6&}`-'
    'Pm+i!!eMy6Y#VtwhP<2i|3XwTk4^ThmE{?{W?A!brUVOIlRZW>z9w_16EUAgIU#mID4vs7PaMk=}v#xvk<`R!XzEJKue1)l)0nfh'
    'cMgcWS)1D$i~|hczYsx(XuP-CJo;qmMTn{=N;UTwP<2yw4=WJ8_2LC`PC1&V;5bqH@A*>eANwaj3H+FcZFcdl~+p%%0|Nz1Whk9T'
    ')VAGb(CXw&zluaxB@>A3#c_Jx%<j1GL%bE^=FxpK~Q$8tXn34OE?BHLaO#BiREhs4n*Tq*t#pkRTv3{2llO7v(?O&YtLDH8C95aE'
    '{Dp@3(&24`>W1gIE){i{`on#%}reE{yx&i?Jjvv&!taf&1$C9ddh!&i?S4vt@EH(7L4wIMZXW1{=QIgx2j$7{eVW80$2cw>o{Kyc'
    '954hHod$P*UFDLJ&c&fkH}(YO6;$ITj9vv*s57=_9jVy4v&G!ME9_9C&HnFAyfN$9KF^O6X<q0I+?d^95aZpmEIH1q(7bJRl6jKw'
    'OnS@1$Nur8xw7BN`AQ*6(RqcOO`9XuWX6A5pXfVJZrsot=`h#+6ioRF%+|GQL;br{x2^2wbaUOk8gNgn(d$Nw%Q>nhrYkk?5etlQ'
    '9z^f`VrCYFkk=2>SA{V?*Zpq`>4Kf^Jc&QaI@&(#a%&ulf<|Y7Xdo2Uq-Lyf{Mk_VkEb7b4ik0_B9^ypWom|6LiRELD&1Dj}3(2o'
    'G|;RwwdX*srrtyQEoJmXAh0{<bcx-'
    'n7I8}jQHY?06H}J<Qu6WEefXJ8vQ{kg|Y%gQmQbI8UDs9JS(huQ`@{Ztx9G3_?TVfVl%goy9{~nR@UC}I#hlB1HNw-'
    'y4~+r^$i#9G0d%AlVS1D4~ljh9c;uy>$VlSU@^!Y7xH?TQhLZnRGnMw_^<cb{q-~|Q39M>*GP%Pt%J5cx=g!2vJ_&^(OSVEHC<W-'
    '%V0hOZ}f4I)hCyn3}2;Ve3=AJN<~D%BAb$FM}t&$w+`Kr>Je`cM9aR%2E+DB5Nx<lsqSOZc#~c=P#Kj67li-'
    '4n{ET%J@WAM9G(uF4Xzy0-l2t=e$3}<N}$(7!p)nefOOiN+goX~YUgIH+PB=&_IrKNj#6*12@O!i<}y+-'
    'tN0V0%z?X>C><J_RHvKvWcVcjSIMAF(L=d0=sSHtPO)qb<O_$H!}C%_^e!WKrhHBl9BXKezlvlljDlk#*~Fe!oq_wM-'
    'n4VocTJ*6I32fBXzwsP2oIAD@JgmVwCKdg<JXqVnHKYfR-'
    'w9iV_PbQ`A9BO=IatzMTK8XJ4<ZR8eH+*9q+k$asupL?IX`CTUX|o80hp<@4_yeHDGfpEdCwTbS|GhlWU{jdwHAsf!l|(>UT*4&7'
    's~d(V_!2tW)cU&{J-^ldCL#)UlKl-x%DjOvHYEwA+xsWsIm8U^lL}&<{DwE-#`?`IF|_>)wEKV-'
    '|s<VmsJ5q5Wc^GdG=J#Y&sBYUhI8s)_PvrryT0Y*wgL)Y{ZWPw2NfWP9g8F(%9;m=xvn^!e!8)tU0!g23TSdR0l=X;cgQE`~U|_O'
    '6X@sI(tdy?3*k4QwM;C6+V%$y)F3hhe;!$K#sE;2cck7_HNzKV;PE7|0(4+3nTcqA$zHF^`~UyORtSjpEnakGk?}F9kZ#DEXo2@c'
    '05IvgS&LGVWm8^XINI3U+btl!j?e;-'
    '@8KR{$$@h1he_|2|;^STrlgCaLf{APT6&nAO16Wj0*6LR4!+dK27_?h^Vi<4#D@!v6aCZbm%TPI414AGf3kVwoHRQi5iEs5v4+a)'
    '@vG6>wi!fdZ?Kk8s~R+TJdXhGxqMniTWy4oi(fvvgXyDfyiI$U35h+?W*L@lxB(Fg=*8M-'
    '7>$jY>&7awb?t2R^IUH~Xo%tlzp*HJ(APC%7suNPpoz`N=)ZX6wXeKzBW=r~~5NtBqZ+R1s#YQVJkdG$@|q8{Z_C?HzX-'
    'cB0#7CXB$B_g=?G>o&09_Z@?G+wksXTXB{{r5iZUR`Jb!gjbM24QsO%-d{D?dA-~fhbTn@-R0CfAl-Mr6#@7ILa-W7lM^-'
    '`)N>civ3?YQMbLp-'
    'J&Jtx*QnO<cfEi;bS@5Z2JXmmi>+0(a1z2@=Y<^TsgpoIPulgm8m>AZzVh~)1GbJ9O&d_9wNA;wrZzRMouG07m*s=I?3N44G9I=Z'
    'mVG3Fz97?qEx5HcO@_8P^L{qKDg6Y!-'
    'LTMzHYFAsUtiQYmUfGY@;IILffG!t@M836q?=7uf(H%mCM2%hRUwCX;TK9ff)4Y~P#ZYjI?dVjzKZL*3|dcBy&mSf-'
    'm~pYoQ)}@6J7!NH|zrE(&xsrOzE#l@P^6;D8B2e7Bv`Us`9PD6uFm`ZlA$=Md--n!b-'
    '{_gLyp;zupMizJTAkf03>Bb4ed+=w%d9_VgX05McgQ3oYEvB;L0=CqV0;t32gITkX~v9p1}A%w6dJd7Ty@@WJ1afR}Lt{?r+*9Y3'
    'Spk+-Iu>G7o6$n?(N+FzT7GUKPDUC(@*e|Kj=xxUVFd6U9=^KlgFjMy<6t6qGx*OHIO>ddvx(tBhqC&0?DHi|+iewJVwaius--UD'
    '2`Yhv!tE!0l{MggvA`M%4)oRqZZo+`iHg;l8)lRJOHp|Mv?*lsHg)<tIAWyKdDY=Ye=z`8d(>20rY{cHxe2tvjBcA+>KeAbvAy*O'
    'MEUp24ib)nYy^z~uk9W<{DBxL4r#1yN9%6vnaC>U}YPM2?HRiANjN$WT-'
    ')f9?#Z1K*eA$r86Qe(2D7loicINvW}bsPVE0NnDEdS<ZALdUjfV`FdWERqk;DN(;`$ln{W3_2*7$E(A<zRalU2iU1iJDqN|^<M}V'
    'PueNGUaAdbORw^be^tZjg_L0i5!GWRejL@v;ZNM{T`S|yxy?@46$W$A|I|tKmdZe3Gfqfn|Gp)M$Ggz_5MC$wQY3=Nu)#pf)@Y8*'
    'KMY=TlzpDCjl#JJM}r3jEJL6q54=QPIJa&2cHcSO%U#~77X+CImjS54T>@^}><0Ey#TP0Lcc7plzSDnhRNLh!dyk#weM*G;N)Rg7'
    '&24xkioIUeYQJ9cLN=e&ID)m<9WZ;c+MZ&TwXId&_vf|pU_&FH*~jp0wvOp9gRx?zRYJM#Uu~^=+~Ud?lj4DP7eZ(85sXH0E_7y-'
    'c7*BSCpShlAt<kBMXSP(PI0_l-'
    ';RpjhnL+|cI~{D#3W?L*kHlEWi%`N<*wWHr&QG9M1<aKFojE6&Br{`DqS3bKhBrzMVd3a@UvD={f^h)n6+M)ayV#jOU)UxC`K^n4'
    '@xk0SR5_4F1po1WOacvC|_?gMv|#Ur4|5#cKiNiCH&HSNgcGvWfD_Jh3Mg<P3mX!=bph?^f2aEvZCH!pR=>QtrES96+KQrxuh0~='
    'hNZITD^J44Q3&c<DwK%4nWTJE?tDLyqrRb=DXmmhar<MCv*6UmC^DkTfU(-3lzOp7n`@MG8Ga%RJHegGA=*+`TY;wX@-'
    '3(vZ8ZpgZox`FxON_MDzDxgHyBdxGZq{H1tk@WSKq(^*fIp-'
    'S$?Kr8EETGoA+VIo)5$tvFRz+e{`qRH>TFyiOHvakcXaQ1akT8Lzc@4dx5O*SefoVq2waOR(a}Oq7a-h#dJ0x-'
    'HF{ym*qcQSV6EP^FIt@ml9XWAq)d=#BlOJ>!rKLhxl_7{phjK6>0C?z#-7-BnAvc-;#AGHf4=-'
    '!DU7H$RV6;Pt0e0WC1|hZD4)lh<Ki`_0G;h>#nu^Hi%ftYFKpqZcj&Hm-'
    '@yWm*4#@pw3)qcgKu4*oFpr@Ze{^TME9Hs<l@+^qvEs?Up)F;t5GS&sR09=y<-bVS$I#e(pM(wgUBB~M<=@xZ-'
    'VHT?T<MS0vMA=c{!xYKI@$XZ{c7etCzubQ?{0BFC#j{0NU?#e#>#{1a9C@rF-Gf}H4H_?AS$E?(jKNa1YCxj8Nr=B_z>!s2CuE_^'
    'p92d&K1~P#Hjb#NR8P3{NHJu|^PLK%~+vXMNe~wmq)oZ=^s4)USi2g&&s&#WQ6S0O!C;h41JQxYkTa!YBdv`}TXlQlqu22(BtC2#'
    '?@)O0>UQ>;^ybH5ENtRxv&SUmoT`zdU_6THJZ>+#BzlePQr|W4h9;L%k?Py!4c$HprtgG0v*`*d!woRKlzP#4q-'
    'w@QRy|FIOsaC(R`ScUo|1^v310CqmcH1c>(se<$`aZgV#b*N`MK^90K+WuPPE4Nio;j?K;0Kl8F1`>Nw7l3KAMYQjVEQ24;#}dat'
    'SV6el?KH--9(w%-rC@&`5`RJ3~{=m>AFL%Uz_S;6kfN&<@6i+-'
    'ZQ_aE&wS$h$pMin$6oBJu|2*mUwi&L(s!twa^Ba(T30US*>BGq`#|m_fxQ5f^68l&>l7{XocZ05D^&@b~q1`*Yfocm2aEZC?&AX^'
    '9yn=*VWb;_a}#vPxQ)2%8f42vdV?@s&jNpbSr!j1+lRx!k5bKJO<}cE<_)!<Hd6VofGef64hO@=&jdwJDpk|!-'
    'Z05DHQF>FLYtK361V(w5*_^a`a}&;UrmVa8?(@I;_9@q=L5Q59A;_a`d*w#ryk!7RaDpQl~~Bi}bi&!{Sq%?cqNVUHwDER_pwN7r'
    'oMJ(d#||Bc{UdrE~31i+5b~9dD4+R+&44I~UN;L$SQdyXmnx`|A#dA3XsFkNMfZwyqv`a<3OTABJ`(Uc4s;JKA2?@8Tsny>AQeaq'
    '||Gqld?-|HMuP{%ar!Ir@zDn<Z-W^3F6LHE{ASv^$+^Yf4YU*s7D4DeejeBoS+C)TH--'
    '+7x2i%#_kT*>yTp9tCo^#_4_AY1OOyi5;4)B_aPksyJv$(4q={{}O<_zy?zuEvx<G@n|m~?(yo1*THA7p_#|ZixxKN<cJpRyfw<B'
    'kzcb$&SLgaOHaPEo9u=BM{thkHBhi*#*rI5w>1DoB1X&Jt2!(Qcge1uk84C3U&IplPk8TFBOiQpFQ(p}wO;nbo#7~YC=_bl58t?M'
    '^HpZ-pv%0;aF>32U}A#}H0WONKprEfaT^~W_r>aYg{z&h{<#es7kDur$74V`wM`*DZoT}AfZ~|M>cOmB`fLGpKIS&KclW$7y6o!9'
    'C)a#DPV^Wo4xqwcSxplQM0U}j?!_Y0_mK*88A<yCB@f!y0`&I}Zzz6%9V&rFhDo1)lX0aKH-@D*t-'
    'l2=2DP=dM@~^qyMtTu>7G4!Xg@pkCg1EVwiP*5Qyb5ctskGe5;<(mpjxL?>hMlU?bB)NxfV=!+$dF9_WfiV7$*evBI$fx)Y8_iD!'
    'ht6AF&5S_{pdrYiG5#FM)nnFz)pP;lyIL7>KyA+?}i%P2X)_g$uj8dN~Nvdfso7>HfG@E}gh#9y}x-'
    'RN5FLt%}W3;WSe;e%W8n32S<~73bD>K3W*ui!))6DB5Wpc*-Op&TFy5-'
    'YPCOS_t?1p>YU5)%I@iB&^ZFi`NgbR>h4j1}`Q;hQF!ft2iM=-k$DG(dX=QgjhdxeM&}`40Z-c&-'
    'g9ox0q&`!2KnU&+>Hy9V<tn3^;=#t^}padQzE}aL{ioYsseM^qz`U27xy6I1TEfUgfW~V;8`E6E|M4z_kJ$ogm9b<gI@RIxiXhi&'
    'z)Iqe+Ul`{Z(%nS)hEUIcO-'
    '9Z$`3T7U6vT30hpv)eZUZue$bEq>2hgL_honAOxfkH!!8dN_4`eSGakTpAxvN*e`;`=HPn?|$RdvU}`5;#X<02zpP<*%;{*b~R_W'
    '`asX14Pm9~0&$!3nOHJdyn3G%jPY~X@{pRw%P$bx-AfHe51fU88D}J(RLq+4KYHzl;E`OOR*zRHzkesUvDs@a<pi6SkZk=J51hsQ'
    'jM|GPtHRA8gYG`&eCPZ3KAyj3!$Th^lxr3|#PB|{GJms)cVJ5G(Sg&uwW@knTa-'
    '~e+;;D+kWKjG7RwX(ZfRN5=+%?o@junW9={dPW5L|{?BgnBV~uo>qb9mLeLCvz;^%gBJ{Hwi4moM&bd*pVyU}Sg9&A`-'
    'w79nqkqC(L)wHdKU}F1v={&+KEndsnMPQjYn|$S4aHnLr-'
    'g?>)R8x`R)~);3BPJ}5>=#{Kt||MYGX{A@xi{{PjJ#N_u$U)YFQ=>*WaQ6nZ?%h+Lvt|z@tL<(qpY&lz}DFY>e{Ed$FS0+_TBmge'
    'GM+vE5nB|Ba@dOpWa|24+2rxSx=YsCKs1kSo?Eak)d%_eVc9e;Ggdg!nnQGA-'
    'kS2G&B+H_u4GCe5_^eD_D#72aO+37h~??W@z>U_5?=Th}IXoy5}v(GyN0PblSpsfmJDZlU>KL_pW9)t<vz{^XTFjmvNU-lPz|>Cu'
    '{`eeQn$3&aH}f;@`yi)$9#wOG@~A;yPT;`euJ)RZTCYP<GgWv^PdR4zI=e2V|n;mz#I`tl;VM({(W0Mu+1<5TjMg)Kh5Jb0&mEtn'
    'F;5v=)slYtnPDxxmg(`I=|dk)+ATqN!)W=V7?+Bbo3oyMInbys<PTf?8ebvyq=QTie_BbeMbkSgO~SA9$8YAYKJYQw$0$I;{Ty)('
    'wL{o55@71xnPD-M3&aM6nZT?$p_iFF<47)RI+nUvzsLb~hzEotnu}D3e^yYxr^c=<_xOZCHpUH(aGgLHif$-'
    'nqs@FTmM8o5*R?`ii0+)M+^7%I)aNQ2p@M0Cj0%j}ds-uSN9xT!RC1QXu>7&vtjQ%jZi8Vd~wj;}#90g=qMxtg6`rrsb6P%>4>~v'
    'P*5)kt%DeIcnUneNt}x(44fGYpZA24q651XuykOEb<izyv43bPEQEb8Lxl|qPU=9nQx0V@4n#-'
    'C;jF>JEvh@j}#wh1OxdfSduE9(YsUy?{>mohNrb2uBa<G+hFs2*S21ndiE0&$Zxko1-'
    '4$bLHBl8w}&`1FHC#{Y>_i`TBHME^{LU@%eA%H%^l|JY8|Z%UwjC!$_EGU$vHADOQ=d$`=|}wJLDI;pm&_hnpr)H3@e|s;*q8ROW'
    '_@1P!)PRQsMr>2?e7HJw0XJ`L_BfGVpqLPgziZQ=bpS{3wF^a20Vkanh>-P@GQFan-'
    '1I?x@+0y*<dl_u3fK+lnjkEaMeFBlHS++y3EFctFhFhz>^aTo{S;N1IF?tU@(-'
    'cKD0xI&eXcy0=A#FWqu4NAfx(!+pz6co7)Q`|xI*FhYU^e#KT;<d#?EzfaV9pslW~Yuv2&800;>u=RI@al8!<V04u}DmaP`)=pe='
    'ka&;YU-C(|&4+mVbRKu-'
    'yLbW>E8b)^O0s$6k?t@Cts=TZ{l8ACJRUS#p-7f&(xi;iwYQ$myM|R0ehC29iCAC>VIb-P)M#k6O>&m!>18FwIpsI-wQRyvZ8-'
    '?9Q9;@gd}=&X!g@mOHgU0~JRbnOc=-F#8)w@t&@D-'
    'K`!*Gvk_5S2>zi{@tyaG3L#SShQDTpkU~C@uOO}&Douoe<F!ZQ^(%nnB_DaIMRW{rAeuU1r<YRt*-'
    'g_{DM9*>YJk8j1CwnyLcP4c*+bAY`=ehHj?X9PcuD4_aBbS%Nq^s?IHO)DZDLKq%P~TKU;Au8e?hJgeE0Do8c|k4l6J>Lb#aqC1i'
    '~!#zMDBOfgK%2*<0|5&6tOI!-V3EJ<u%?z8|%cFtyQef=#1l-'
    'w`+l*G@yH*ucQ^j2$10omHDet%IB5UZ|{TNS>V?Bt3{<tKB>XcY`1~0)Ua|2MG)#VC)DglzoSC<RzAk3IVug0<Ras*#;bLF=5bKZ'
    '?qkaCwDxDBwCsA>>oi!_M1hgVX^lPFlx*5{^EU}S_FFe)((J5!^wKGpJgxa3Q`g#kuKRRfODkHcWi2_RmX3tVp&TMTs3aokfJEW7'
    '-=E)uumAl99O}AeX7AavN3??JeP0G2;OVfptw#)S;nLZIZ@LH4Qoe%x6Cv}#8TNkrJ>P~<&`_%7_$57b@#6(5(Xc~5Jb2Na*p<GR'
    '@%FLop%+UHx6AFDwu5m@oKnh^H=Z|mhw}zfkA>3w7Uia47$4x#yuY~JwzzaO%5pq~`qw_Xtdm2YR95T`)}QCJ04?O#^%X5~yQB*@'
    'eQFspcs-we%bo}q%Hm13@ytbAFVkYi^k2B-'
    'Y8@pBk0;s5c{>D+!3t}3!qd#OK`q#3cafI<N}!{vaGwac4d$2Y_K9mt_TMVLy!pNll+|u{@h`-'
    'rz0v@T(<d<LbirEQA(~g>GDxW%yeQ7$J&45x9#uM?a+*SR{ec1EeUY6b=$*t4I%_S)-'
    'es9*Vh$?V^N>eEG4wkf``0iV9?BOii;!XTm|r&!Z?@0YA*vqk5(?-'
    'w$~GXY^*XmIi=PqC9Ai3iXu9QL+}=(%GdMe<fpv~Ilg~$KGa9dakf1dX3W}w+bhA~`tcpo(K2&YI=yi61X_cZ7FX-'
    'O&@&{BG)n(L(+VZPXy9<ks-'
    '9ORc^55WeaV*WVK{y>uuWouddBPTfdG^>F%i?vodoQeK`K5F5b&IV6wKeOt7}499(Wer;@pY}JspXl5#oT67n{qd1^BR{#YLs7(@'
    '~4wE<%y=T_CK#V<dxnlJ)1wk;~aq1QoDhdk9FA$U>jCG3j|@d2mvtUclSi;ZO$xTFCW%trIlr2OS64%h7I48*EO^W-'
    '|_pflQTJnDW^QI>%GsK31VIUheh|BUNI(biqh^+Yh*?Kxxh8f`Fb@xbw}q|iHbVf7Hs{oJGJ}4b6&f_c&FRa2NMR&x)aN%AIGc3#'
    'M6<c_C9|<$9{HEm)jK4A1+??h|H}?`5J||S=|gALK6-qb9&|f>|ad__w=-'
    'M0T{kEuA{?=M*x4(u1Wo6u__NzWRaKYvB>Q36UI}rwP$0<EZWHJT<!dU?ql;X#7|=!ev9u(=h|R{&aa6L$EGp#btE|UqwC7+Dd+j'
    'w^$g^`0(f-kKi?KUEv+}*+az91`;(%v(4dvmFZ6Ps-m6~@36Gt@`9C9Du9XJO{_$E~%5*Sj9>%(@b)^)4{q|$B6LUC&_0j@l;V0-'
    'RI9>YDhX|8EQP8(!tR?v2XiGDFN7Gl$X1R5MugOfS<72GU#otXK;VBXKgT%Spg;8GBMp%0@rjmfv7Jn!k9lpNKDVNGe7APHKLE1^'
    'HXK+K@*T4OR&#v6pfniRiihTpoMpBzHcT-gG^wL`|T>Uy9P9Yc+xS0B^6lA*B8}-BZ#K4at+IRz_Q`X?gq-mahte&9EHs}`J(8W6'
    'oI@tbDf@iBvli3{NLTubj{dP9q*ZS@B;&J#<ULDW}b)zZL!AI^~wAk(9K$VYIc+juhj)M(FlsRN9&Y(?!JcPYg4Uh7__AwNopaC_'
    'W3!Y@q6_pvr%#KE1qxtI1y{@?1C)Vf!z|W^bEf+qgzB`jGI__jZZ`@TG*5Fuxj+Q4vU$@_E8M`xI?>Cow*zE}zQ<@j0XfzMA8q<N'
    'y_jP#5h7IlA1<oe9<M*6oW^KSQGp2Jje3T$+BR_Km{<Cei8v3qec<lq7wJQ5Kp-'
    'zo$O*TGor(ynb+GHI#rG0-l>fG&Se;Y5z;i7)|7^uDw##~^h*7W(>>eJcv@$7c<#PqYFNVBi@kc1|Mid_f-mN?pwXyvA^1U#BuQK'
    'p97R9#Ju%~4}!kpE~t7dM|!ISB87=4n}JhD)$DB3pFNyTY5g6S}RScI+)W0p2zG)6ZmlG@a64z<zL5n(#)|g&#PA1o;nDQ<@Je1u'
    '6z_o|klIF@Wf!K?FaU$!%dgJHg@EnOVhiK(W{N?U4CfaoS2IEu&{^Ou;zw4q9`;O1o)aM&ka&oNv`y^+2~T9w%J^dc3Nd@-'
    'yoC_u;O=mCe-opM_T1&<j2;|2>X&e0m~swwD=iakW3jD*o=@c?3LFW8Oz`wql-&EvX%cim~69%A55Hex!QM39F-'
    'rcLE0S`S&8;q;Z9NGDeG>G<5a7x-C)SPESX~q^lb}Ooabl=C=cH&)vxq+^*hf>1_(ry$rpZ*@-'
    'c4NhKZv^QT`?`&%y^=z1rpEaA+bwZe?JQ>*pALpx}#M=|hP$_Tnn<FNE0EU%>gq4sbyfW2A7uNC(8YEk0(K}Kp|kVk9-k{T4~-'
    'F+qOiM2x(!;3|K$NA{-'
    '{2j6(coPf>g`@lAytkaYSZ99!3YiVt@+dmnLMcYCx=X!>d|X>p4DzJc$d6Nf{*~UNdPQAxCVd@mmkhlLFme5=-n-'
    'ueM!YT^aoTMN^8w$XDu?9(G?}s}kBPnJ%_o}4{~M6HzpLos*pNi7nqD$`u`KqfPT`1v+(%^u%4VOGKG3c6=I$?ovAZUB*XZ$@tdy'
    '_)?#>Q++T;bZ?P^dG9CSiZ$LvogX>q|}2v@{0e|{wQZ%6Bpiy6I$A9hysQVY#y!^X|tk}Yrz0NIoCo{8A?hNq&F##wu2@<7GeMfL'
    '>Rwo)K&0R6$w?z6#+pZ&m=3Q>rZ_Oqy8lf{<Ws+F0K;J9H`(Wn}X)%&Jd!K`d~`36Y1UEzP1l^HtIR8rYtBkvNmVr7Ywp!ppq&T1'
    '2EHRL)NPx*TPXU8-XaD8$Z%;U<g-FN4U@25oqUw?lwPe`MR5AAJmjnR%B9}fIRx>uECnN{Z}=%b8XX8IGRdE;o<Hm(s}X-'
    '|U2dD8Fk)Nb1i<wHZ_tmo<(Gq&Mz8jpA#^?AIsNId;JyaCSJx!9Z}&DDVJlT!Ja?vFtCmV2K=chK*7?&rBWIm-Ha`;qo>+xQ%j#y'
    '2}MiFc1zU_2q9WM1`V&R5{a#wV|N$+t_&&c)ikr9F>uttHVuis-'
    '3WwxoE15EVDlf?g@&$#pqLqM|*uzSeRKw@Knvt~vI<u40`Di?LAdzjQ`?MOgnEl&^9sd)$0BZQjcjc!Sp$2DfkF$E(`A>HEv|1$O'
    'f=Iu+;H;T~rD=?jkqnKQ1f|Fwd&qcPZ2+8*xj(xG$SFLyg#&Ud9|v+yU>UnrcOk(#GH3LP?!+oQ86DSOU#F8f=sLts5P?ti(UsTQ'
    '5m3;c)=x$!36`-T#iteQD*`18Z)CiH5<-'
    '2%WPS5=Jrv~{RQkOane)dA|u>tEUGFoP;TT;A`{aNQa^qn7?Z4e)(y`S3hYg_MA@<zDz)UCt@Z#d~^wdhuPJ$>Ywwu`ogm8%@+pN'
    't1W@(&5YXd+<<=hz}rR{Y|UfAC4t>X42)h-sOzf=kMo_z&eOf3yTx8-ti|o)mYE=2XSqB9dMZl>z6oeIu-'
    '}OsEN=Ub^Ew!udD8>zsW=44dy_=?|L=8py+tob$QOVSkipRO%*zG;X9?o>->~$m@;ym4q0^-'
    'qZAC<;&DBwFFo|fh1hT~N;!Zm3~z&v&H1?Qjz-H4e3JwhO}7J%FxV3-'
    'v$c8AFe(t1UdaQs=pk9~`A(4`x0sTA@S1u!n^>ENYqSOtAi=B5xhgj$(crK8{O6TN)z6{^?_O49@<*M;5WM`h_D7Mw7Gxjk8P?7Q'
    'I>M&Ed5KRSYGN$bZ9<CN6QNyGjW6@-{t!*e=4E8MgthvdYrR41QhGlpW#Ie0K1};8Z2r-'
    '34f4%~qiF*NHu#ZTzaz7gnXwbzE1lD|XK;Pg;YE68++REqKR}z#^wGMq>8iq)KU~-'
    '{>#0+CxfTb`Ga|8aRG)rMlb62++pWPGJS&>=FNFi!_5Rqo0J%LA#M8GwWiETEGVwgdo6n@bDxH3bX4Gi`rG4@RTU%kiwC4oWOc92'
    'Xqw^L0D^C^!t_`>e*P)+ng^5C>7k{;6_*e{j%|fmJ6R+F`a&K_1^Rz<0^3h3ybKz!0;+$j4NwU)W@a1V#TJ5mFR*~GewUi$*eWD('
    '8r1i%;<}c2dX2xv&=32Hc4&G|5Uhy(IAv-'
    'l1FUEv0cdRmTJb|=*1>$h~HLjO}9WR4P2~WYU7){_#J$Y~CTJtz8bo^6c)7|oYGX6dKvjr`*7QWlG0=4m->V6BMs!EYm-'
    'g8}vfT+*e%RN?N6SE>hhZAME+KM1}Q8s>bQ*a!YUKYN%F1C{axH~CDi5SI=8Di|#0jhpArQPX4^H;spKe@0ORW3@#mrcA^0lNBxm'
    '~;Yrp;YbEpBPOv$Hgs$>o0RFm0qjrmtP*MJN_Rdf+~~o^4;^(36A*Fbo&Qh#KraAW){;|v!|usExMSGiw^7dCq9AoxUDhDzT1wrN'
    'anNvS4_tZIf9O0U|!o_daZ7|O(h3?rWpFROAhuZT>dw9+U&WF$p_*e6Hki1>e2g4FbE=8)yc$i0RAYI<>{(&w4FT+m(TK?*w#PN<'
    'FRA6;g&vU%&YP&Aa&Pv5cMVRK&4IV$MX7GSMA{7mfBy#8vHXCk<K9S!jP{~_A7Qi(EbYk3SwL3Dz<~LTJ)*9`Q_9!&HAQ+HU)hZ5'
    'v(<2=LdsqoDRnlv%-JviFO6pvwo)BDZ6gK#ES6w0T+p8ADCd4Ufw|aSDKA5O-'
    'b&{&aNj^;~P@0Uk@_+KFjA;@=)g#v%ipS&+BXA6?y%1*w2zMY>+x))!mog8g09gdkLBHoosRE&bpZ?6>mMGXT4`LsT5Jb4%hJXg~'
    'i5X!+Uy|>HUqzZrc0fYyD(3@u@o>cY0+uTjS0(d8g@r#mhhH=+O@Cj!BrO2{Kxu&#}1V>9Z_4gBu%UC;l5>zumCSd8cYT7mdHef^'
    '-=8FWe$NBWc$;Q=xM|JBH;iewaZ|nE{yjlA_ygjqHb{OR-8u|NE*=Wfdp`=ox6X7HYh^{N~19&lq*PZ{2~?B8F2wIdbQKb-'
    'CG>Sggz`jaFD`V23mCa<ipHa^<o!r*vX>@+n^CXt=`atZbje=CNN0C#CeyY-QkZtMzX0%g%t?-'
    'SWe9wEIiM@oJt8KynBkYyH~2mi8U-'
    'acqM3Ewi_Q;)^dBeF_3n4>oT<kztE1pSscWG1e;nYuM3mE%mBxKi%HBziy#z=p{R&znj1BW+j-'
    '+@JXN?1T%h%L{vuN3bWlI{Y6zx0@XWCBF)2F59FN|Kk(TB3#eZDyQrV%qMN_4WV)s9+2$@mGr7%!%O1VGtfo<Iqki0@8BLb1#%~b'
    'U@1f_mv&4J#rZ8?*qAPxI!14N(d!(K#!6V)#G;A$eVWn^UdnOcL3!C7cfz7i#&BW=07?7}UL{hdNB(^*5cN~445XT%5*tNWinWNc'
    '!mTSlv7-'
    'Q7HjY_<I>aX{o=47~?6K!zaZjbWgJi*c%fjnj%Y&ZND_#bp)7n|SC8PT@lOGm?=@KkWSfl;t+HsX=ebXBzccj=+5EPL0!ExO}b{;'
    '>ju8l)>nsiUTP6wIg7A73YKX%nB&XJgz7hwR3`Gt>iLB1uGz{*J{t<^MGmgcf_sHBCk?)L)uc9yD+=PMpHH`aPsJ0{QYDV*S3@+k'
    'auU8%TA5d?eC&G0K42O1^H(wp-'
    'G>yj?np2hN*X^Yi#)77IiTplyloy#VMlhyQ7EZ&NSl_KvypmNEOK58P4TTCd%DSbg|4gv7eDqZ(A-'
    '_7_v$3(#HFr+kY;#f4uc=?749-'
    's7qO6~8I9^zF37rg>wXaedo=);qLcNbSKrReY^J7#)1;2}{=z(+<_!DVNTJ8QXGy+^uc~9+3S(>BO<8(ql89<>vkPcv8>BD>uHNl'
    'NmzoGGHx8|0_J5*=WO&MH%VUK-BZT`Ift_IM4lg$)dfMTJ8j8Ff@mkDZ@TqpEEdb-pcc9<@?hwF*&@4gi9RP%Rsw0F1+W>YKhy*4'
    'NlJrKjV}O^wRR4z_#xb*3w*1PL_{vpIw3?HXaIWJ<YQ>eW-'
    'Q&PYHJfQX#c|si$;D9*R6RTx1{Yf4q;|HHQu7v$3_$egdxtOKg~EgYGWRNz!`M$@8P#Clq$sBRv6!Jd`wmf$Ac8t9l1Zg2mxbEh@'
    'doVVPVmIj%2_^;EBdzgTW)^=u7g<M(dO90g)q4c1QK)XsPg${;X28{-SVv|8KKRsjDV*C~h2{+<`MgUu`%5Nz-'
    '>is%H6s?fl}YSi`bdT3>K8L4#7;B>rGnaL!+@3EbCCfNIMa!Uf{LUf22nPo|9_0-'
    '}}8pyS@R^g@iJAFq!GKME8V3+Q&M;6rL@1UZP{r)%6ce>xo(;lL2@96F`8qTly-'
    'q{A@&!^d8nl5_d(FAP|X8v55>UhmvPA7`uXvg;B9&5{~sRbt`zQ_E#`&8w1X}EN59s0gm>z2C>>JdthSiJj>uE(1A<K25T=w|)39'
    'HUdduPtlsu-Y@u8#mmKDw-65YgH+P)c|a%6K)jR#0K_~%}f6^fZyj`?%(Q@@@!D7+F-Hs+wn$;Ki|vZggUGTHmv8-'
    'Sos{f9J`Ue=)KG3Xvcr&uHA8yC{bIlW2@onPx_p*vh-'
    'b&?Noa?*8BeVpBh~N7XG;pOo2tZpF%YaSRPr~<=zvq|3#boD}O%Nb3N!~3d0X$t+cW=b2aESCVvoInl3*3BRV<ms^vM*hyLO`gnE'
    '&_?=N=`s5$5-_ot;c%0GI(zsO}!Z8q5eWMEmTC0{dU=HBWn3M(|JxBW{Nok|_5c3SV?6Ddi(V%V@&in--h<4Bjf0qS(dLiGJB_Z^'
    '3sopsPw)^C~(Z2WX9r`DCc{4DvgFc72F{k#Y%JVg5dZ*^TJo0MIET}Q*Md0DHG-'
    '!fYPIyM#pxi$*asL)x5oH3yS0L}Vh^o_ib>Jh*x%irovPD<ZV(738UxlyAv!BA<L)yB+D`A)aUVT2aybiFrw7o1w$^D?@g%N4s>o'
    '9sXgt*cU0f0C^a7z`-'
    'k6OAgQS?PCRh2@@z!amg7&Xuhks_ZcUZicP#vm*VoB}NAkhv@YvGnnStO}Y4DIB)>0Ow2u=A`5#`nd0y3*vpT{X+i_h!nv%F&Bu2'
    '-cpA-`sM)KfsgrbBVFK+HiUsU}K=zF~!9$;Is&}5k{$JiR!NdMKRg<(YTjnxvzN=W@RisNUVeLBWvg-;RJBtw*B@wRG-'
    '*GbB6mx#m8=s??3sXnCkGssS%2nxc{yp&FIIOx+G1=m`WG@Uku|)opc4UOu-TKg`Qt81*Vj=Zwi{Z*XP?fA87Fn=wgLwb9V<iz1A'
    '6tSDuxPlu?%f~_n7cMIssJtb9kq4?9SWCM3%onSF>vjxx2xIr;_psIdw2P<sw1<%%1bcz`ENRcSk?EB`-'
    '<cE8sZ5hyG72oTVdmurNL3Ri5FV}7jmUGtuyB2FvwlRv0mW|quSpNnGEhY+u_C?)JeVCWzRQ{lfyV;D`${_AYkZVhmSIr{@In8Om'
    '`?4#!zV*Rz=!luz*=LF;NBg9!j@-pLI|D{h|wk5wRtjCv^FqUQILo{rS4Eh<iN*AlC1rfN&{Mm-FRU)wbtKWagrFxlfgK|MhZ8d;'
    '4A&LeqGaI%_-LG{((_$h`oXUBtCCTbr-'
    '1w*)FGSTgj+>tcDU9pBNp9hv{@Z0!)P*|Ey(s2D8SlBZpQeRZa5Zh1#W1<f0T+U(SBjI=+>mm78MDNE|Z)d^JCl-'
    'X;S504{!>hET+UTHy=xKdYpipOk>Y%Ze%NVfB4C@lXSH3tv7x7M=Tm#gP8uC<TX<0bVf*B@=WHD22($U*Z5(r?f_$YOTyO{iBkUm'
    'gJn|2|q|p8+<z8}()y)~4?cueMOG#duJzJN@n8+$SVNzEDsrT>eP;@z(h4*3XX67Ki2Pa)^@i@35?^VP3~4C2KM#yIYt6W+e#@4Z'
    '7spo3y$+Cgb^Knr)M9YkN77h|M><cT#u>2=;3SPg+_Ey8_Ot+&MmFZF?_Y8Tq<MFD6hT_X_HDptc#nucoOfi_h1dF)!f>PAB)?c)'
    'lCBn|_1=I}*z<Pg>PMU|s7zYqQYm<_?k|lh>>G_uy6oXHoB9$VM7uavO5h%ec6{gf4D}eq*=8uPZ=4ZOZFgKw4m|fwx`})r<c7Dg'
    'Awxf>EU--yW3klH;uU@{|>Yd?!sYzd2>mhCVpqdf)sf7LWOAYVTVSeEUxMPU_#i31!lJ)!3z!Zg^TWV~02f9?xElFLiv2aNkXET9'
    '{VleV??<Es+S{>$-o-'
    'hz*{MO5LM;9sW4T&(zku(4JVET}iuo?HL3=Jn`H<z4QF2Q<5W63^tXo^)u;~4`kHrggBkt#A2C#ZoNgbRFKeNDkRIP`}~aYnf-'
    'o7;?|Z9<rSDqdr%7h={2<>V6W(Vm%Au);xyX~X1P@9ZaX}O|Dm-fF;?ctX-jO63uHYf7q4{wicOIb0_J>aLXWY1k*&3H<W}71KNF'
    '~#Z3(QJl+qzdO-'
    '=@pO0Dw0$%ZB&5VAIl1}ib7)B5_%D`$YDB<8T#0o~CBcgzQCF3iSTE4?1q3ye&5w*dV5^ko7F@aN7hMRaz#VpN|Ue)D`-'
    'ijP_IP#@_=w0auJK>Qg<U&ai>taD+6y<=D|W1b=nFk;kK3upSR`K9`4{RzNSn4aK*U<M|Yr~7)1<N^TI^iUj_3W^ZU)L6)rLyCOo'
    'V#{}Fb>UqIQ6}f{ux8BvISdfY>C<bZNm8X$pFUaY`Z;0Kbnjk!of&s+f6_H03zg&V?s8OQjPtm{F_@o7DeK%H3q5jaM0w|Dq}L41'
    '_&jjCH2{m{AQ$3Ow4dn%@p4%o__?x^mY$02PRVyy+{=XToWjf>eJb|oeO8!vZ(PA*3;7X6^hENkJswA|oH~e~hV0|^;8uGSHEn(R'
    'lzuuk#om>d7^e2<vXZ`XvRu%sY%cmAx_NJEAGY_>p4aT_kFnM&rl-'
    '?WJoO<|`?UHBB!`Vm?>6W6kK3~E+19Bf;gZHNj;N^`2a3dimHU39`LEf`z#T9?QA&3uxa>q>bcHrQ0t^i0#%-mj-EtK2UG-'
    'i)NX7ag&Fwk{)uG}qO@*v<J4YW#Vk?3dr{W~|T8&l-'
    'xy@lXFJ0S&=09(zH~yPrE=3V)b}(*IA6QNIqVU4RH(K|dZZz(vxxUyAQDrR*H`|J+)oaJG6VB4={dnVq7vvlS8ToB!AzQaFW2U#A'
    'DoWkqYNQ?UN`bW27ddSoQW3>;DP3!|um7F&TxHX4^U%w?-Jan7^A+!t%UX~m2s0Altb+OdP?Kwmi`CYpX6yQqZ?-'
    '6pAOCJ73`~x+eVh)kOau7fq1Z2U7|7u#ZhjxY@f`OCle(U*+@dm~4aBsgzQLUwLmUP3j(MFR)0KCkeBvA<$x?pt;KCOSYxUALU4>'
    '{B;;Q9pzh%ScUh6qq?H^CD(=qS77z5eHn%7FwbKNO3mYi@mVbzL^Ap)FU5?!u6ZSe*^^G1JT!|8x9xlIvpL5Z+YcK0oljmu=v7Wv'
    'qjeT)A#_B#JiuBGIc2D86eP``ZXEwo+3Q8;Gj(bS~kUo&^xKUU^PcG-7ZmlIlK@eLVBuu*PYvtR-'
    'w)g85BQ)XsK`;^`X9TNMcm(nvI4wR<}p*ca~2S9gc!po^V>h$?kJ`c5C?VO}MZmHZUN|MV{-WdAquiyZwlR-P-ZJoYP;o+MT4{CA'
    'Q%m_s_HDlW#2rj8>i^llXo&Sqq*V=xynXt;hh$W^ZZoAfODai?m8**{`oa(jDn0>4o$h=oYv6&|y+MChM{SB<`9`M;Pr1^sTj<&C'
    'zbt4<-'
    'lS{hC!If53P?;dT*f)TivuVlVo9E+)RE<DCNs+(zQaH$}lZ3m&@^>bsgj@Q<`!jWpR*T!r=a;nB&jw_dZUvL*ap`p=?b09SzFh9P'
    'AiU~RH!H~-yAJsGV1Wk$hy%d7XH!DYEpx#TmRpx{+MZ>v+2gT!z~8~;cl-'
    'q$6Y1nHn{egxit#QG92PbCk?YiuswOicTZ683yQz%hhS`omU;Is)VC3!)-'
    '`(Q$(`0?u$JH&EH{4(kzrz0HfKcOtpwBAC>Pk)1lTcy%f8nqvE>{m_VAYUya>_&dQR^w2e!o21KzGY>rx3I{b)O`K-'
    'zaU`t{cI07PC4tfwlcVDfat1oSqnzNt-7zDuULCE;H8@td2iVALL~|`-zLoV}nIY>(RJ#Y-'
    'OsgY7OS;nIjOIel~~YYzvl8`{y9rH}yBT??<XLU)vC2FhSCm8gq&`J&MD4{^q@>BjFanb51*}JyS)dI!v#X#3(TSw=Xv>Vzi;5_m'
    'PY@LWDES;I^io{oX=IU11I9?_=xGxs>4(4AlJiq;T<8O17r~t(UPa)FU4Ut`4x6I7j6YF5R&6-'
    'DkuA%2%IRI~e*|Z&&<tc57d9&cbo<EXo^#B;~a=4CBFQHcWV_e(wf*w*h7b<z2mJ%N;O$cf7rc3cX6jbk&tcK;_1Ve|L%>S6*U|v'
    'E5|YvSRD_x&%F-4DRUAZQp*Isb4L3dZAeCKCYuqmeyr5yy8+fRx3+Q*i^I0hzzJc-'
    '5r56aECxPI2~#IHJ@!OrBGP!zua=S<MhvcMjgw)7Tjgjfw|l1O8W9Px7+ND#_BqOy=t@GA0{#<Nv#2GyIK&NO)(LhotHbUw4S}j;'
    'GKr{bI}q9SXFQTx|!=q{kZ39?flxeSj6%4@1Q@%w&RODFY8S#$&y9`H5d+``0t?sYUP#^F%1(Rnl+S4Y<`C}@cm;7&Xxl}+MGw~t'
    'TFV#^R(k;r4ihnW2@&ss|lIKZ@rtyRLGOLLhuP&?~RflDK;UK@O}W5<$-'
    'VJo5Z<Nt^uA*ZqaIj8sP_TWW(>1z~T4@VvOT1>p<9f`G+yk=KXsb=W6ddwz_j%Ii$o-'
    '!!`H!VVq)>_M81~oF2RNC98pl$3<HvjYZ!W0k+sN6EFQsu(eIS(Ew0vtOEyPO*c3i6Da0IHW=$T-(A<eWD5FQ+M$_jFA-'
    '%8MC;v|#s6!P?YT1T`AMU1);F~UCD%mUb9Xcp)Rky=1q`Jab^h|<_;}<-'
    'yu^0Y>=JsXajCkLNA77_lJ~@K3jj!52_+bOo9w~P_*Q8}p7y7$3me3}gcY+|e!<TBzj_*ToqAlXx1ATEu3N&M=CNUeP8GW$(eTXm'
    'N`bn2O_z6D*8VaF7fkveS!SZM-'
    '&X&z$IlRq%hT{oLo$7Pj=pF|Mz<$et&Y^ojkYvk1od8raha&}4vOTrdy|4TND#Y3xV(Rr`y<CR>tshiwWX0xd=KT{F5lMmQRxe5w'
    '`(mYmxZ^=@4{t~jIKWRD<Ig)4hAz(`1{$5fMeVHL%ohA$hYq2<%Yb#+wI=!pzM;6bDxmSXLXAH98`<Hgipv%*Q!o6hK;a|#Ix73R'
    'gVs(ht<H~3;Jlly)zEH#@X#R*w|6kw08N9Zchg~n0iEq!fLbreEq>U^m}aWc=1Dv+~bcMaz9(ar}NYrvCV`^Ol9%~$~tSjW=Z~Z-'
    'Pfr8^<cKyqkG^R9@(4=!j09n($99e+Sx5BgE*fu-'
    'T9Osx|D&Pv_{T)hszFjFZUKOct1Z(k(k#HrI+X>#)$vV@bG$)>S&3*&#slHVj63OGyO?8+G-h|V!}vz-Rd2_JwLj9?nG=<3o25in'
    'rGlI;Cl!Ef($F=a=g6WhtT<b-'
    'PIVMIqXOaz|q=`l`Q$Tdr$t=!ryXvbyaFJgPAuVeWB9$YLs=gOlpMcFiSw5V$J`Y2XMULi7mznu)w6H1Q=fi^{msQ+8>10jrKZLg'
    '%cX>jvh{v*98J@yc+y`Oln_o`R}X7!P>nz4-Zy(ZIC<(^7-'
    'J^onMOH|7mG!4fyq__W)J^+xFqsZRA06Y(wx}$)tAVSLjAr>z!+xM!3>;J5~n0+jJ(x!|-'
    'XeXJnY`FJNjEKSGsy&irQ4UEMf*vDfzBczhlQ*LsC%Hy3yJqe@=b0{uTQ7j}>*lU82xtT+d&&kktZ!sNU*yh?M7w3x*hJ?|NjHeV'
    'H`qz2{3Wr#0_++gre1Dn;C_)6A+l|pn&q1?ZgCqQsI2<B(OcV~Xzj0tqtz&FeDcq4vE>)H^<v&|K_h?8q~qqTuHU|EOF#6O``E)2'
    'a(^%5XHTzl?Zm&ermGSB~MoOds#0l}N~zS!rRs7{m`6o41c-70EX5;Plod~8P?3LX~$%$!y4hJev-bva8OD~sfA*;OLr&Q{c5V~4'
    'e)lr@wq5(VTW%D>dGbKW~4^pE@&!_uY4n3OgcK00X-V?s`>J-t)vgQB<$Md=PJwISs+k<*$c-'
    'tVjVDl1eoQ=+j`fh*?AaT9h6Efi{Ej9XXr(s`XP@q`%e_ZHSPonOcOz<o?7SaQFrV;WiVl54}EXKxC~A9y+50pu~Y;>Sk`x`p>gZ'
    'zS9<4Aw7yWA`vlmQ>p>t)XsCjEy1N`i$YB2s;GGr@WWfW|!I<J&%T6fgv;CM<v|)9o`qFmy-bxo9j1vZ=W5ToM7GC4IR$M{1c-'
    'T)#_GfF=;&SLm_#f-|6VyfFAkUFo0j6PSaVrET*1(N{p@QlxKqxp3>j7H7Wn4VE^Wi$c)ObnEaQhPL;}`I_x-'
    'T*Z2!9_^8(cI=fV<^!9T@_;ebhh90zdIYGJGtAG6MXM&5p9L-Kd$jGT}&QFJYJuG=>UN!IH-'
    'R>acYq(uz4OP3Q0NKUI;23yZMFThM<*XDUmuC04^#f*HSvD)(-Y+-'
    '<ipm^Zs;}iGw+}j~&47rTmy!Eovwm4@r+tTqH2plU?SdopP4cKI@lhWekWD}PFs7N-'
    'Qmn0&wLEXu#Q5)x?&`t$;i%qFTrQW$Na;@gCC0zH^2v_n#k=(l-E=S4Kg`5V%EMNv=?){)|5}fSg2(I}4SI_-b-'
    'IUi|AjoV4b&)%>DsK-dXK?0RFTPcG0R02?{3m`4)^xS%Ao4APb`xEZlgE7S7fnda;Iy@Zn76FZn7d-2C8S2>|-'
    '<nPiLO;Kt>g;POweB83lbO`Y8k81RXgB@$fT~H<pLRNfs_PG~|Kd>+*(A$r%waFnssU=Pq^T50A=s`CRoi&6k+DI|SZxiM$Ms_f^'
    'mWmpATytu^i&+n~r2B$aGp%_{M4O$324pjTJV?wJ$K<{)U*%S&gY;o|9NkA96avO6)|qdq+k6ow+bPp{ug{<7F|=k1jl$Y_Z8SDC'
    'EZ!n#hEP)#~t0;5(5gD<kFUuas=ZAD??R96UPGRnavwGY_Ey!BTC5g92{j%{{-Q+?^^9$WdrRFrDIe<n{hEsi_-'
    'K8CHPx0@MdZyJ+-SnJBQ(p!o0wISD<?-8r;cU$^$a~nl3Lptw--ekhi8>#K>9^eML>X&N-'
    '+DR|iyy*RtDp;>?s|8dU8M7+$jA&{ox;|*;hIVcV_oRT;xKUd*G183hH%C0IAFC)g^X0j9gSx6ls$d_M6Xzz+z~6<Aigj)6f>!9%'
    '@9X6pIaX$`(;WNUSom6+h7BxlxN6y(jqpolv+1eIbx<|*#aIx$5kVjyMyw*!m4iz24QN+FdAsQ0Kbs)6dB*z^vcJLXqq*b7{bg5+'
    'o2TztBTK+8^XAD!@-'
    '_`@j~)7b<9l9&Z*J98y+EBLZGJqvZYq5P^{3nnr&~uaD;k87x#RDQ8by>IHKk_!PpVeEE=r=)DUlUfP^DS7t1h-'
    'Ky)y@cEx&jI)xOR2UUPM|DK_|1!uLL@OF`MKoz|o$<M&dnB9DC7^5RDv6u&SPRUD~kt|G;J*!`^;mS5Os*9x@B{4ZE6{-'
    '6$MM#}!&8c!CTvps%_+ilkw%=_xsC?*pDX#d*i#KGl6K;QQ0TbEPz+Ty0npvmA>fE|6U8IH>sg|?OqF@;`9XN#TKNm?3=zw?0wdS'
    '1Fu9}4o5hQI${*SEguG8Jo_q$io;n3=W=6twIX!ire6HsSt?-~k@R?IRS7Z)nd!C;Dzs9aVFtzo;x^oc7}zFs{<`O-(-4SwDF-'
    'bP1HzL-{A_diSTS57yn=vNZk+uA6w7?U2!Hv#5hkn@c~lg<I)0j*FP?m4gA^`dr|d=KW<wcRLjP-CTEb^&o`HRi0J|`a#?M@Ue%I'
    'QLx6_5OC|a#L}-t6t729e|W0nLs_nn_xSKs<81TI=Upbc<(-'
    '9joKNV^QI8615uG+rerf5w!`n_&d>=Dg5FMg1ws|e=3FF*>y5bCO$HT4<txYtj559HyUk|oU9{Kaw=aqsbONCTu!^hvbX3hH>xxJ'
    'KLK8<c<-!a*c?h=G{CeZ$Lxa%92Q(i*uhZ-'
    '!CfQ45MK;}1U2HW^7^WGGf^<N8VpkwlA;5nbQIWK*=${e1tRT*j8!}<gC+aR@ES&9up;B{iVC3tM1JvS<1&v+*#dy~f1!C*ldQ}l'
    'xjZtvS*=2^`n*B(s&vhcH1=_c;W{^#{jU|DDT7qAvwUXR90FU<QX;jfk(=yLrOFJaZ(&ZdMKFYRt1c0-'
    'QJE}Nv$ep8`y8=b?b9tw0XoSj<i^ew@fyZhphb+#E%WBv1PdPvJ>;$J6Z8*F<-`t@_Er_RHb!vx;*o?-'
    '=&^(%6y;o!55b;0QEYp|9W$Mypt)_>(kMbi8*s7J3!tG`lTaJM{rPYRp`>K!~Uuj*OrjmII=NbI5T?<}NmW>U0}uXsqS#%pz`_$m'
    '9S9R6@D+@nS>N+$#P(s7pP_|3=q+c}R1gVk$BUsouO5^!lDE}K)LoHu#WUF~<Db0;ya$MQUfv-ScQU{v}~y%DThLx1knl2n<czE~'
    '7<&D*S6i{$naIsiDjR9@8awQQ@i>il_a>kdCgr_KDx_Xd<tk!=?vzOkZ~pKhPKcYd=KW54Ja{<aj3;uk~=f%@|^2$IV2r#Lu$7gs'
    'U;V(OK1+U>U2(|bYib>kVdyJAoCwSQfGbvL=_@k-'
    'z6i)YIm7MJ~Hu>(P==PU(bnOkl!gl~2{ondo1uMbqdp5D7z^ZV>5E3E!c+X+(cGZ@_LqSLzGYbE*b;AQ$YMXx%rZd}}-'
    'fgO##*z+}yvdb2+jN)=!L?Kwhr(HRarUZ)|X#X)pxNdwx8og(7KU6Z&I%Pt?yPgVUOpe8DRDEnnyP{PSk)qR)LuP(GeChM&>udiA'
    'yGC>D0N#ol=ATuhpRn-'
    'f^|R}q?AtcQ*JF9J5a%!8dLou?D?Xu;!J*uvz#?!b?hW`>7=%Z)Gkfp$JDgTNrw?t?n3VTWsZ8#uX?BJO?xg!93$9eYO67zmpxY('
    'imBN3ky7cRGS5n2s<1D+U5!X&CFJ{HKstBa(u_wj)(D^m5nR{geH;|BF9=%dm2Zf%FebPES)yZ2w1*Kf!>)+AUOoqeGp+!Pey|*&'
    'E(S9MfueZZIUd>dmJLl>x-'
    '9O8p^hV$b$H?gUkwcf%;%N%E{#op;Mw+QX1Y7FFl|7O>r^S_nirXbPF+Uwo3pIt#q4L>@Q+ie2QCMG-PJC;A*-'
    'la1T&(Ma^h(~*va(IH_3IA=^G<p6DoZm^9c<9jL0{PXq)kCB?+@z;wrw<k$Ea<NbRA*~jNR+a_@4{&`pEv}r<%X3-'
    'h|g@xO|NasrBKdTZ2LCT|<!uuc=f8+l>u3Qj~=8{tmz#?{!NZSePz*YFrB-XJxxm<L-'
    'OAD_U;ApG1vk%UzeP*y^U$FaNuT)ZBlH^gLRPs4aqu$c#DkjFu;}jsB*aTa?khfGkhJo%#9#e+Gw<iNf@nYCngQrY_;;9fUrPflW'
    'c;@Lx76Dy@KhqJ*F?%2EEQtQL&$58;jz`$1m}idr}Q^Qh>0$NOM#DYS88=n3`E9cjI3`}(-72tPcx-f!_$xl-Jo?;Hq?T*n8t)~o'
    'FfZDe>0ygmzUH|n~SM?Sbm!&3v=G=JNLFYu}(J)0M>QG*{@{0C8vPyW?HFrKWocDEtv6+IJVTx)kgDrjG;Qdd+j*0Xd*{UA&o@U8'
    '@5Jt?}`Qhg^2TI~)bZ|~j%+(K45Y1-=TTag*Km`zm{f<^Ntal5VGqZ@148H~yYuxCVvZo)>e0m);yJI-Hi5U-q<*Ulyrr?u-'
    'pFM=uGY>nNIO`aO%30<PQUX+dKJ)CE|GyAP->I&-'
    'LA%2@QVcQsKzGj}(6I#krzxK@&g}DFdNcp`)>?@0Sih2TYn&KlJ)HO(f3w|gi2|zFdWBGYi;2V0U+Q8R2^y?9_YR<Ph)8tirc^o#'
    '%b6*T5t~u;KTc9DVR=cd!s?oyVF~9eZwSV<+giYq@1JHYmy<Vg`IazpXFaoqYu$X&=V-CIg!!fE!m-)}cM^CWs0>h`er-'
    'y4TJ=(A5jOy2F`rtX)W!CsfeF4c~@w~KU_OS>*4m^ON|BPbZ)*oI3VqB_mOFUx!E<qN>SLM5VS4?mCqM=p0-'
    '^BQqHf^r8PDQkUWP<c+BTDSy@PZr)Qx1$ujPdkV`8iQFF)FoIOXwnKMT0$YeZC9*qh9sTOp(*^z?jgLF;;rj(-'
    'Z&ZUWf5}20V*BxYxVacWq-A-'
    'Ps53W(BntHpk;_gd@|JyM2y@R|5uZqF$Y$xGo$&vhhFX6D%t>i{4Y&JQveN?p<3!Wd~r4%b4taZCmMe`C=;5MkU-'
    'zNKbRYvFbeJc5{}xyECmd3F^ezY+ZW~=l}D=2Cx&>FWv3A!KBPN#8B+2SM)X1KXBIa22b9S>Jyy-'
    'TTvs;PM7V(p=a}hO^I?aEZXl))Yu--RcG`#w|3`SN^4O+(KemE_!?0TJ?*Wre^i)WCl`&nL6~E^g{`_nk>n558E1wj*I>`9_14(Z'
    'TVc9-`nB2&dim4<U>1-7;Ug6w^j2{{?q8Ku-!NVuhVgy*MG+IJKj`h-'
    'Fo`9vAH9l@2XV=aX4G(>w%6vew{`}nPrBYk$q`ML>R)XXp2NvB66cd6y3)9g_MDF;iW;t;({@j-'
    'voX$v{qh6GeLdYyX0|c7>j?j{j<o#@zT55dpA+czd=O_!LWI-'
    '9sxCs)rdE_s+)yE(i;8a04&J;8=vK?uwZk)J4uf)kjXfkN<KG)NKhOLcbKm*No@3goG-'
    'y9kT_5$exrDr_YnOb^<PfB$|F$K&n+H|e4w^r^U0}VIMc}>cJ$kz<@IhVqVARm{68XCem-JlO_zxYe_v7jHfv2@|SVMu*TbtIFtX'
    'a&!&FFIb+E1bmt?OG6tn?PU=NOB;L%HT1wO?j`b4`0~;fvXW39Ct;N&IH%zA7tB1@AsPqdlccSx_DGs7#+x#m}7u^vJKoelu32OR'
    '(7X`lGYFn)K^BgdSZIUd+gHBc9q!h>dQBel#oJ<G(SArL%BJfbi7=x_4ZygZHp*eg7yfJh{td!TPHY`_nfgG!JXO@9W@Gd~KBNy<'
    '91a{=SV$uM7PQdZMz|4U%W?8U#w?%bsv_A^1$YUog7<qs5)5bveP+1x55;2^9W)-'
    'F?b4K<sH~bJ2g7US+w()832h$TmREh0`_zXHOU;tZ!ZqY9@5QfEVko?6#@ewc_RGY>&#j@aJ@9FjHbIJ0fOly6pN-JulLhb{{JnZ'
    '5r0q<8ALklrf>&9@7lkRIMO<NgjEV7K8~oUkOKjyDRlyNV}G~S8EcQ;Uuuu{PA&S_!jxv+=i`xefzkniOY<8+^ehphH4IzR#+jeV'
    'r@6#6+C{PDpF1dIH_@3MaY$38LKrW(+si$sOVXQ2iC&o$~})>MejH@I_`-YZtsdkVPZ+3g$XPf`|_<-'
    '!ICiTL>C6nj?eA8$JehC10wie)_M!?tls6@$T~iiChwn`6?f*_-'
    '7<de%XJQqW)Z6sYS_$A?`BoQnaX`oZhpI;>uotYZ)#91mHU;x2UHKz3KFK%I#(JLFcQCuM{N-'
    '^{bAXo=*{<DPHt7Y0g%Q2{9jwwb#vp>W4BDb5u$d6XIBWt5D6k<KPX?U?zvkaZuaqv@^(5eV_@+cKkV207J1JG`l{c12ntq;p7zc'
    '%S`BHfWaa0}U(Lc}bbL2UD3<SX>?EHV>M^`*-'
    'jfMmdBdyG>eG9IGxGx+PL;Ix<dvT%1ew=PrRZ=S?X*+OP9_sDon7U__3n;o%PM#Ou#40aTlAa5zF*)+2OqSxwaUj!4jjPk=w8SQn'
    'jFnLuNu(s)%qx{=OCxKRVr_nlf^QPK|P(6#L`^dmQH=tgCvhGL*xB*y)SmkodH+N%FkK*-'
    '5~Yk45c)EKYYnIVty_Is`2iXuQju}8?6O!(LFPm8cW}9nc03%mF|umOn}pNara;6(qsy;=l-'
    'JxWcZ^@mBg&@Q@UF8J7;@7jufa4Re#Ba`f3NeD$Gv-'
    '=q&e;o(9+B>TPyV?{*SCG+~9n7d4!z*^!HA!=+vFF`fQ|NHueMJZ`uP)EUKcM%?U)t1OW{SRU}2lCBl$Yo|O!++DUq4|-'
    'Fvoo%*!RxLn%ojZ5vy&Qei8U=gC;VV7%;x+eg%h~@Cb@j{Zd0q5c8fwrqqf%)iMHC_=(H|mu6-'
    'uP{Yk&IAJfD77fa9FA*V=pSwVj_6klbbu*`1w#NMKX-!k`STD-ts7wC%;Zbed@Qs-EwWR{%gA>deAl3gRy}aknL@Kb%PDvO>&0{0'
    '@R%<58O_w9eDUG2ad*=MDa9Hg-#ioMK|nU!vnlgCy(!&DYo|{WjCv)DY61TV%FPXY=mZlU7%%j-'
    ')p*TXEZH=I8JnZ%+Wk{kfv@tqyrYpGUHA-tQt}v=`K7gG+Fr6pChDi=NBPyE@@zxllV4o$z#p@AE$V*w(UUAdisNIlm|818+Yoz3'
    ';Bt{nuB0cnIef<u<*D-'
    '?WSsZAT!REC)0@rvknNmwd7(;R;6I74S=M%N_SDH$msrehdZ9BQ^Mxid$imk0hwy>ptR`ZYW2ogCi#Mknm<{IY9e=0wCAhl)rE=#'
    'nthoI9`=krFY^q>+-0hocmhRB{HsL#TpHjeQBk)s?^VHaizus&|N4+_*onp4+@$2ooqP!EcpyFbu(@8&*FB4$9PV-'
    'R=9Q@Qb)I+40+e7jQ$isZMpdDA1R0p$HC_iJWuZlxiDv=g5QtR6*mLd#9soxEuB^VAQp>fbl(Winqy$}KHp4FrNav;bP7&dC)c8g'
    'CCYDBAMBl&<FTaOeA_2({2F)r>Eh1hrJ`Y_bu<P}5kFc_<E3peb$?r^v1ep+M$3eMY%U9RwLW)#rxe&d;jRk_mNJ=~0>KW&?(})Q'
    '8O`&f?w~UuA2VTtIlhl_;)u^8bOY%oKCg$H$X={=`59TW@JS>t!`_qv!aeT>-N{MidS4FTx{S+a!-'
    '#$&v)U%q*^w%9gs4h9Qh*KDdCB{}*H^E@=}CC!<w<Mjs&Zf2^1YsXJRgn1c6sXe!(~^KA3XSLwB8O7-'
    '+m9z!<vg5v*N;Q%k<+s%O*AZMADhUG9#at19Vi{!?QCrTo6ptn#2%UuWP{Zx*tpK^{{qUqIoPYdxUeUI?0>tauV)r#I;1ss@=c7E'
    'O&IP>?SYvNPh&gIoP2i%4#a(`##4D(+`(sx8`WPDow`7n*Ii%_r-jOt|z^jUJShUmpdLHCvdyeXO)Q$bh>#J+N1CopL$NeP)M@{K'
    '+XPI3*r@aY1`1$Zf;zzX5__Af7P0?CH!Q?&r(`g<|@1{A|yYZ%vOf@zK?zAehseKhc!N8Vi@4FUW-ZH&o`)`6|TjSp*X|}za4taj'
    'C;R6Xy;GzSCv)`@Z*g~FU`P6Rh)f<!=%ceT1DW}95tQCvcFO@NmZ9Gm5J8p%}{r55wv3By_B~)qXU~9woB;sJRL5|h%{VUoZcAHk'
    'b7{G4fJ~v!TuiQEF|E_eXrBIZuTHTga>SVSk6x4dIgD^YgM3_{9_r9xD@GRL+`cs@n)gW^n2`i2#~F`bhTS+u=9Gn*jUM|4H7oc-'
    '%wNMdYXs+p60X@`Rji_VkIn7nRW7>gd~g$-'
    'MsG9qpZ5P6Eh7u<8v0zqn0!I=%(}n^L5+)9^rK|`EK&%JXs27T}xi&fB`M)YMSGTs<_p9x%j|JWF%tqmeHR74FoWI=!&M$5aRWEh'
    '1_UltL6pEQ|1%*@*FMGcV^EtlgfHMw~@jehZ`KV+7<2vU9txrZ$Dn5KUq&$qeR{-'
    'TPAWdvB+TY%b^MUXL@(bvLIR&4X$=w7Jv0C4x04+>8_3UKakU<nG@7#4HC|d#-'
    'KbmF~Z1#L5i5fRDXfW${o><1g&q^@&>zR8v;H(#ASQ}oLY#k^YOU5h+DN}U`(gC(P}O_9M}wm+h4vFHM(H8Hq&<M&^e^dCdSH_@H'
    'KIJ^XUs^X37*63~s8CD;aE*-'
    '1Vg)FDF79%8z0su=jSk`Gq01Pe^`Wl4o>KU!OL$X#QNE;s+btsNSnb{ZyOg0?E(`mm|j%R|?M&7|WY#lPYJqA*Vs+)H>Z>LOqam2'
    '9E3Xot=LI!)jF)!IfC`{SiR-_o=uX=c7sf6tD5_8`Je#>r)a-6M6D8-'
    '59<{;&R1Dk63=KutM2|xodoX)OUwE?d_)h=jV_Sn{KbHR9j8v1(J1;fqSzoZq`4?-'
    'f9ObLGB@@x#_HEy)>AAsuRi3%}WOc!+3Z@t>^yFhUO8ag0<g!!@2P8*@*HMOB6??;&nlvLIJ>_4X--CpWVB%^etIL%td_<i_rXGQ'
    'di|6g1g1{>$@H3%X0*5!`?r0YCx8m(!pb@Df}5951VDVE;p8o!VFm5PK|N<&816~ZlcHyD5hX0FMMOcjh5R#y&n96^VM;imC?v55'
    '>M_hYai9^X0yk&buJF;OJyBHgI?eo?+#tpgPPK@IBh7_-tnA-xD=$f|J?b!+o_PfvBhN?&Ryct;});o+Zpd#dF}9b3Cz3lWG40(z'
    '2j%Qk-24IwFbJ;&YPIm(e!qLtM^i4&+n$Ei!?t2JxdLC$6_lz1J|{Fm~-'
    '=w*!*<v0>)jWi0%usyt3SR{^!j{xjfO8+xzAJ6<hPtcovULTwL{oA|>V5{)X920dai$Y${I_--xd~xl&2i|4Gqn*WSuW2a}!N0p)'
    'JZr!WaZO;XyPTP=5Q>}#3ncXpxf<DTqp&9wmxKoB_+ZLv+i>(3P?JEMyiRcq~qQmRbc`*l$`9M03xFI!+-'
    '!O2i=jHa9INL1JsGN$%i(O(Jc01ZxH8(Kq-_Hk=kT#u2w-VBrGYSg*#x>Kw!H^k^(fWH(K$f5G-'
    'U2~k*xuu%9JHHG&CTE=9mO94%QrA9<t}njIb~R=%5Y8_0j`lnr_qzzmag##lo~ks7li|P=RvcV?m497<+3+;EMK#RFSH1jYHl*A6'
    'bK&~Kh9gMx<59|rJF-'
    '8BZ;yLZUDqGpsGQr^dq3)4S46SUnCWvSW60Nn{!H;D$b9Lt+eotHG5ak8_ee}v*lHa285IZR;MOSmqPHtQP&6CJ8nlQWckR;*suX'
    'mug6-mgwR_kW>_^xKc-$L}ad}l)dGr{ZrIE^vydNNFZ`$`&>gC5_qLj{4>}(uhRojfgx?eh<Mj8^13-'
    'uU>`y?V<w5K1%r^?i3QW8wu5ue9J>l}xKFW6p`7gzI%n9=8*Hu^y3m+_v!>U=c&E2(XN=&4lz>rhw7KRenLvJQ$*hh+G@?RWb6PC'
    'ey<Q7DudQ-|`jIg`QC<v8}UaK76+U`HoXY~ZS=+5BejSq4&ECY~iTnlFBzdg+legWnyj;QhhG-'
    'Z`64U=D?)L*^T${t}9QQ(UH0Vx>;)X;XK4w~&H&ymAGS&8(T0)VGb}VS?K@7f-'
    'y6gg(f%J?boO<#>gv#Grn>cw}dO%IVs!%IT6d?cd@?=hUaVMYs6s72j+8Nu}k#OjM86E2Y*+e)ON|?((^!ShSU~zTfkc@&c1OUtC'
    'u$tfZ}yGRf5<5aNunhFKwe{+C^B_O9(+Cz9q7)Jv)6`t`Y?Fb-'
    'UgDJH$Yc&Y{F&K<Ylb~UDmCn4;-N2fG&2Z}x4W_$XCf~(~S8Nc08H^Je<a_PS*_V-IBRb4Se{4_hiI?G(_w2t?|h^lkCTMF&%uyM'
    'q<i@w8doN_*lXU7jlB=y<7KG^S&W{Jdg9c`ju>(MoVSA85<ka?YJ`wi{Qr=@gHFP?Jb|M|o6$adi``AGtr<LZ4@N#2;fd-czDHkH'
    '@qJnZi(zrn1>>fr+@RkgkBUq_|>tN|%Ey=T3msI#sePNV#bB9fj6mbd1+{p!Vh@cqX@%#L;TL2ZQN#aX)x_+ng^i|#POP{1CQHP6'
    'O7htU*itOWdfVEzEnI32*WDb?Ve&;T?EvAhpGY8SjgaYYrDa^)Z>z5GBjUBGU(3$|)m^8$Bk`8#fnd!Os`Q)(896ub5o>nZHIeAt'
    'Jb&U0iG`yvkYT3n6!TY>2?yXv|`wP`7FZ;((q^Mz89(Z?O-'
    'R7z&ITWRJ)z7b@`0xwq$rN|*uJPlV|yPy8D5aU+bU2QKUGQ%42dRM6H`FvgPyRHi10`y^HK^h<l$?o26Evc4?J2d1D>woq|AUJPC'
    '*C}<|m@Rj^g*!}$Ns?}Ee_T`ia?@I1T)Ez!t$vZ^)Mkb1q?bfA`UVF9SesS2@*$CwcWf1FurnYaG0MmL+UOdM2j7b%F9;1{A}%We'
    '*Hm6%Vcw=2PWs$J&HMQix01(SD8&vjJs@F5ZXSEVsm2mPpQLsWJk%GhW+&-'
    '|iXeaV(x*KavZRP_w{z{8omhb0x!;pVW(9<KeNqEP8vd~2uFR;>p;{?xjH2O%$gaC<`1(^7EB=Dk$mRL?WhApZyr{hvj}ayW#3f#'
    '|=FS{Qy3V9iV1z|4!gGv!T^ZTC`Yk=DDX_EoRIiU+%*+KIv;Ujt(kic~-~}$_6JSp7zl`}w^{&kx8M6oLet1_VBe+1W`rp^&-'
    'y8;n7w(mq_Y=6<zwq9vf_l|rgX&Jat5+X4%7mar7vI0<&TBvXReh?IQ37s3y~i<pusucL>=O&YH|V63MTk4<mA#h{vs_-'
    'M0WldAl=gZyj%Rn_+zg9IPn=!O8gUO3=YUmXb^kkCO`>Q|NvNEB;pyyi8!K9TX)%_U-'
    '#!a1%g}Z<eZAU7T(#1yBk$+0verp^(<G4BqsFcgKV({~-'
    '5BebA1aTvc_|p7KW%vDOG_>_<{LU)bAOe=gEpAAd0Ckzi&M1$02DvI!TtLPv4)r1;Cl)``LU=jhV{>`et^)QAg~;x#cZS|W^*}Gx'
    'w9vI!#ejxwdH|QdyTsj@HNaMxu7Q@AzsM+sy&<ZYSu{;wEFs3Vn3&q!+MP;8E_XJ-72o!X7F2sx-'
    'Q!fM<DbkAQk@FJqoO<7ClQeIwQ87;g?$U25+aK%0{#9{aGM4Ku>(xi`R0eB<CcYv<bK|Q?wh4w<l9%-'
    '+O^gzT?H$^t8IIr_y?czjtE^S#ON>lz+9+_&WPz#?R~Q$i%))`Gln(I$fa+@=-'
    'c1lmBI|nsa(&O5<?Xtq#bogrMeUKG&aNJM)9(_6eD`(=ybtP1645M$rDJ`(%2|(%4mtQpl%Vm6|Q<WEv$?LOFDb$6I|^X_cmZNBF'
    '5+`SAT*-'
    'Me34P}~h$acEtmo)gfbrC?RVdg8NQlEQOR|8IUOy}GdW0c5IJQ`^7Hq)4NIFswyc!9?wW*ro7nb<SV#C_0W@teiH!Ann>IUWaaHq'
    '&^CT>t$r)X|>a?cN`uP3B53%*KOCFtEHL11E&G{M-'
    'IQ2h_`38dJ%f3=UvaGO*uWD13}wd$mwveK|rQfBlfbN3I(nF9_feHAfxY`UGLQnJ-'
    'K~Til0%ZWkvj~HbUvUI|a&}&EuE(yg<=6(#vEi#tPQ(yhlTK5lJ;t>BBYa=*(Z}Md?=(Yw?oen|+CPRr?|-'
    'w~O^~)|s^W#(to=nQUvdN@Wb3LcfuWeu=tky(MTd)=<LD<~qY6_@Rzzd;A+htk&=%dbv@dR$X?+xtEIC3_rBM-WYuWtLcPr2yj7&'
    'sQ10?H}kunuBEYaxohCG>`s8e(|B|7I{4gr{rd5I6}0}m)}n=i9c;H|daP~@z3^wQxqAcW%}$vW_3|cIgrwJHiu~RL4(AXnKPJ^x'
    'NV+*ayhrRxyaG3CWXoRl(LE2tUdC7M`Jp$u%?~?+4J3RDqI!+>yixDkU6J`{7*dM^Uh4mmhyJNHVn2CSFYj@2umf~!?i?#ayV{<r'
    '$^LSN%br$x{B%4;f1PBtHnN1~1%rA$)ly1<qf%!bz3!%?`tTE)H*4%|Lp{c;=O&xdbv*3ik~6q+&+r;IP3zD+JQg(Py^n}(G#IhJ'
    'Wq;NEE;s#<$htZmANKM%MZ!iU-'
    '7Zg+d?FX*{ovS;=$p4_DQxk>y`Nqf|7hfa97e}_JoU$i(PVW;&bw*!wo2tX)y&p6A}YT#Jlk=@e(TE>$x>rr-'
    'QOB06<^!DDt^i*qO<8y%oA!qZV>iv-QxH;*qO_fn~KQo2nM`UfBpYa{VVmUf6m?FeLMnd46Gc_8r%%}HhZET0}t6hx~@8Ue)nOhB'
    'bG~-'
    '2U}zindal+k<qjFD;AwL{(HDg6Yn%1?TgHsdr#5PtbcEQ`6t4$fvbG4WqvzT@Z;#QCA1Z6Eyeagf5m=$u1z^$Iqt#}xgQQ@up*=V'
    'k1~wr<Z#(!H_+@fUq!XnUkmjMn<UtdMtOL%vzKV8uDM6G{pvP@9%?%i46Bovtf05=pRxK6ggeOBo2f^kw<YpNbkR$_{CpHUI`D;_'
    'ugh6J70(#9jy}qKd#cY`7pD98E7doeuC}LM<?(>mc$$9wQzkukb5<R9weIPQ>u)n?L3X9*gniX7X{c>yVibjq<qKyHij5|73o3Q^'
    'xL;`b>OU)g>xcUxM_#pr_Q^T)`<IeqDvfm=DcsrKUFcz}L1!meNq%OjHk#ya2bX~Led6%rQ@AbFFFSQX9om{S?`ORyc{n@#5}>NT'
    '{UgK$J8!INy`mu&u#KL$YqjtaE=0Pz8`tXraLeZ_y*{aQ$LDUxr)yfPPcDryy1PEr#1=YLPF48!r1a(^Eb83&1GXB4PrntnFUV&7'
    'xRrj6DvIAGhTEw1A(}HiFoH?*vZKh(qgj@-'
    'PMdmyN+A?l@^U&JIYJgbjN#~sE|BSHbPcdw9|Vkd>$xPt$wJ!ldfKo~rEuPT>mfO{{jR27>l^#82)74mwDf+af({)q9vwXh!Y!6K'
    'HAIs726||<pJZWW7Zw=E%-'
    '_dyCnsH5Rt_FwT1jLAWmQeb^ZRAP(`#!rliq~ze!f#v(7^()_H0XWrU*b}?!?^~x6U*H#`Ec?$mF#PTiq_$tuEPDP)z^y>cQs?R|'
    '-{-IW_pG<2RqJlHjVn+qU{$mEn<K-&xZ=EY-5y9@qvk+9peR=uBjT-'
    'J4VYRqoio_9n<MMp8OV3eQICcw9XXi@D0@&0d^wR{hYXcS;>pr<uHM3&ow-'
    '8!n+^GnzkQ{W#BBS2yNoGT(HLCi&cd3R{79igH5)>H-g$#~IO>Oj7r6vaHgYa^>gjg-xCI2)fnho1s#7&tN%yyzTlm+RFjRzmU;f'
    'wWr{+CLG@0skX$a>Z|JDhwJ>gUreta^h<I=ipKJqDji{RQa?G3>*ytErzYe@&}So9!3%#xFn|=3f%3pL{(k*r$B{XMe>JNfc0Td&'
    '<DCK48U5VnJ<Y9cmXh2#9M9FG0XAAi-LT|Bb8CHSYa0X6JMwx6+Lwl=E{}W$do6`5Ph{*)qou>;mbh>p#21rOBHv|RDXU9=mHpd#'
    '-05<boo&4JFBFtkJ3)HSvApNA&O~XH7B`c7$b+=o1N%3J1+HMWO^3ZJysT>SGDI$sev6p6wm39H)a{Mda@sNm$1xJt+L5Nl<g4D+'
    'EoElt>iu2sUg19*-}3D-;?~qclcw-+$4|c-jplZ688A|Vg!-'
    '3_AGY}CJY371jBKf=cGtQzU9jP>y5Yy*jhPqbhtgZg`bC`_!`)L2gXcwQ!g82VwHS}s)c$&!2h3J$)t5_*0egm6ZM;}-'
    'QE(GgJ%A8Y^*4y1EqVrV?=;uN&_2a2fwJro;T|+_6-'
    'k}Zq&kI5pJWsJ9k%UA@n<<N=ch&DT=6ZwUYsha`DfHW=U8ny>eU8CrcXHqrqrn_bZI(0?)vevrbC{=WCf}p909BeA8_sgHZ5g;I8'
    'r+?y&l@qD?MHbVb77F<&B*l&yB{PZKJr(<+gc$KdUW~_{%cSTh>wDZ9#eJ&ddL%xH<mP>E4HnD~{TyC~;?pcazh&OnWY0;#@&-'
    'cx&$V;_;~!=Usrh9c*BE9|z|G$C0YNu&eC)v=3`3`>OW(Shl^nf37V=kqRH1l2&BZXSvS1I-^%xX?1#-'
    'bbSRaXAO}rOp9J3Zjz_7Q~RYElkW?QN~tiLdqnXErPWnWe`h0tK3^>?Y%BLAR_$F|h#+y(7b9=>`T8?sZqEJvI}pZlldO1nd=CQ^'
    'JTCb+Db}+oQqVn+QD4xg7Je3YN{K#B=608>jT4|PoPfdVpkezxnIh)}Pby+2!?KJ-RKvy5<Mg{n^<}(pqv#0!^#72qr_LAeW&wRw'
    '3ymrsZ>{zI5luSFy=y4A**GU~zW88P4gq4j-'
    'uFabJo}SFY|HFEqngmq$SW5cF?Q^8Wf63?oO(zGX@7`kh1wxZ1q(j~aVEmIIi}ysu}q4CMZ5;bLN}P+&i-'
    'Yw`>szL=nOBzHpG0;6<klbikre*2~tLH!W~_+SMP5+T=Cj~+f~8pkC(-'
    'G)l@3)*?xHvonF<)<!_uhaaY`L?SaoA)h0r@d=o)A3ah24vEHaIv2W$oB^YVDv0YzGe1LtxsDB;jh6kA=iQkA&?Wdh~_t`G!drR6'
    'WV>wv-hA?@<&5axTG#g&&8OF>R|8CfI9O~B~VYBBE3<uA9dvGXO_`XK<B7ku?$-'
    '5|Z|NS%GE^tq2z1rSbdye4ov6OCbZ3C5CFv<8o`4(K|Frs4-<!*UsoRi~xeH>@z-'
    'kn+|)2?o*!zFF_^ky@>IBQb(T><o{)NUECDj!X5t-g1iEf>9no=wn4`$Or<v}hluci`o!-'
    'PK`R<Lc0#8aTY@W^s<c#^l?}^Q+5JB`=^Cq$U-&*eW3)b)P+*cQ~qO%_<#SUx&wIpS7vSu$7M=9+A?U&axmbC(}wv5H>5#-'
    '1o3X2RZ!e^84pZ?oZ1KLuW#z+1d~X`oWtGAEdmXVLwmW;ytT;Ec7TYE1@y5p{KzQ9`TRU+;tW0Y0vKAwA|4jrG21=co{%eC0OeYh'
    '|Yvc<g8px8S-Ro&!nEj%<kgcsrqb55Yl{*wcou>)S-'
    'SEjrao0CSjwW0{o=0E$i~x@=4e8gVlY3gO{?_vk}2jbnl4?$rsc%c&hLz(B*0mxO};Ga{#H4qq2mv8htUWnHaqSsE4~#wOQyKx(l'
    'fwLx1AZA}6`~oN{P^W(U^5^t(N^T!@#gJ;Ro^r~p7UNqd!Bl`d-'
    ')C`EpF_jd)Q+{WwZCh6h}t?zu9m{bn|^7{FC+*Vwu<d>(cYx7v1UlmY;qs?{^2+u$U(E(?6ZOvI1q!ol^+Ut4ZF7^GmMj;I#SPfl'
    '7wP`=*%K~iI*Qj-WVlVwol?Ngb73anZw2AfNPmGbkKA+E3ur2D@MMk4QsFE9h@o86By3$>juM=ZW)?Q-'
    'gH!+}10`UyJv@Q#YafO;UR#f3Qxt{w|?%ujU<q>8L+~EU6Hudih#F6*M++=z^8S|$Orsiep(Qo&5V!vmlltL{wb!9UoNPV#NZqWw'
    'c$LGuTZ>H1GfTVPMgPHkqP693NQ{Ym$Tft5lcBx!VH$cwEICz@QIZYQ;IQHAVcqtR6M(3hSrsRvz4<6TQr`h&=5L&i22B1arDcI<'
    'yGCFR5vk3+*(9t^#bytH7s^1@s>Z5e_9^YcKK|Yq^61m?6@FnTD@RXP5oh*JfFRfq!STE_fiBT6uzISX<nC_<fnNSy2u>a&Q4O>Y'
    'aapqrM)*$f3M*|h8C+>4(mol8A;mzxLBpQWxaP^wOoqpPnwKciUTBl;QH3AQ3D18PaX^0ZG3iSRM##r`dT5GSf!M%=oy+%>F$}Zc'
    'N8~n8}9(U;auaB>LzlcG)@uQL{Apm)<-}z+HM18tFZx6|Cx3Iig_l2~V-'
    'VRP+qy2g+KK;R)FKKro$O_HCZM1XcxV$(c>RsM8$<W;=M2CKiiZ`Oge^HtL2ja_XkBz<QeMwOf)83jGjSY^B8*>06yaVR?>$BqPi'
    'U2u!7>3aMqtpfJ)0OC1d^z*au6w`hFIRA0)$(p``x4|PaID_TfQEg@vfs<+#oM}#Pach9QcUULK*;r+VZo!RNWTE<bS>B<xj4_|6'
    'l1}G-'
    'c63c>g3fv<H1>;OnRB41$$>4pNAP#7+2N7*c?3Uj6)WIzBV{!S|T9+wJVSJS$~^hj#%c&SIW1FBRzh2TjOE<wLEDVvMynFWf;JLT'
    '{=sPg9H}11es#B8=Hh%KP3jG?Kbpx&5kdRtzFR{Pm1|<+$x2X^Tnw-zde*OP5R<_8d%)YhBSS)&D&2)T8H)ZYF3_70zb<J$KK==_'
    'Rw;vswE|1It*0kGBkih6{EsyF_XNezOR=avL7FhQXy(@B$1g^273oV;Y96s@_y94h!db@!}EN^VAgDA|NTG3!}5&88)xHq-'
    '4B=gXLYj)V7{rJZ$0*VvC*%hUAyKK^^0_6>3}nD2f;)7B;ON_PtIJ<BxDbsb?0ig5KIt%v^X%VZZfVhvRA@wcpo>VF7e66=4;>ju'
    'FhMId$pSLc|J{RZtAmgbvkz$s*CAwc!2^x18BayoY4~0<|M1v$Z&&e^=~w5-'
    'crf$1;A)~Gu5Wp=^)3r)P%P>RYcFw`iwoV*?50w90a0A_8Y!>Z9%BFlSN+^yqds{k86jz0Aa08YK^}oxAfMj0eA|EaD=_nqR|R-'
    '!7U;Vrz0oAw@{*cM$sIGO9EVh>M9zLlbKai;j*>+6#W&<JXZsitsna}V*`HT@sbm+-'
    'PWGh=KR7x?(et5`bUkT_l1b7uMyy>$Y;fhK1!D3#koFd7J@_l5!YGhuqYpt(Sht4Iq~Wef_%yiCMi7bpnXD%KS5(g!d0tGgDfgMC'
    'JW6k>dN`pYGqM#I79bpNnlJ_a2wMaws_GXw)5aqp_vb<nCB~fpmTJ?4^sSDK&F?EJR%VFV?tvRqL8({MF%7q8gl3SxY<sSQA%Sqw'
    'nRuemBrH)9rhpS$rScB0q!iZ)`ipR>U;DXs|cGT0-{dx&K{T_<HzcpZ$2}x3H+tT?fv-87uQFyPpT`kI$`*N-E@!o8J-'
    ';KwUtfj!xwlAUX>0wBACl>BuT42?p^6V6|M~<DZ=GJyS2mn!)hW379XfgKr9h|c;3EWB>Zo-3sx)nB-nds594`Tl?%X!#?Q1en_R'
    '&DN4?H2zH~zTSt*hSN5k@7_12#@ojcd+*<P<74xb@WM!s;qavundwY>u#=n;@9HVD2fm)h^E+~8T2n(UzR4QKb;BIVZU3&Mf`!-'
    'GD&{;y5JUJ{Gu&WP9n{yu%kc!-'
    '9>hlz>!#+bi4OZ?cG9AT9nw|aVx&!#vTmBz~L+SN)sa~Nxnj}?w5g+keoqk5xL<Z*VqLcuNe{B*4;_d`OT^0Pq}^ov|u-'
    'qNxw_GX)Og*k<tN_P+an@^oSFqxQ9bpv=4ot#$mWZShk@1C%PG|`30K7HACUX-'
    '}^5gC*NW10N2+)&kop?h&rI4QFlg1|rBhQE<`AT^I|?^^vFwf-US4#TiEs*+1Fj%r@Sh4<IOndA!&_tzt1;FJUWMpj={ab70}2Us'
    'l22-'
    '1rld3NBoim{f`c8siUjWZ6w<W!E6od0=gG$<`4$0Az3_*srPKXXOA?VqL;I6U^kW>@sCc<cE9htsZGq;2T2|3K|Th27MU+)1oy8)'
    'ax<;-^y_iG!E0-7rs_g@D4gQz~uvq+35P)b(D7(ZyR`;veC@Ju|2MU-w_3>44K_{d6eLjCJTgzodt_sOO<4PE2~fTDxQuwShwc4q'
    'ZE>jl<D6M0;iv*N)f<<oXtuSFPM!Ifo}`-'
    'd}5DmYsF$(7Wr(9A0$W4!(yczXqe!bf7^jA1CV|9p|8TTFTrpV(nLj2M;%Kis4mi;|YQ)Hp>OrKF%-'
    'bDw8C)V65Uj(xZyaf+jz{SNuToK54UQ*3;j(aeV(IH#z5vW3vO&jfu_fUz7WTeP?W!^~vx-J!>KSLA+UdUv^Xb2C+Pb;D;q-'
    '1?yj~t21&Pd9)=i`*iT^UG!~T=cHn1p0v<&$1zD1JG%f{!|ioJu$LgyXw-fR!2r`5QqjK%W<0OAPtjfRC*u_`p7yf>oLl+xW3wTi'
    'dF_ju4XVg%Too^>vdf3jJR6w!$-_6u;0+DGZ{F(i@6)`^yj@RwhP85flB3>+{QUJrpPHe-VgN1p(d`XP-'
    '*{_)%XNdTkEHBe@2!J(chRzXlW`BO)(&ZF-p{U^_eR?k-'
    'dT}t>;}<ufsRJydzkhbU7XTg?sTg)kl}itqFMO(0<*u!3d1d@omLjGWglFOtT2!~VY}q2{83&7Nf+_r@_Mz$%{hAIaPIQJo>0BC7'
    '0l|*`tFz6EbjaUGN<8XSM}EZn7&PF#i~y1fcA!7VsJ1`LnE&-oiwkoCGY2v-'
    'mcoxqE6`a!0es**}S$5h|VlyXUoU;;;S|~t9WtXJ^{EQ6Q$K1**;UOrsnO~Tu4>_uvFs_+8;OWKX9ct?$vzo1|gbiQT)NpkeD9ac'
    'FLirp9dX9CJF_98;O4K9%R*FB`)tI<2>frC`yUh;CD$pUuU)2(z3ieNtMxRKe5N<BWD#R^itcWkM20nQ6WzESFb}1l<F#!`d%M?K'
    'baS9Zjizgh#?Tv+8<<D<9U63+8-t4uy>Mz7@P*l1^#X7@zZZA%hRUJJy<-'
    ';`(gP(<z3?pTFP$oj*E9nHdj=>JEQ8oxaNuI*p)iD3`7#RBm3jhx?rEG%cOIcK382W$>vS3?dZ9&boTgGQQ2ys|CznTvangJExr2'
    'rVyP|Z(mpBXecU@<{6lev@AN~tl@`&iEGdlt80IfaI)+d8(%L}GjP(Sl$2O6uLDbYyw@*5!EZ@(!T{C1#rzK#6<Usr6e_r24^@et'
    '5qF8JJhHbdVl(+6a_^O>uEPRZ6?iB_UaMWOHhcCOrZxmQMSYS5zTa^f0%d}uYSYZdWhDzK|3~eXXz}u&E;CyIBt~;l^DFt=o27DI'
    '4JXx-jbCfMql<A{IJh;R71$=~zY&`AGy^U>IoM5-W&0ssb-'
    '9l;^&*ZNj&D&e7{VJ7?jz7FY?fR8dr%kZb59%nq;4CFdhfNT6*lwv&DC;)QRfU;2?NE?6&ei1K*zkQ718&a^w>41=Hm?CZs;8OH&'
    'mR5UidX%_{=13g(U=%p*Fy7hYI)m}UW(k~!UREXcHo{XCPKXGjRgC_eNmMMYX@(>)-%nd`}A5Lfz>bcLaYteMzZI1-'
    '@H`42yQrzmU97<P^D>~9^!lQ@2isQSW?o8R2+EhbCArY+fkU`sfd<#fi)o-'
    '>dlDtoaTp%sxxuIFT4z&X+^nx$&H3p+a+8vi+i#jEU)jIWhdgh(_dDuztq%=r#|BP>I(Nc+i0+T^TeS$%{@=Yy99kl3%dVv@KHW{'
    'En@)9Ev?L8Uqq#`j=sj1l3db;ou0&4Vv#3pd|j2PZW-QhC6P+4d?GPXH;NN(w_vn~Ri0%AH7u<rqe-pHhS9m3@sN;~{7q?tw*Iot'
    '6Y%3c^>Zyt93@*Xmj-'
    '04kkU}v!h6HCCZ8$RY>SpU{eI=3xUCIl(SMCr9MySzM)@GXnghivhd~=dH*pxTUbWsD9O<>|y(kF6Fwvv98R8T-d~c@C+v)}5-'
    'Vk${oKN^CXBMg!0L~?-jyF@<uRXMMlG6adf=ZM8GblTD%gJt*PwZo~Mo*s1kIo8WC;NhX8-*?u8m)BPmwFUfJSJ1_yX6Tfg-UE^!'
    ';{}of+_eZAP8tcjUEHX4~zuGyS#O?FmV^w%-'
    'f*TXiI<1*U@aKobQWuJwdCaeqQP%TF8H;(+$Wy5Da`HjRGHawO(Xu$^1D#tjh8NVvj;MU$w28JLl+fIy6huHX#blO(9*N(|<{~c5'
    'zO>l`y!DiowmxtV3E{;~QqR?dtgkEY=t2!t$>X|1^YB#6s0%nYI8yEZy_FA#bwIOC%;v?#2i$G4+R8Qo_Z!IK92)-'
    'q8pv2)Nz05_VGBY%SJ-Q}Z$>ETJpq2O7|~!g*Wr^`8R-v;$b)i5AcOT{_ce7+*YlK<opzl>oVb)Qx(p^ORU+FCdXo_3Giul-hF>Z'
    '%9kRf}H3<U$kzo{cL;oT>>ud@~8Q^tg}6NzOJDH<S!ZbPt4gkRYn2JzIF%Xwta-'
    '+%0FXi!%FTmm**x$I}PC4@H7yW8#EaVi^k|9c5noKJsGj0U1w-'
    'kT@KNMUN2K2_!uiSOJv@h7C;H~1<$zEGwtJFaJD<l8olH$kfP}p7}R%Bhfk@t7>hht-Xxd7%#4R>Vr(utDiZaZp?mB8lA7&Yt%a~'
    '-d|#NK9yo-}ud|UG0++cOHXPti?W;|3JUoqh-r}#k(R+;7cznVuk7}1Y(2-Co$wbtb5GXhDMn5j#S-'
    '+($v>x|4y*vtUl}0$!)2t_Ysh0|$5dpYCJV2Yf^>DY}zRXf;Eg{0K$moCLF`e_g@ZoCbQNz!%Q4a=Xx%(x5ceA-'
    'X4Hy0Q{`M9*s8KK3YPzMy)4bk1sg!(CYFy1>ds3Gp(bkt&cKJ>8Ha5}mwnUC8Gqut?UCj|iH2w-'
    'G*0u~`jT1MnR+g5PmJiIji1dpVpQ1KBHGtN=orG7`e+t;vZzl~QCGMqxB;Tl3aD7NSA#UwLyKShAbo%Na=UQcO2rJC=H~`FZU23r'
    'WU%tyae;{c7UWJ*i)T7I4tu9MHsmEhLm+Dkk0PBy*a=P{<Z62pNWt`m4l~Z2A7s5~SR?7ti+Bq3md()hQ__DK~T!>2>mcldTbhp!'
    'T)ed{XqUUGcwIxuGgcwaDjJ-Kq$No)~+eyH{K%!@7hAn}!5U6w@V~J%xT7F=G<=ICKYn^FPD_^>I$F2A~HWgM%P;By>*MR-'
    'y<S2XNkSIrsBL^C{-D6dsG+!S{^9X(;ER7qg4~bpr_Bfqmvx|12ebkS!Aq9iIDhq!%xk_C1aow+#TMPF1160J~-'
    'FK9E!y~w6yJJqpL<g&*;I}pM2tI#?V0R!~#mD(oy}ZTp-7D6?@xWdTOFa12FL!WsWWLY~)5aHL8&R{>IXrDkISs<da%0F6raZhf-'
    'QEPTP@aUE>7=QToT5v%$dyU?Z<dG7kJ<X53Ml(&H#}Jzlo|y)Toq5`XY^YI=UFf>*LvnwwJSNlP-'
    'F(R@<A6)#kQf(vQfd@pGyh>tWzae5Vd_y)ycRQY15|iNwJ-)k5k!|wfOGPQe)P@&6F-@^R-'
    'z$P8NI#<k>#m{LAP_B`lx2(*w<3s<pMpm$r0aa1gpH2AZ1AnZEZz^`4VM8)}cTsMDo;NUcenD7?NHwc1`$d(kxl%IE7b)I~0KBDI'
    'Oy?6|O{pW~L>KtOr?#h%#b;OK)>i_Sk4RA<aqy=J@j*=s5!zZAOETsyOU^~+0SB{-'
    'L6DC)wzV$9p$&+*>_WW`e0t~JM5DxU3;%!5mCJiR|tQ9tg=Y;U%`zfE$iIzx>5wH?_dn!E*5a<=PDPx~o-6ar`PA)bxxskjC-'
    '<}TBRgaRcrj@QfW+ZC$y=7JaB2e1&sYS%30xP9NX0I^I(r?XJ#X@w5JmF9kkS<4%y5%B1*Ae;%~wIway8ExOhZ}1(pF1yEpO5Shj'
    '9M=z3+4ZST@|)ELJELJ^yI>o4fY=Z7unwO#6Pto;zqn}42BmJ3H@r;m^c7<DOr$Dx`Vuc~IYS1ul*zo3wX%2sss&hZmdd^`H}{EK'
    'Lv9Y5W>T-S+QBpJ@Am89E<21Nk3Ca@G7g?0d{b+Bch2r+HOij!sN=LoP{r_u!h?^~*PPmffJBODe-'
    '69PW!POsZREOnDs6mpypw>q4URj8-'
    '@ZIx1Pz%lJ0AQM)n;vGs4HIG>R!9Ui|em(2}0Ipal1tM66urJ#x)m>#2zINRjGF&Dp#5sP)G2=tIxjAXzUPVfr+38TVhaP$y%SY*'
    'qGAB#Uu{epxs^b==iUG*U6~1)$Qd*TVQldrG#DI!)TqIf^$_AgiW{HOsT+8J3{RV@de`|Pb$X+#Z}#v^z*zP=A~`{I<T#%@U$1>H'
    '-zsV%y357+hS-Kd!*D}z{G@vzD#{*(ysr|vL$EiPU`tm%0>V&#;e6Dl7+38WYxBSFe^)~-'
    'jQpeg3D#%;c&ILf4SOMW?q(^I{kPMca`>B|2Pv`NZ||*!Qr)eUx0#J$iKwDK<>q3pW;?}?woF1Ulkt})hpnqqFdVRM?xRRYL28-'
    'n(N1JxN1K;OGIt62KFuM@o8x5=yd|Yb=iyU`(}O{A0eEQ2L18{ibAHAK=U?Ld+5ZVYus^nYn7A!IHIR|rh595U)u+Zzgc>8%BJ$A'
    'c%5}0cD3|}A}6yq72oRRqnt67z^0s9{%px!zz#5^H|^Jym3tL$o5BshP-bPRHeD&Nll}zo{JryY57b|!#=9dEAp16&g^hyRo`<e`'
    'OKRhU=wyOCLSLUA#WwL6c=mIIo+g+A^ogD9sOErd`ih3M{mp|SdK<Nu7S;CZP2_8y-'
    'QOsFF4X{j(fNZH^;`4H@XIgrcCvGwTD+Lc&JfBq->V?mB=yNnvEE11-'
    'btXsiF^QC;8iioi|P7&TwYz)uLkWk15wU4ugl#zk%#WtPm_^ydzim0v+Mb6HSU9xT4WTPMC-'
    'w7Q8^f<(==B%ovn2}RhlqbyKW#v{UT$CIdzt`)$qo0`_fsT4BaC29Oz=3Zp7u6P0z8R;v9oc_$ZXGrJge5Ds$!!(ORR%RVO*#KiV'
    'NUHSR0EW!FZaS@#DHi@|TI+H!mB3%~L0_PXYf3q6}%UPAHm)K^RT=myisH}SVvoPc#cYHx<m>X!w_Ra$e^#%Wp{F8^%n*F=w707-'
    '@MuvyJNz*v85TqNa`?H}!WiOj8nk=&m7=7@%9vuy9?tCqC+<#I8VR7gwTpv&DGT551%B3{+@-sp&)g5h~w=O-O<lBn^Cm~W~B-'
    'eZ6gm`o!nDp{sH%z;Itxd|C_cdkSXF#(z<e{`v>T@zX%C_`<rPVrA+^yF^Wt;ILNMa>5HtnRkA_`Mb64G1qan#Vm3Od8ew4!aL#l'
    'j##Bw5`*=Uz};F{NY>AG#aR7ZofV68vR$0h}Fj9gEF+)VTy)CMVCte7tVi^9#&UVt_1Pt<r<l^hn6wsBCQ*vbopL_@3GnNic*Pi0'
    'a^WhOg3YlnotXVTTC{k)lJy;=KDnh;2j2Ugb#>S0HWW@gMB<Kco+T%KcIS9$o_@_-'
    'eJsZ6A2>2Gds#w1^P%=3oCJ_p5WpL|FSrD6ypQA3zdG^qm*Uw{wjWL7sMW8mt{_=U5Cyj>}hvhE({CJaUczh{r*^cWMzmPRd<+fq'
    '+NL?)j_JCA;19{_FFyuH9XPC1}KyVKjVocHIFdo0tXVyHnZVu)WAiK8Lqp#?PFbBPkl{MRYwZVk3HPBTj3=3jGRdVWBX~pi(0}q&'
    'EcnytdVIUDUPXnZ;{6V91C2P?ITTqTa`+G=9$gC``P&NFh&yK@EjL2$X~#%-'
    'LuSmnSM~}QSLgqvZvZPH?@W$mhnxAZsgGmCd3(3932-'
    'OKS|!17+G#Bnjt4~1z1vf6Rhi4U&;j3!P1}R{fi{P!KcIa%mJ2^i_5{u<H7RMj<Z<3k&ESeFLSiJ^Dg%^V6OZCV+SNCb=>BqFGK|'
    '(^qx<XJXh7hR;e<*dm-o_$sv8wO5QacG#-'
    'tf_UB04j@YTqI;U5fJ1us=#8>sv=0LkR<FjoE5L^%|rLNW!WeJBbJNwyuK2GGbVTRD`v=vf}HfaNCcI724%PI6c8@{<ug+xIEVKk'
    'YU`eyjo!+W?5zC7Yo{jAhkncD&39rkJA%d7j-MyOskeVN})!{kv&QMI42>j%ZW)(=Uz1JS)%TroF=ERrbe^h24M%e4mC>JP<O-'
    ';}H3JNw4UmPP&PDmj0CZA_-aXQX!L#_HWFmOhJ_FflcsSG87Kju~ZN?P4O$L<7Kfx(E<oD5JKsuGMon%zp{V<#lCkSnD>~U{q4!k'
    'F|JTilK!gRG*UzJV2J=fTub;R*i?cT0HJwHSShXS(QCO_6j4i=Ep$hZinC_e2Szc**o$oC@5rWHJn4ww>A&Af83UG?}tTuvN@Wt<'
    ';T*-Y*fH|m9Hbpxa3N-+wL_-'
    '>)K?}rdGShyBn;zhrhhp$EET~&H*o6^s+6Kg9Ip0Xxo#$dqUL$e$^9Z*7{yCXTLtr2!FwWbsen^DGJ)F12VYupF7Ee4T<w3>NHZX'
    'PyJ^OK-A1fx8d(T>5<y+R|}uly?Q*ycPG8N-y*_z%jE|nZMvE^1zy7=`lw&cb^)ng%r*F)5D2@Bqy3kfJ<Cw-eDZo!&}jWCKWu+|'
    '>iff*7|f-'
    '!cB~n@6;*mk@6mGeXr`ISU&m_`g)yu&PUj8t`Fzwv_HgEJ5B`SdgJd+?;W4mk_Hc~Dw@vcCz1C)e8SbCARSXOlSAFs)k*;{XN7~u'
    'WP}Scj=n+-P<L4f1&={E79@2b~k=1W4nBo!Iq-2MDOzgRX%*CTDA+;-'
    'il99u`(w^$$!F;8c>PV4+esi3Q)3YV)y~Q)!!0>!^E#nsk;%3OhVJ=BByO7!T1Hf=7{1R-'
    'Y6EeH<a>W#Y$#Q3nfd|A1x`fQWj6s_sYK?8t=5P!=3E>Md`6*-'
    'BJY?Z#I~nG)88IaH2VaSR?%>^o3lGNpA5&Mht1Pz!pM@X<Bql025E-2il^IdEP@EA(6h#@-'
    'XFvWI+wWZO#I3MacU5<FHR2hUzOnvKin#vVAnK%<f1A6QDlsgeOOIP9Up87j_L%Ny<js44-$ORkx<~J>i>L$cr(T)-'
    'bUS^{XV+2AT+Dgp)DJ75E6H|SK7F*=;y$`<?82&d1!g0b-4H9Q(L3&IZRfZ8Wy=-'
    'qs60^nZvSG%qt!Vdbv_lzpR0W40?+Z%(sbd1tp%J<M5=RM6i$I1KeqZy62xPxeB5O2urYlj>Cv?EyfW58vMlaT#X4sS_XLIi@Dti'
    'q+f3_H%Wl+MeUy>Lj3<0_9GtgtE45}BonNJdbZD)fANw&XoF<D)-#MV41TuP_I|%qCKd}$y{$U{tZ+Y1@%l-'
    'WFg?}HVe91arI&=H{<(O+nrQqm-zH??fCdSKn1Drb;XGIsbtb02Yks3p=gKb}XQ*Ro}fV=kc$*QGV44{}bOto%;27n(MLh3sj8a+'
    '~>8Ir@5{AM)zi@LoO|C<KwTw*Y%JrJlV#mT6{Hq9GWYOK2N34FOJjWDZhr7}@PFy6I*b^81_9Iy4@0igR&=H}n)+Gu}Ty0$MpiY?'
    'zURtFhg2j8^SmarF>%C=uF5B#0`4KBbcl<V84-'
    'XXFEC|9~rbW{zyKZstr+iJH&o&B#sb#OK|EB;kh?xC!a53CjWUF8E|KTn;xFfMELLYc6F0-'
    'bVR+5kRf(Z0ojz7}k9b}ww5OCVDYu1OE%%Jri%)WDq>Bt_7;&v%_#vwc{N4~V9>)^WW~P7Xp8gEBk$mCx5Vi>uAMxBe9$kHOAG-w'
    'YUrjTELMi^f^S;hl87r<-'
    'L_UP#z>oDOatxHzr`w&KXK6^#?V=#F4+m%SIvGs6qxmC}Zjo<Hcgia+j|mznXGt>|Jo#){1K9ZeemZgo#1`6)N+f^h773RfFtZ<+'
    '}6y*co3S7WMKKhYhGp!ex6lY`m^BU9s+G6(M_^XGu*yy*$k2BTgkqTPwrU704_D{Ov4fGTEb8t_IDq+Y}V<x*JOg2>D$aS|<>7+h'
    '#q@~U7ri#~E1ThnARDn9&Ce|vq@mhsyC+~1-'
    'e4w;WoA8l<lHY5%YZZVJ?g!4pg`jtW9uN**}1_$7N+Fm?Hts>XO$5yVB?bN#ux3AKRpJwgOJXmz*PB7@>!-{jR%2cy<V0-'
    'W;C^}sQS5taBmBY45J5+U0zJ406JsbKWNRuu!`pwl;CS6iX!jd&I;)3)2U9S`0-'
    '_n+CVmePg)NSWfPsgs7B9&X9l{<C^TeY)wqCSe1!O3S-N1K2hslk8~k*y5lw44H1eQb3}|KfEEWN3E&B0-'
    '13IqbNpUDUkym_g$AFuz*%a9V+GTQwS5R9@Ngb&BmEV^UmSdw#Yyt6R}ZIlS(><0)+YbiPHZSl(Rd8Su%osiMxb&Q<TmDDU+Nd1`'
    'A@cx<h>6}OcUk!*Ovkl8NS!ZbBAEedra9<zxBnDsPAA*KGM@IH4RG%BGBuZHti=$K*V|JBTar2Gnj{V0{`{M64ANE&s@_PBJxNpy'
    '0nn)p^P!6ofW5mpTzejFQ1Cfs+RaDiQKzrK@#Mjh|o*&IfThdD=6Zer9vblfDuswH&M|18LXqDbLU4K)tq>S|e-'
    'mR5zZ(kHIV(;nXm#Ea^jo_B;q6Fq<q`>EiA#R&rVzehsv3tByULnW|ZsBGIqdzPbjvlEwwhatkg^iYeLXw()SB1^6LZvS)TNe66A'
    '!TV68Bjz{QQ7x#P1u0Q`%=B92+M#g-<+8bJif_G-'
    '$PqWF<Jfr&x9u8z>cn%S;TQMF*6i=j0K3+lp(e#=dK;J{9)V{icuz;I^)&lJj@Mbf|Lc@0_wi<Z1%}fi@W?L{A>q7@vwCNZ+?m!j'
    '-vQM=W<`R*XR_<!v;;g}I(J4~kD0;lBxu#b-'
    's_}3T!xSY78_+eI4kGE!646Yf5`Vsv)yknUe}4&MZYe7wQYB?m?Y>1>5nArEXaL(2)7*KJ{-'
    '+oomcr|>u*AC1TxmvCi~TGHEU%!_Rz<fUw!#G)?^TqQ&8nSmx{;fz0f_^>Xn2QuiFZ!N}|+pnGycy&&o?0*WZ)}FL{Qh;{sbR0QZ'
    'P#8_Akz7sqR@Oq9E&vS$(~VNVJ2ZX~1l3K$mDukK%qn{+63gg%MMd!t4Ih23Q6TB8hLs#Cvqm22nNvY&s+?|!`mQGS@m9*rS&BQ~'
    '%$Iy;V?_8nX-hVx}%USkHY*5%#L8vXsC23L6JWfP8;$iLC;DeiTiI6Uua0p6;z9ZP*|*Oyl9w376BCoeqHFZ7yhrlj8q&jds6+Lb'
    '$CR>IqSxM`l><rN6`&dUVb;uvlnATAkd9Zafas^#KD<Khi&l|P9m^ja&Gp>}QdH@DV?HObm-p&eKC=dDuhWQ+PGWNANg!GnHH-'
    '#FXf9KVloK`9;ex<fA(09?ll6etWJZ8Pk;{-'
    '8bB>$^?(V3j?(iOvqte*8U|TA$XQsJgD*P>W428PRy2r2<mxP7cnOSLfbfnHSdO(b8SRTK)=|Bw_O*??`pa<cMXkrGnA3aE2yDX0'
    'tfiYd$;2g((!+C{sHg>cW<;{nhB7b+LFDtVaS#kW9M~#}`{TueV~Z&dV%txmRpmT=?6EJ6z}YQg0Hvxg4FT-m|&j?bE-'
    'd2~x9$506Gdt(2NpJF^}84!~d|@15OI%SICJ(H+*WL}&b<o|}cB4FbGpb|wTr3%M#_Wm~w<R9epN8IBNU*{DuGRTB|)HAO|l$?8t'
    'r#r`T1B0XL%fLcc{&;6IBDQMn|sKx1y6**>%$L)+8^@c5i{-VU~q(?O_TwJ-3=f{-Qx<|v^W!y~N++y^x-'
    '^G2_xnr&5@nv(}XMNzwt54e5{F*7iVabz2dAy7gsq+OS<#eG2>gf0p&EF(qbSkt?5yg$mNx&SY3~_%5R19vH{Sm~+exm1Q%$M=QG'
    'K6;D8^yT<pLC@IevjSQ0bldtdJ$n&uPF_ho{D*|Pu);}7-'
    '{sta{bWDYgdo|8&*|E=M5|cyUE%dmpQ_mU=N;NuIzN7T>W7m#pCW~Hvq1ql$}`oA}P=LGg^kHM{$IIv4y|LHWnb9#{B$paYWBOlF'
    '4p8PbKZ)T?We?tJA|jM<_d=O^JGU5VRVkk>1#QwS^c!CWFbw+8Nym>DP(|z^y3oxL2SAyPkw|Hkdy^V^sFVBX}>sfCxuWp>jX<VR'
    'b(YpRRDi!IRo(j}G<U%*a5LJyzQ8>c^uOPJwwAufm!#YWCj9Kyf=hT!1{TE)ruFnN(?PQg%#wahm)FVeg(cCk|ZUO^i!<zgH<hdt'
    '7ZDG-'
    'C9!k4hh8&KnQUnU`~u!OLuwv+rhkmBr;!KcRDZK=G&T?`;c)|D4rlzOAwT=#<NMM2L&$25M9(SPUnF8LIOf@<g`}W|?&>AX_8r_O'
    'o<ZOgcVLmVjhYA)gr5dEXaW@W?ZF6$E!QoKW3Qaizx7Pk8xLs5H<Uir-aN=2xZ9QFgHDe7Ubr#jVn>i#w@!l3zHGuQf1RY}-'
    'T%%p71?ITS^DR|)#@<TvJzl|9Gr<kmviO`C>qddEWBJ#MjSyS~zo;}HyLOQ~gtnsHVR3zgQB-'
    '<sTdbH9Lwz}>i3pL5rpERMEjVm$t+x8H)kI?1iNR#??0uSRpeRKP0G(6jCLVil%NL!%>*N*GA4siIB5yIVQ*@>h+^y$Mm1^6`F2{'
    '`lzb2A|22JQp|EQ5|m9VQ&W9dvLNlE6wide14mSA%uhjy&vu|9!^}hw_pa8Jp47)EMQN6Rt0Y}q#}_rp0<=!kzKn=r@h0VMnI?{o'
    '{kik4M4cMSW?vxb25z^1n{uYP<r5MG2ERhnmNiQ1+I$}{9;{sEjK?P!n#}hyysK=P{CS_-SZfQo3SnXZf0eNo?5c{_=UackZn1)&'
    '0#WGy?e@2z03JEqPmi?gj@P`5Ber0$4Q;NzY^xUpWbQj(jMVi32gt9DqBTJ(sd+MKBe?katmrUXLFxVcRG7ruP;8(Y$GHovMqK5_'
    '3lf$B_{tpwSP;4Ca&D?i*5KaQ7NeD!iNz;ev|x~O=l02icM)b&oJI3n9t-9sGm=y@y-<7prT}MX9)@R=x7}LKJV-'
    '%*{nD7eRKJ$+l&fShx?$<cD7@si!kd^^SORhtq=UF-FvlJL+xfQ536|1;U?VlJH_xih?^?@d(mbvaw0?WyXpz<^rua&XyIRyaBDf'
    'aI@l+E>G?h6;OY#`WB7^^e0YPyN0%wr$4hDtP98qrr>3x(YyIbSyse&)40S44Q_}N{J#`PLjV_?SKv+1W!##U~@$tk0TVr~#nVd9'
    't00c|(SzZUvu{jwmD+^PoM@;8A@U(jku=WkSejV+%(B=^g9?(hZu*JZsbr<#O?J;xoN3&s5qwPYJltcJel;);>vGGu$7yAmYO-'
    'y`F<oYc{%lmj(>#+p+6p7tDtL{BzNNys{NH+x&-LWnZaZ*oem)Gz)q+14RFDQ-'
    '%8l7M5+Pl>Y{VJqBoEx%*ikrYoAFPT2eYEKHaA~Nj&tYTmO=6$w?~Uaox}{gU)#`n*>*Zx8SST$Yy|%};7yR3F-'
    's*Ae3AID9pg9yL9O@NgAF6gVeVlvF_`NzRyj;(nw$`Xs2lBn&GmcYI=;eWh<owAf%bnn_7m^HZVbeNr=ruFexKXqZ=pCsBc?Ew69'
    'sE{J7IW$jS<<m^-'
    'T}B|p7`TCuE`{AmCZJ)@27C(V2Gt?DBUOIGF4_NSuOq`Zg#42?c<67c#jA>HEpxA?s(SR#neD~MA_)=2MzaqyAeIAkCsf?&q)VYU'
    'Jywi$>HngE`#*0Wd3;G;xahGHLXdVtogoa8;8)Mi-K7@9m3Hq17gQ(G8f{AYdBubM{?*)`Sdfjs-'
    ';$VsLqd7Nefyx^DY0{i=(7c7YDxF+E<lo-cG}u=xh+5Xv~A{%9zAe<q7NB<Rso?Sm5Qs+KjDZR;{f0>W3Hgwcdt*3Wu#q4IysHHC'
    '&Dl7vscemdE`?&BE&dBDVXE=7W3@39}!fsQCQ*nMaGbR|R((CXQxNzc(Y_P|azSM};VO_4}0Z@UBf)865^ggX;`idau8lJn-fGV}'
    'ss2T@Ny4fiq8s*c|}8j!ioMiYcES%2Ya}B&+!#yyyOIJ70j&;ocneD$;8FG=gDafvM23&DQ&iVE&sz0;(eydz90pfNu4+!Jw&|)N'
    'WaQx8-b|H?D&m9-'
    'YY5>pA7b<oV`orepFF<c|(FYKadwLl5ZLT>d^N^ypIWSRei;4_JL@*G{#D#bDq((qwzs+Pnv2(V5J`$!TaH&7`^RpZPX8s_sxFzc'
    '1aWcG2j3b^HY&rh4OMlM_*4Hqnwa$3~#hwHG#TJzJ#QdF*V$ADdRcxDYR6wvxt1x%2+#r*qj0Q)^g2=!P<B5}SH3H2Nu9o{zG(VC'
    'A^AWv%KM-XF$6P;f_|YVrY<JKVbxE>8h{6?nqIwHmF!q1yeWXYl^Hu4XE`>ceJ;>)yHoI8keU*2a$`Qx4ohBi~nfmW`t8kRb;gJ+'
    '7f5R8bm)u$g<0a&6!tPh0F6lePpnk3JY}7}1YIwK1o52Xs}uIDZy|7wXvWovbFZncj~HzH~qIBlpvrepxR2!D>*c)_>jGFL!Hu(V'
    'S=Q%vmssSR>JzZ(BL-qi4~t4m1Gu+rCk~?0RT0*p!_%pf|5dQX!J-'
    '#;VM&MmAl;9%m2wA0jF(C!=%XT|d8konM%6uMuPXG9NAupZNu)OF3F}S>*0RAJ|{^>yz;d%m>it#)zy77h5NbB}bWd87qexQ0@fF'
    'v9h2>%{E&#`j+GO(f;ZqPe3yKwNJ`ndF7jItCx${U|AU=;gWADhq<`qfT?2)lZbpb+f><yQC9=763=cr%39h<#3ZK*(cySooEK5X'
    '{fwuU)B5<%`=`rVbTO;Cadej7z~e^k@jkE{cM0^Iw(L~D^sWX^WbWuO_Sot6&y8kvHtyw1qEMYiW8=KWG|U*iZIm`&jGS-Bd<*%R'
    'L0-D|v-'
    '(l2+dC;B0krMWGk5apm9LM7&wR#2)4|I@DLEhDch4=gJ>=ol{NiBl;(KA$^^E<e@k!SAqSBA$U|>A9X(aTKX=}%h;2+MQn$T=NFY'
    'muc3wd=gv(~bn46%FO^iu<7@5?@H?+<(L^xtj~4*y636ZyJ7Ii2ywXwX<k)^Q)b?2ned+iw55OU~DePtS_(XvWMah6=Nw_-AK0U0'
    'ZYdwW`tAilAG}$?8<~QW?#R)j32Sw)CI}SKhxS>!aT-'
    '71QE3XM4ix+}=Ii0e6$k{5PNQ;BCcBMm@KJ?WKnhrL=~KkGtjA`VQH4Lm)6R1=wZ&5e3riWLS5^C;U*}==0^PMW?mHzy#bs-'
    'y?TA>dV*Mr-)hgwbXAr>T?h2f8NuL9-'
    '^!M=k<~rz2|;oQI9&xd>)NLy*SX1s`9V((uHm(9~phDF~nD*+gJv!>z0tfc7J)?_l?PLHYk>*ZBk!1<>hlx?09BU`O;-'
    'OP*UbqO^^HxmCd=Rq_7MXml4rOhIp4-'
    'NDqZ)zu3@|{%UsRoyUJs+8{1U%h_^P%T0?PF86~vMb^a^rl<!0Z?5Lm9}Lg@2i{Y)rqbLthjllbb1Inhju4$@g~rZ7@gjIZLz3jX'
    'pXHWv`cR>;IdM-aWKwY5%8nqv5zWGL)8D>kiC);c)x(o$oXSK!9I?Qks@bp-'
    'Z@x`?vh<lsmHGJ`KAyO<MMr)M4fSQ?K!fmmuGQ<U!a9_|-}sKZ@7BvVO)H|yD%jfzaFGox-GKqG8$aQU9KLOYYo1n{ZTY%;f1&aL'
    '%-'
    '1FC_AWMuYu+FloB^L)8(|;q<!3KWmQM`#U_Cgn)<F7!p+c8eEN%3Xh2JT1XFL6(vi`NdfCer}*1&{Q;(h%K`Jh4AEV4{*1JNIA)J'
    'jP<XZm%yJK5`rf)|B2wN5tH+`fjr^Yl`wL9IaSLS#;Haj1m{y^4d6ZJi|lR#M-'
    ';C(!b$byC7ME*vk?(_vm~7fNXv9jPL49h%EQX+3AIU!tiUiw|<}&Wq!tvpP5Q@7wO*117S%HKr=gji4={h2IO_mxEEn6+=>KOqwq'
    'm<1S{4hC5?WIgEkAykF=Z=e=5Laogy{H7K>8-'
    'eq?0!iIN=2IuCw8HUvH6k8$?I(YjPjYUI8JO6F!Rkp8PWfWfqe}kt3OVkGdJw*J?GC#oNjCPyXy;Ki4gx$3@*P5WR+U|fh2T|4W7'
    'a^0`usWSCj=&S0wx{pM3crnfarNKA?O(qLLh~Rz@9+iyw~l%J)PKw8%fdjS>in#%Z*1fF@fRE8LX}2ooeuBk!$vGMoz%F$I=^{m$'
    '0U!?ssWlvui2-sio+d($;cI9ApIU}Xmn<*x~-'
    'y2!p8gV?&f5d5lKEm>3i@~wBD?3m=i>01pb&Z6n8r0?apdMx2mAL#><{hwOQozTSttsa7#T#+A_sViMov~pAO1C9Zv_ByE45hOI*'
    '8rZ*6&qopicB9wYpwDwVew76h*)m)FW9xP0MBvDar%`n-'
    'eAMShjsIu(XG*@r;{?EVZYc_wu&YN0@3vNl*MYzLLLOF8FiC19=Gx#Ga#_$j7g)+F%K45IG|-'
    'r!@s*douPOfP&NP;=FPaCt?#JWpm_p0UY4duTjf>dd_-!j-`XF^Xg`Y0hRJRUf{qn<P+Ef)i<#o-'
    'ixf@5e!uxnlwN^ss$hJ%vGQRK5dH7%7FzOJ{`RdY7MCcvdbh@hvN7bQAg<BvSiBkjOKMy#3=zS09>1ZJ%6gS4_9<UYjVFZ=nWHuF'
    '0jl-9W>kreuJ!%I0ZvJZO=9^r+urfgfX=4SYML1>!@e>z;aToELqC-'
    'oX{FDO7sx)#LAkwh-{y?#Qyeno8j$msEO4F+#a_g5Zm}D&6m`NcC(Mzdr2CsQd-Fal06e6I2u~Z9+5p!j>^QZlUN}cPT39?O5tat'
    'NKiGu<LXFpl_9Y@#i|n&j6Y?&dI~UzEF<PUO413$_pb7d8-'
    '@lMs)jozT%};uf8Uvg{51Pt2N)p##30U<fHYLt7C~|2K8cu)E6{`&l>$@aDRUZ=TR(FE^~Wb`|D;W$!|MS*HIZIz8Y>VrFCF}Jjp'
    '$`tB}UHYVy;ZIfGK`vbr}54brF;h}E`M5X9ZMZGzN$C#>Dn!hsWfp51{%ZGI@u)nlWL8>1t_!Le$WVMS)ezyB($0+A-'
    '2_T8RLlkt8k4L>x}z!f{UCp|K^7hl3K87+3VTcv3g39dJpi^K?Rq33-'
    'xG3>NQZHOAUIV~bTdDX+PJ#+c>XufyOwZeOTZXealUnAG|VW9j(J}&z+g1wM$Y9+L4!bt_9VqaVqAB9n0Y`vx$>Zsi73?KK6mAW9'
    'MD+ER(VI&8YSGx#6+niA*jH~nJaoDubeo#1__OF3lzN9U8+d@xm-MdN^czU@0{G6+!ay!U;x-qEI$2NZ=-'
    'A;1pHPomwN=)5zRe*+fm5Vt7PO0h$&@5|aVo_Nb^#%V~ks1GNuj?1{x!Yfh+GW}w{x>j1V!LD*VGRGS{rsHOCC$z-'
    '%IDGT8pNt5;KWVLt3F=Tp%pxl0l?o2hKzYEuirZ75xr5}zMi&`Inmi)%rC078*fxIc8{gA9(+3Dm8iHKxxDQv_U4JL6QZ{NTl0X|'
    'uJr5OHMvzUDrPm@=c(5)$U0V~Vm7%D?~r?;wNfX1s@d1>arD&XYWNeNvUoX^0gK~^X)>SGbcYMeOS^^u^>wc<9a?JCNSb#H8Y`!U'
    '-mkd~LB8@%?Tiog1+l3#ELEkRPHWwRFSi=np0cyS3HSEdTJQOH-'
    'S&4{@2|MI={6ClH5Z!`SaGnuyzM0Dc_UY%nZE&>%?Tj%AZUNBEuC}&WMwxE=eBONI1WdH{guVyD!SuVPh;7+>2IfiUb1#4B)=(DB'
    'i7UV{Y+crpW8Chc2Y)*6oDhli<Rm|Nm$tJ8o+AOeqA8sa6LhI`Rtv=R^O<0J{~lGX1CT0JJ`sKj^jOJd<kOXeulEJETj#t16(-'
    'txkMI9?^hOP4(oP=Y|9V*Va(dtX`2w|Fh(}rt?%`Qe1%<Yx6;~+g$K|`2cPp=<)~*Hje1Nl(xOpiTbZ|5I9cjV6fg*<zZ2Qw-W-'
    '(Gx||`}j18gAU(u!EJ%#t)dfH7BNB`+cfrP)%#*M13+Z8ad?nZqNbv{}bIz48By|BH?d_Hnd@IdNp;P1^CTJZ77tK13-'
    '!k{}Q*7x(IHq{xqEPn2VFGz2X@_doK5Tx79LUSPhB`9Y;Zx794V?S>w#22KkaqYHYKf#dz;In(L`%(Kr6b)CPmSy}^+i?<#E{S%^'
    'AnB#XM6&lmcHAW;%837^ht3Cp3ANp=GH$R=DW}}*ot}TEnJjDt!*=%!)(;*2@w}~=<Z4Afq59`E6(ttS#m8z6@p4;{DbXs7J}P6p'
    'ZT8{0K3F{%i&mqRaMMAi7!%k*y&hHRO)urDqdpF|P`{3V`Bd<?<<@iAsY}H<@iSLy(_{7iQeM4f3b3kP+BpRbiuU7++biNw#-'
    'DV)UZ302K9E;Vz^-'
    'rM&l7zSRC<;BrQKQ`uEDNTIBaPYfwt8xy0Fb=<d^xjq7?S?sNZOTH{UpqiBqep)A2bnNMky*W|bOqB9D9jQ1*VTISE&Rd6IpVJU}'
    'Bd-#on$8TJ>;vQm^*;xl{IeGTJ`vh|c7-'
    'E)+B)qZ%VSkO+)a*BsGcR=pJOiBBXN{MY9)>UUfS=a&vfX(<$^8T@u{MiS@`ezM=c?&t3j9a{Sy2K7Gn=voHPZb=i?rNW^&duzaU'
    'q~AHmfr`)KXA$-'
    'OyiP$8Jt0Nz4N0`wnt5*T{n>PFle~pj^O;9^@ac}8$EWto^{&1AOUdHy2~z|94EL`y~pB<i=W=H%v1SIupgLuGH>ntb$ZCLIruYR'
    'X@FDi)kNy+bz#&f^(ReA=o~%_mrd690-'
    '=cW+3{A%bi3<>^`zPJd&~ErTRio~++|ZT)BI;*(wpa7Vk?AJL0GOwbq5D^f_^M6=z57C^MJF6wE4d3>>{q+b}|Ayn+`c9+lPcsKN'
    'a@Iz25k$aJSGw$VNSdt&T_hq(F}iQ!77=Vso-!)_>c&D<rcQ^heR#SNFAc)Qd&i&^qp*Y6|O3C-'
    'dj&!<@rQ`<USoaX59W`<F7Btmycg^1ZnYbn5-'
    'XL6iE&h?<=b_tVmTFEYX4@&1{;5u4L{ko}1c8(H&t3!z=lAo8p~SxxVoVvBvD4ALQD7ksaUw^}F{F5AR>yms#U`sLt^Pj{17!Mnu'
    '%zL}O?4U1daPvSr?kV(Vn=;o9^htT|W_szIm@eeGyUFjRs{>IMJe4SQrs$Jb2np~+^{w?eY`%>_%U8~+V;*|@ll@ZT7jrR1Cu&w#'
    '%EUlNKePACfW-&QE*Dn^P0g}sF1!4|k9o7q7H7+$$=T`%*uSeTKyfe+Px?G12JDyiZo!1j+56RaTaC2Ec-}Pz+v0jad-'
    '7_ck+k7?A#>ses&NU*MEXzeKLD(0`)US?h4p&rh$`sakr%;qL-Hk=K^JkEpD-'
    'gDL&bFsdC~~;CQ-`}oTUqudh#<_67i<@=3t?s2OKVfOq#hIP^N13w`_G8g$eW#D<s_tGxqU7w>*isex2Gk3azzZWeUfGyBHh-zf0'
    'F24MGe#5C!b=z{ZJb0#Vh9#2OlOQ?yT!>S{&wq1XA}0soXkQYt^n!l`90RpTR=6uV9lZcaGz+vb4ulqGp6J%C?RBuP`tvZ?yQ-dj'
    'UC!)_vU0!Be+mPq(4~WR+;4uNyt6I;1s0IL|ZlWhn-'
    '*=mT=b=nL~kOs%atD7;pdQk?SOvkS%W9^6s872pfGpj|nR+5e3_ouoyXwixZ8dYuczET(Ip!}xM9ZN!fViuZ$eN6)Zwt#v=bQ*g0'
    '(jF{0?-3W$r`V_3|A{$<lGS)HEwwRo@y{+$83IZ#hLb!bS6;JD8(t+MQA`IWqz-Z8qp%X8%)ur%W$_b*{q%#y-'
    'D;C?Kvw2P4y4C9t!3!T}z{L7Bn-Px#(#?8`G_NDXBd)tIFkDV#n}^pe;Y{?PUxHmU+|jyTJn%gp0yn9xo!k9SAFh^wPdp<6v8QI6'
    '%0?~&{**ahy-8i&WfkpM8g?%QXITZt-N81MYj$1QQ*We+XD6OcwPsK=x0~y^@+BdMKU|zA>Xo)i&p4Fre6e<KedPL(r-'
    'M6p6^Dr?+=O}+!uN!nLLU)Me<6%6w(J5Itp#@%UWl9Pk`?$%+M4Eem}Qns-'
    '4>1ew3hc0r`a@$Aa@fgKvB7f?mz|9a4l`KdN(|$LtuB|TC)wQZB<DgCp{ZJ_m4Aljjpgibz;KK?#(q~kFl`zj27LbQ3@Z&iE>PM_'
    'IBFbPhPgUb!D+p#J<_Xml)}14~k`1c<!!GkeF(X#bdmBaS_x4v$K>YDL;RAb|&o2J66qtfx@%jtm@-'
    'tLB|S%1=_pp!I2E1E1`7g+-'
    'k2IPb`pq&)TQOBENrkf~HNq))M_kLCq0sl&fJC#_d@QU0dA~U3<`@(>O`b3HbEFadBi(MBKcB`<7=VO|JXOj07K=T>aU64{@yA@j'
    '_&lls{&D5NbQSPZ8;h_sBzBsYPO&U;NFnQESB0Zi~H4d=_*L41*a-'
    '8QltyO<pU(9c`7id~Q6>V&AqLZt&5Uxf2BE`rH7s#p!bRFWorokg|=%SqVYo#pvp`m$@x{Iz0=m`2xWof6xB(8Dc@ztyIzL?zyqX'
    '{(8|5ah0h$9=`A`A|PJZ+w-'
    '1QNP4T&(Eh0B9+A)6qsNR*J%8h4e7@+79`j!4CxT?VVoQ8HufY5RWg=SmreyW+S5?ayoW=L0NL%(C4SHJ@hbbDX2i~#9z6P~=g{v'
    '>bV`m3(%Z+LB6xj7^TLN-(Z!cYF_e~u%Q#DbfBZ+|bAcZsSaa~<Cr~{oKevbn8KkatBKbY9*-'
    'x46<C0g=4Ro80@8UuIofDNERt*L$UqTb?ajoZ?oTpE3?PLpZjorO^I%(@~b>;_*XcTS5R8~k21vA5Zr8$49)>IZgH7+Vr>4=&TFe'
    'Tx6KT85*_j;)FJ9B%tgb{a^w&`4!$m$v5bympGtp?R!1k*m{+6OJ~xV?s+Nmgk+OK5QsYuyAk(>}J2**DuTEQP^&>yJUsE)=|E&y'
    '$4EP?Oy`)>u}H$k5&`3^1|pF@}{74OZE`V4Kw?-'
    'e;0QL!k%fJ%0dwy$U4?KtAbi7$eY(SHxURdd?}1fsVaSv=$3K@H`NMoZjP7w9mLU{6iGSz7evVQL3W=zLe{}rgYnsiX!X-'
    '}dEMKN^G2&~DrJvinL*$-'
    'e6zjo?OWRhG4ifMBX5UZZPwkbaKwlvkam+R`&^3qQ*1bqVpn9)+xdJQzJl|g)@n10RtNUIR1f#{|CxVY$V@|C*5kb+jbk=Z+JzS2'
    'eI(!;r$uaanAWid|3zyIi7jK*XeTG|qJ_?WaQsA?-(;EAF-Tg2Lr2Q)lrgv(i9;r*vrljLWp7plia=%fx6_J=;FtZ}bx(swCb*l!'
    'W5#E*ZnIs#w|lG6WG~Azs#u}9#VI;ItDEsg8_ef*skUF;+pCHscsgC_2-53xrrB&U9^lO=h;NoR&k8-'
    'pnW|=Q+WO1Rui0XLoQ)2VfZw<JNx!y<_%)W>DBYIu-rE16llP!<{eGE=H?A=qb$dIGvlX!;_QTZ$TBGx0zeOmD9<Le1jp5Gc^dZC'
    's^(8^{dop~Nr)lfrZ`&zH*X3bg9!->N%}%@4wu)>lc|>r=thS~8YVfm}C#^ss5AKVGkI$~-'
    'a}Ymz^Tv6Swx^96l9#LXMW}J|ea8~WI}fmEd9B2c&gWhanagB6-s{-'
    'm{ybFFZWJ`1+D*L^9K~I5zy|g7hHw6SR%`gpLWVZGjf&;VQ+c1Sl%tV*?23JYcE<(E@aa+IEbV?49$s*FGH>M~7;r3d_0{T}KBj8'
    'ZJ6zq_ZhhPE2HGLp%k>smHF}$)LlO(<_7VSxZXH<pezm!;pQ(w64Y@+|978WDzfO&?a+?7@EQA<T7Nx?XnK=4T4{P!~rpZ}|R?hZ'
    '9P3HsZ3&XW6=$f-iq5h7lK*280J+i|-'
    'hnjrv4gS30s`RVQ&R+iY=sgF3G(k?MCUgY#2KRWwoj}@E;+_Xiy;H`0coeN1k4gX^Ij*dzvi3dOg;(g^Z(8L|0Aa2tUkuQZ)(hvj'
    'sqsq^Zc_u;{WD(~dTR&l%xbRnZaAO0q0@&D&kw$TEnJHBP&|&=d}J2bx(KbWq5aDJaN6vhN85F+BG~_$7&EmVDX8RDGJl`02N&<E'
    'Q*c}C`rSrrA^E#oQ_GawQ5#Q2$ekNG$!7nE)|Ih#8ui6kfA8%PB7-}!JL_SEMVb4U(tZ_&vKJ6Uk0rTS_#?r>yrR%TFFqZQ2-'
    'P&{qW7docvTx21SdDh@%6DdVEJt*k%Pu5Do~xt?mtBwSz(@q>3N~qS`S3;)8>RPI=ez^0zcHoo^kd;7~_}Od<l;Kw2LKF+8#0lT7'
    'h+Bu4h7UPoQLC4T5VWC)66ZJ}XP5Wmr<9Roldf-'
    'Fj5Q#(qe%^lfU4)MRH1^Q7rqC9yQ!t9qYo+)l);{Mtqg*WalOTQL4=##*UX?F-+ic_G@chA-ieTp7h{W(taArPhYKh=<LfdhgFmT'
    'YEk%OUD3y>gj@les*b<%N`P9lx`kfcUEyY9^0#vTc>rZ;YK-)9km@kE@5mi(#T*RbN4{sok<jNOO-'
    'f56U*9ywS#zAZ7bJvuB?`#)<{O1fz>WzBk~);Zn(#VfASFaZB|P&=<`|@rvsGqYX*ePrs?$q)Cd|!7Iu1dC5t&%h$lP1%~rB#tR?'
    'Gi_3%SY@5+yEh|BS8AC_KcuXZ*+tMQ1Wok?JpD!p{#|N5DWN((AJ2mrF*R>ffn!x)#A&7JsMvOw-'
    '7oH;2qA9c0kcQ55}#}X_h$Ywn64eOvDzo;m-'
    'W|kK4gWeY3m`b5LdoV#M$fWzv3Q}&|;9*~?Zc;dz6}GX*FY=hGOa^lil{;diT0dR2($&7{?n%W;zN1IXq*M$`)-'
    'Ia)dAWi6=()BX6-'
    'tkvpK|j;UhG+ObGw1e2yNbd7kJkEaZu+VE)WDS81}=`?d4_bpQhB^l3jB*l#0v%Wl?$Q#lxi~GDoi2br$Q5puzK~jsRxFZOaN@7@'
    'eEfs<`6#@v?KRC1~M!>z1MROT8J*mye3)<3JirFKNa#eukQ&g!|OJj%Wj8-0vK*i9cTH&1DhlqT^-'
    'sfkP4QkI8TV4EvNrU3Wx!Tk@0~7cUjzDrz5i&X(6=-'
    'OsPyh*Fue+HUbQE>%bYp_moIC7a8io80M8F;D*YBCp=@gA~{Bc5>>B6m6ytd3y^c<Lu|{!tLnIs=J){P=}o~$x65A7Gm#E+ruu5G'
    '}7kYnx~T94v)^3P=nfvLdURl=c}^YrY11Eb}EN(f;9m^QSJRUU-'
    'n#aSlPX9qP46TK&HOllfO+&uv!1ff=KZkQXhJZ&awBTO|+*c2ocj)Mm<`9@l5(R{3&?@WLoSN_pq%rMS1HFjqxsni<?c?<HK6Z;h'
    'BwcIF_Mld@f4WCf&HSsV;d+=V`A(z83sXxpF+M1?Ihvt{EjLvVkM$qxsgtiY7Bf6G4hpkJ@%waU@m?yI<{FHjul_7anD(r(dM0wl'
    'y%J-gJkx9#68%vfl#V=t{Y<TzpKvz(AV<#>g=01B(;j);T(y2yW|cPcbl1IHk=*Pba+Z^XaaG^~2x_-<jmk4-'
    'Q+J`|&2&zCZ10#`oq&yI4^~BWIAu)a$?r1dH#9;^RW2{xr@dg!y8>V$NdyA>yqoFhFDE$sN>q^QUoBHTVu#HuVK>%j^7zi^}w%$K'
    '(}#T)NGr^7#I>3ZKc(%=feNXr<#99qx^)#fG6!U_RR-Q}TTPY0X@|Q8bY28#&yp)-'
    'spaA<QUpcmT(L)pT|`pB>c>F%x#jOw$swT^5}Mcwsu3$)sa+Mcn(u<uw$5{Mp<DlzhcJyPA&Y6bPQ0i{*`f#@o+06pq7Re{1tr_<'
    '=P!jw8K1zJZkoncp7k@Eg<&=hK_+29wsi(?%VNrS<DEKa9)xXZl$b%by{=lwU28wW?g#b8O>Tklb$S=*!PqX9aIkb#`|iS)Jd1qu'
    'C3XDp|{pTC5d>V}Nx9dEf9-frtCxva24`xZBke7$l^7V;RQ4;?lvjtbyf0-'
    '2q*%#G%z)x;S=x^C@f|LrI;Ns@UV_tn+2(%S|Vkqp_v>W+TNVKAlf}VmiEu4lQ+}%l(@Hes$6>%KGG2IVj6mqk|47i;dbk-qgcbm'
    'h{4ql^3<bL``ZrdEK`v$HIhugzK%J*l#cgKz`mWW>C{=K3?f(u_6oNr$n*KW2v<1!x8&DoKbxAR|u?a`Nz>tL)S2%k1`RfMZ}qBW'
    'ezEI?J%W(ylbP~G_p_Q6cS6_bNm1-ua`j9tzayL*|D`Z3nHyO-'
    'u`KpF8iy_p1MriT0A(1n4OOF<79>{Ak`Qu=_8t7w&*h7=ylfgmQ{am+M}^jio(Ao&qGP7OpHud^yp<JWNpI<N^sq&iv1y)DoRF|B'
    '|65uO{bhS9EgMV1E&U{M@T>5&zZG>it&qIVbI`XGSr$1x&I`FI^A`quYm>dj?*};{-iU~M7ph8ik+@kV(d_Bc}f(DmmoRr-'
    ';ULb#16tu4#lU;6?On|@g(d;pK9%EJUvHhS%Qa&R6O$2upEhbiE-;-'
    'V}})w!>ug$@Wy(yT9)+9U)emjr;D43*EZI%Tu)n(Xxz$(T&dS;rS|gVd{(pQq9wf0E3_7=QoEu*sftVYeF5AwciRijy_lWn^$3<p'
    '1GF=HHf!*3G#&B+#v}f#8u#e!s@Z3%l@U6>{n{bU$!)EQ0XpoOK!xj26Q_O0%Di6h_ovlsfq&TiV<9*|TrYs!ZaV0X!S$3TY$cwp'
    'GoXQ`g*~TDnExi#?tT}lD7Dg$y2hN+Z_rg{y@S|0IFP=OKksk0#=BZ!S_97a{mpF?-'
    'hutL)n!M$uAI}iK?G;dNz}$>124om+p(HmkoNG-'
    '8c3DGW7}DjUQC~5eu|E3H9amVQoo*`G^*ZFi>kTc)3}3ZRP2;c6T^TM_DjeedybTLKe_@`@>#DTG4)>n#mQdD@dtLj(?cdgj|7Wq'
    '*7ZK-iL7H^0BBO|9)bQE`8Tl)L09$;oaty60`;Pec{=j)gW{n{Gd;hh_^WVyk+o53##+}APY;m4?-TF7EVpLhgM2KA2-'
    '1@IhV5_qTccBCh2Co6vmD7wT+cm8<X^}+U9_SQWw&qo+DcYeN-v-'
    '02NATx`<$ZvAX!WE?n4+KZgu<ToXhyP9pbWU0Pc~GRi!H=5L7?B+ieJ6);)7=f^$l2o!%hvoI;b3*UQ0XWsr>mx=pBL>};-'
    'sr|{bhi`>+~t5My)EE0HD{7JFbjh{?IF^+Yq;H}`@)wAh9U-'
    'RQVSe|U8<>7Q%YQsl=&PeQlR)%ftb1NUu$C|mBbq@20mP%XX`SzWk6AE!|UAgD6_lqR&=VYpz=i+cg0d%#gi6qsW+m&&|k-'
    'dsCGMszeNX+cxLVnSB2b`E26iI!yWU&!|`$gwn%#Z3s+Jv2WI9Y94X17MJCXN0q&RfC~h<x<^hvnmb53j#ceLTGnw<CPU)s^>hWy'
    '-A$CA#>By#-;G^jm@jUf0`JS@QV@eBO3y&-'
    'NtR$Ke!x&tA)<bnR~XtxJCwVCY+W42Bg|GsAUyXz@X5_eUFGqd&SsH)y?HtMmQm;H}u}{9Ut!1DOnyE!{9Tb-'
    'A)5?V|dP>IyTjGy<TXqm^gVRX;{0aXw^9U_TYPFD-Zd)-9V7%?*TtZ58b)+gz<>>QLM*j-'
    'mo0wYMbnd9fT7pp@3ISnqg5(cLSEQ!7k)q01h&I=l;;!UZuyW%`>0v9~>ZF&91)&|yPpb0{@leXcc%iv3|?g2wyb`Jmmxbm((kC*'
    'Krw_t<TpT=7*qLs!TMr(;05dRvka)?IeVR<trlEgH_=+iUoB2}%+?*lno7t$Ha<WaFGv2h=Ye-Vw0vI(WRT16A+_nYRy>rn$Q_ug'
    'gYpA0ii$`v&C~{QD-'
    '!T!EyCEY{%S+~#jy@#;6v6?dwu&*fVpUssXPIJHtY!F#cHUiRNo&Mo#qwbjb2x$ZId)oaAe;%81RLAAUj@@Nyo=6V-Q-'
    '^^07Wif*P-lU!j`+H^k2(-m(`0I~YSP$F?I=x};K#B~n+<!(c-0-?w;ssD)0-'
    '3%?M|#7D)B59;XzpA9I<p3C#m|fyanC{JFk+1_a)Z5M*mS@N!?bTJBkU(a_q;3cco|;)6>TO!*qjWk4mOB;smg)Yu%x4=1Etdj2o'
    'DY>+yxIs7+AWmTK%I*feEkm=QfL#({94!+RIdL6+B$S4m<CyLFm>BX{>W!C~GZiI>Y0lRN9aJFk3WOoXosj#V?x|;S}!i{e`U74d'
    '+;cOWv%zvgR|am~wYm2Kg?!GEN{6cRFLB*{&aVNA=V6s6+RcXC!C1OPhrm5*ho^eEu9wQlSQL){q0DV%QkX3y3xCR)8P2?(kgnDl'
    'GQQdI2fhwyhUI_h>3{?UCH4wQ<sjr))mHU1}o%tB2inBes?>%Svr6;HK}b6x7C_8@(FXDyTJ`=awoLjx|mg|8&`qz@hTE%24GoZd'
    'W7;%8J1PhY{@!jwNQ5SFTZr(rGbW(mROvivVV>`VZaD2cZx80h>D|h@ciJ7qdZ63w|<1^Lnl|=A_qv)%A_U<>J%xNS)?YMV1b`)1'
    'F!Yjbd6!6a0qW-8xfUPtE(LdFtLzRY(>u@Gyop%B!*(Z9HavyaJl}-'
    'VTSZ*|U6j@S^rU{I}WyBD*y|z)L#;IoEa;PhGIWDGZROwr>4!{+-@!K;7M47;bH^;vsW)RI0o8QDR9)r-'
    'Mk$CuZg*jv6z`q+C%$>Y%m2?sMKkzWGA#oS@dF>OZzYdK7aVe@JIwCQt6}d3G*!Gj9Ti-M^vVe$z6ME4QpdUF>0AVSl-'
    'x6I*#Mcw)3o>)zBqZdWItTaCvJes#?9LYshQl2;?&?{@7qnuE-d-XVSwzaGeAT_^fg5BCoR=2+&p5r8U9?r%A8Iu|*q3kOap%gn-'
    'PUo;dxWv7L01w`-x6FMJMbQmY}d66f^j$P@yJ|9O-a<%+T`0M1<6R%OGPkK5{><}^_n{zDfQ>TU8ZA-h1FL>Zq;9d^|v-'
    'X3JpHKqbxt#pyd9aGQK18N9ZYO|%sP70+8dZ8Vdc8SWMbHxt+fX2|>7U7Bp)r7V!<teyql9eP_O>qoaqO007H^VtHSWwON0S_8<u'
    'aXIrpb^!Tn>)>KhEB?TR~*m7X4noqAZ&yx~*YDBUcfWMpQ%v1>}qaD2-'
    'wR3IYo1Z+}+pTGrn8?EA(Y@6%dJrX)dT<cy4n8O}08=rrmI6tw`^QR6|y_l_VxFGhe7_M3KCAWe4g2fZK4<DbJq;4t5pS@l-'
    'fW3#(b$*+g+(otlnMq*lmGEW9ExxE)MG%TTsy{vR4px3Z-'
    'vp1G@>$a_^q{k8`DFWgMIIEO6_IkZaZ(2F1MbBlf07G}in;$@g+at8VmeyqZQGkeIS?lfG2@s0VuyUWkOXc{Cog9*IRpnG_n`b$n'
    'hNl$?*kj>nPw)m#u|YwRx$=;hBqw+L>W(tGns~TU)voT_mCMVYsm_=C4MAv9&|R9cr^e!%2&gKi^6Qyv$W!<BD4e^K&B(psL;=7i'
    'O(KtB;0K1CB)(~y=yb7J1N6CR4=M<}Z4_pD(YC4Etxa#c$f`41u9N1M=!n{v3!U<WZ9$Jtt=Xj9MbiPYm(*zV6m-'
    'be=9IKQsBzMO&EsS=!){3Qddz^i>ps2kGyoVE_tdUiJXYVzu`(SGCR(Ey<r}+#fS;g4$-'
    'VxRM}wwM#Wtd959XyXc2U@P9(G2uWMyHu*-tNz{x}$4lEr#=oQ}`!_%kKoq@cg#LVZ_iK=NW9&a3az+_)-'
    'K2kpP$AYcqb1J~W_TmZu_Q8@G*cgwA|SOuosO68=U+^P@S<eU(atQwQ6)j=88D#uY>xp@2pYSpeW!zmf}O@XS)&Lx@L%v@v_DD1o'
    '=m%Q7h^Mmnt?N^&;!)sh5Wm2kwboF}W&=*g%@Y5v8ZBET<<(!#y<Jh9GHJU?Z&Rwbd!F^3!<`XU8U`?$@8PTZxFhxk4@MGpnPYsh'
    'Fw^M&QE?}G9)QabE8#8E*Z#mTK!Rki7RjHn*+qC!a=b+5v4ASM-Jrl1Vk?Ezy_S*#46vjc>$3Dv0#7~PZx@^Cbs24VV!VNx%?UGP'
    'FLsFB6c(zkd07%ZkmH`c|@4#do+A&js_YG^^o(DbY$#?ByJv21sICU0B;%yCXP_<h|WJ-ISLB2(X<5Q@R*$Bz?q#WN&FTf9=*ShI'
    ';l|e+laf}cOTafR^+bK*Zg(M$T4IEQlSZ;>XMO~GTfMf(V<F%TJ)j(q)|FZ6=`y~{j?dW>5D%q(3OsmeekUV2jPoIT}9FBabc^+{'
    '6Z9hX#7z&_w9CR5%rX}MW&i#0Uz0ia6`15KfNREH;(JoXJSTlCx#=GCr;4^JF(?dOVx6`;->?VYsT|_%7nD^D%>3<Z1A-'
    'mANK?0Mcg?q~c;rB0T_#Gcu=$wr>r;<6?N+0OU7%(DJtIv2ekFM9kq+DhD`DTTDft$kAkER#1t{U;?o$gxa&GU7YhMf`pQO3ZwWh'
    'pDYk?Ln6o5y4!mm{{p^jrkL`DPDa$cNe5oNm1;Re-c5eLE;lfno0sSNF~ppfsM=w(-fbB6GApOOr`yR4Z4!%wBCp*ph>~x9g-'
    'BR6mS6*e$ycP|N3w*%{j(|0WW6@hz{5Zr^wC4AnI<OXNPa%{4!pd8vGlx7S8n&bf_`;-'
    'UzOHZz>Lbbv{*GQ3Uc4F_M*Df@RWSc12*{H32Dy<-'
    '!S_DiQvUyAyQbZ=FQ10rh>jVC4ZUY=Gckt#8#c4@0gozVxZfirtjvP!d*$lez_8zqy=eVhjLHX2w&^)YKX)6%=z7QUrfv1)u*c7U'
    'fL{c$ssusGP3k(JvuCYpF_?T2t#Kc;FdovMxFjJ|W%0WJhz^wr7Fd!w?o%!IN$*^64K*`B1G{D|o)&dyE?8hFUeEpz$U*!=psA0t'
    'a2LAtfh@ckv1>E7=VvAfzzUSn05){eOe)Gg^**e~(h{iqG-'
    'SfxKF1$L>vH)XW5+DPNI%&ge{TU_Ep)`g!;6n?7%e3T2{=?+tU37rPm8SY!j=1DAoO(8K%h>gP@zl)OxXRskQBb-K#9wS%OF-'
    'Jl+SivKU-vK1Mh-xIkxL<oS-99eX?4CJP?=H?tmNVQ_1#YkGBJ71%=+FT;=OX1}M55f%f-KQQ2*ht$csxH^*+0*L>eDwmQ-'
    '8d?AQLGN`T&v3Yme+uF82oC1VDd4)A&VzpYJ|z14eoB^cqy?D_S2EplnG|W1qn=CqL<^jcT8dI|s9Gv~RP4INc`PL1x+>*|!BQE6'
    '`J5B#W{p=*o1stz+nszgHf!-tI>?SZK<QeRS7-'
    '1{pi(2%9!Quv($^9x48PU&zZdOg!ePCJfP|rYMc?HHNvM1^Ik5u1vZclM`ME=5w$yD<?C@(%sCk@=Co~cS~Nx;hISQ<Z#&|>h<J9'
    'RVi$fJ$w-4U~(94Bm#JEL^Yr4GIHX^71o-'
    ';TgXQ5)Xk@djYavix(%)`^Zwo(VeeKvOr)LZW4LyF)%ADEj5D3d8MCjytQ@VourD6FgkQx0WOjNTDELP9Mh6OkuTU1w%EbtEf?)+'
    'ZxK)olen}vm`X*RJpqcCCz+o}pV-4<|bNq5BZw^vdp+KYe*(D*!iesVL^sXr7!#N-'
    '7MNbs3?ddgeuJ$d{3OBvr3mDtVVGgVtSg*7<<KDF=%{+oNG;KB$D`u-TBQDkoYcV54!Mgsz-Yj1Gxrmph28aw_=UxRlTxX+EbJl`'
    '$)T&#5V;<uzHq>YP$lYX8nA?f*L)|(7)bs1@6rJIVm_?)f$aBno8lQ@jm6bdd%}e6+Hfk{YL|_bl8?#D#$TOrtu5GX}-'
    'z2R)<#zYy$SSSd?5Ib$m9&o-'
    '>87#lg$jFgkskO1Lf~0(o9O`<ZJ$!DUQfbuba|uNDyLSKLKkPW)?ny*iO^YNH6z<r9Q6#o^?9F17v2j-fv3mi^<woK_U1BS<-'
    'xw{$izt#K49&)W%kGc#LX!~og}MV7}UtexxgOtg`97^*T!8EihOzPqVENn;+GiWq;mD}m{pDTCK*i;ktDK1%ON`buj;R^7SO7F>X'
    'O4-($J-jaed+tkSkN3ta-'
    'V)x~H|3%Hk#_A$8Kh26QoKlI&1kl1yLGH*P$t9Ps#kAGeKdedy^lLPX)SzO9RW>~uO_`}ggSGaI?R>Quizlfw1w-'
    'k=L~^mMjuuEk~_8x*-z;U2j-cF@Bc3o-'
    'bqyo>uX)GKZZ25}^3$Mx=%@53hQ*4>XK%D$HAtNxfk#dF*V^Vaek`qJ7#O8H#`y4qcO6^Ql6R&MwK$2GXkoG*2he8--47TQ+auJ6'
    'hCq7<4Ur3r(bJM6^7r4I#Ky9jI>?5sR|!$n8N`q*w<jI!Wyn)la*V>Q&iaZ{_gzRV+Lxqu?_Dd*#_3UeHZL5-Wu-z|UKn>fX-ug>'
    'S}%Dm@KD6Uzg9o_FFn{ZqqQlg+-I^R9uo^%vJtd1AcG+jy<@t9u6d!xs}kIoOvMGxuWv*W3<>gn`m*;@=P**-'
    '5g050gpX1Ig9?QrekP5;_q#RZwu?ufRstNb--^ea&D%D=9|>mj$Uk~9!7oP$z3pj4Jtku3Cy+&Mui(6^eeS7Ju*d-'
    '|4OL$fepy&B$N)mtcTD{3X2Y#h{0F|YYAoluhbY%<E)K97*-'
    'YfF#OzBD|5yHof&b*XFO)gn%!&Y$h9Qad)t$KZR!3P|ka{<;f6qL0YE@nFA^JC_^Zd(2dE9_BA}Zpbtlg-'
    'B69sD!UNxda)PUW3nbRxqbG<Ics!w+$7h$9eUPQ#XAhpswmJfn4c0%ay~!g#Z<<HqQ*L%H(HXatnwsZQ(Yu{6O0${pzsQq{V)%#a'
    '_hYVCN0SBvsr`!^sPJJX>VxGz^qw6xiX-GINWdm3Q1zxGy8!Vp!w9#ts~-H;x2Gn63=5LdBUu@ha&!WqZ_L7uTQVP>iW*BP{0m!-'
    'jm9x4BWg!|Nvm*^A3tyzJ9bd-#E;oK(R(E4;cHh4+gp@gD3z^OGtR&gd-tIlM~JZg`8B@WElI=jZmfZCx#?rDJi>8jQ?r#FT(m*#'
    '?T^;p_@W%LjSnOOW{$elAuqwdj+j?Vh;9d#$drD=nF9#<#(#b-pD~IRzJ`x6zK3)r?-sd!eW^i-}>*KEH3|Yzg6%TM-sEne$DKnA'
    'evM@Ub*H7jQ=<RuE>ho)0tw3yCjor$1}iF$WCh&62ORJ~r92RKGo#xMRt^^{qqO#V^@U=`qE%fxWk>%e^&*_|gY)5b6oRPLJ6X4i'
    'vpFoMd=?cZjUl9VT@kZrIf7bSa6$*<`nku!=D(5y&aiH~ezQ-Ws>M#$pTz!i1gkZ{1~n@lz9=^0dM#-'
    '*WQmvc%vwW)>R8RGbxxAr!#bAZu4QgO??vN77S{gZuulDyPMBBM<PyCVbz_!?*H;^W$uEPjrnfllB&8c2e%nD062iT6waSDL;<?$'
    '!D)#4>w+(T|(RJCMSc6eR>CRKcTm9aw#j(6#!R-'
    '{pEvOH|@rNmH2LE8RPEKiRhS*LOtV0cb}h>q3sE5;4Uc8;|Jp;6>WcOw1fKlCvJ4-'
    't%j_EYeeEcqWr$Il^kRHf_KBAI6{Zu>rvP1)XKZB#;Z2%H*(DZ6Tl08yn4C2+18@-'
    '$LHK6pw%ws0rS?!Do8mSmbmIo9b;Wn=?AL%Ls?4zyAd@yi&?nT<4vd6^9)cd&;V1y?q)9VUAuRAe$T|yR}(tiAxi*C+K3NnMVET<'
    '1wAwvMJ@8z7jE>J<wk>!Oy}LuK&n4U(7k%`m5Vk3n*41J3h+t1rnBHVk8d#Wgx-s9iQ~RKyEL)=b6JXnRX5DH==r<~_V;A7_p-'
    'Y5##9Gr^;|J?KmfLhDvEG5QCfV&_6@#iV&zcrKils$8WAN=GzJ4ty;b>2^O{KSa4g?;a238z)2&@bXRlK^SNS5-'
    'I}jI|b(NGF&qfKNIj&5dr6r<j<#xD<taI`P&5l_NK3g=fyJh(r7RW`hXU)zmVqO>)PcFUkta``F%T~V!E+@z~u_`B8>V16``GPit'
    'vpcy*O>1YzBQXs@vW{M?tB4JQeAz7b2Z!`rzh7@-'
    'ef5Cnb2L%=TBItqi8Eu&!g=4?r2ImDMGOSn{?>ELi27;aMddxdAB?!`5BOb~(;YhSIDTbPcI(n*oA7+C3s3R0=%)qWv>&&qQxDc%'
    '?JIt&l)vxxaV8g|xg&UkcJWr;jK&qBY*db1R>V|6YjzaNy5xD(KDYW;j^3(zn|eEfQ5NQ>4K2*B@pUr3PH649a}mlS0O)bRq|`;w'
    'hKMeHj_x7d+ttiqbgXS;elwuG7B)agOuiwr-Vkxui!v>NIzc@8z1a)CSm0)EO7|DOu#}fM)lSPzIIQ-cP1x-2=BIn%NlANe-'
    '>#o?)U1?K*MY(R0J@l$x&mrkgu$!xVz6QQ>Kx<obb!m(`%<0`3b*P?MS6)o<TkiNmer<yzzb4cW8~?zdK^DDu9M6Ky!$M7HVb8$r'
    'mVJKEibcnQ0zi(1!*pRLR%>*1C&wmQ~~mx+8EmSPxYmhu7%zTaon3&xvw0&sZf{A{Ltgym&~R3qQ7V?*Qfj(aRRb6%5nCyeXBjVh'
    'Ww)Yq?&#}MN#|g&p^YGM%UW;rzE96*Zc5|avmGl*Qn}YDIw}j>e-EgXfaLJF-'
    '~t_SRXCgX32>z#jR2tvi)1suM7s}wK$xM_bt={V&_ZE6RM54t4)g4(>0cg9NQW!;(cBjwgC|JUi@Ox5^{AH953*-J-n3cNg-yJtD'
    'e|Mf%CD~$aN*#IeNG|TF$@u6mvGr6ztG?3_-~#-'
    '>2YAJbTuyJ>^}_9<T9*H@^;cVv{GxWrywBtCCc2Vz)fj#&<hcu1d<vsabbUCFd3)g4E;&)2!h6v(e&k(==>l!jo_DKfO)%utp&tZ'
    '3)QGi#_#76ac8OJFLb2bl7OP`IK-VIQ$@lMlq#PJEYrC&K;ofZ8#V;)Iz6jcv7zX<uH+sg=D(vVQm^v@TAyPL@~0qjpf6R7tVI3j'
    'nW5$N`3`-8>`~H+G{RUfcR1-'
    'BIDlW2p+Iyff1X_XljMNK3@on^TC``IJ<x@IWG<i<5Fi1OCjxxAxY?WWyBt&MIF|iT3G8~mx{;SfP+>2=68=novl=Qp}nfMPP1J~'
    'NJ2F3y_yRdtXGG_<MKvaDx)xeusf3mu3aACPUPy$Oam^JW^nJeE5%{otNP!l1kEp>=I!TVe6{mo3?1)ER3XpZe7>iW+eq3&o>Bm2'
    'zFX87y{(^$Ub^`@Q<xHYHlgMvP~Kc)&hN(eMf(=?5Wn0<)os{3#N#%uwb7CDC^jd|_;@+Y{-`l_2j?J{Rox5q28-'
    '`lQYhQ4<VS<)vn4KD*j%j2&C`UM0uS?t7goSqysIv#!GW9)EbD<4Odc6SPv$nmx6)YL%rmPCcQvZn_+wIGOQ~4aKlb@ODosAqi;}'
    'w@GP#4N_(V!Z3a;$Ib%`Aoy|zko4A8)|KK_Hu2;sN^&B69LDlnJINju#D!!sE=&2mTX_?WY$!IM}Y@1sM3%WpQFlDe^0?d|~CY5d'
    '`PxW#%ib%!+UZowXu^)t-'
    'fOrX?9((@{_=l(~(DG~X;KKJmYBZEqxzxrQ(6&@hzbEAX3ZB`P=f&UtDtwv?l+<Y*(fD!2Dq1!FUv&#{^8*Nx{cA2-'
    'xS3@W^$2ia$oWs-DqDQwvfcLmMcJ~FWhuwxjX!47gTT_G5wf`g5@Jh&!@LZCU(gT{zPLaShCH+gJ<f}QR;e%#ygb#ZDvZERj3-'
    '8!tSrYP_C5f~hT2CQnSwWixzFhBimB&6<c4@lRR+m(`Z1GZ6bGrl#nZoQwZe9G*8(eWCc^7)|V)6~U34yEX(`0$THEK1bFq*uZFK'
    'L(OR<6GsfFnGDme(vT2uo4lPP%ACp0(y~HEI)iJEsnj&8;+M-'
    'RF6mAJVyUwVg68Li?U;eL(Sb^HB3L4<2*_Y)LGxNkYaCw~yClw=TTL=S#{WlkGE$7<GAW%a3#T=tTbeve`$^{o7XzZGxgUbPs@hZ'
    '~(^}uM1w&y?UjM9l3$b^d~V@oy31Qb3EmwjH5<je0!Hx$SrvcF7k-V4vk%@HlU&jkm%;~5M#Jogp}?YgBWN~`zQ%-'
    'R>5}0*N6hGdCE^0ccwagHzBI%Q`}*nbfKmG$~Bbfd$B%pLN5?)!m1#|xO(3f&IQ<Nzr~z$A}%%JOG{uGLPA{0J%lVb=$i<oyfn=+'
    '&A7g2p#Rv&<Kk+oB)4zwb=@3;GlhAUwwHzVobw#1_E~aEPF-'
    'l%$FWKX@4BJGfw{%PAx1mkb;3}t`KH~I+#wdai&d+$Or#HU#HjDt*5X;m#QHHD3|cz2pLg8(X5jvWZy>$a4J4pZ?uB0E4OZ*VnN_'
    'nKJl{FAT741C#{q;UK;O+}5zL?~=3_{VH`5EVhK5aLQS3}hjmBvgXyAPiiO+r`E`4(wQ#W`&>8{WLU4g?!OprGEgTnTz6vRV<)%W'
    'w|>>z6KIlt+u=QqwTnSEhiop(6*#ubm9;gLH7!9oM4aET5&+{d7<FUJoRVMU^WbZ8u}RDMz|Uci=Lrn$2?Di5pELljLs1QY10b{r'
    'J~^9jO*gJUgKVR)>Vn8;2gC0Dg%zDNnvZf81ix3}uR>wn%OJN^33-Lg%{>mXFb4fC-'
    'B`e8V4%YB}>Z^_Zcb33$j4K@>1nvA1KcsaFJZqc4hb2IL3RjyNAZxD6KfApfa79P83ck{ZPSCLLnfQq*?3QZaE;ve6oJBs&9T1$+'
    's(w_}-37dDYMdS3ap-FMS+&#0Q^QeO`Ub@1bq*3t3e4OM3kMphWi2#EF;B;OC8p@Tz*10+^Az{T{mr$&|3vOzCzqqH)<_DPik8P!'
    'beYPVmeKxaupWzu6C>pi<X|X9x(CmoA!(zPi_Gnd3sC(?2Mjs=pm**2g-'
    'vxxtueG^8t_VK%cdgv5Q5`XDB%;pg;tbJ3nRzlU7FuBYwQf3<L&vqv_X33hTdfwm&P=YZ2i_%@@cq`keQ6uhW_SENqNSVCXlvWe#'
    '%vv@lfEx4+!3`0F1!A>+#Y?aO)WfvRXw<2)pd3REy3R{zJv!Gm`?gmHy2EgrB=He(%p6=LAyv9z9)YBps&|XXm%78EG3I+g&sTO#'
    '(7l)$=0ztXWzp|Z-S>QWd}p_6>)ZKBV_q0Xr(pZy%qaQK^LOck07=FaWH=pt8LzSOPwSc#_N-'
    'y&D4IKZ?g$bhk!YH4cMI3kD48_=`_&ux`}^~LxrOTbE>dh9m3DzdXueToIf`k+;y)aByHqNP=k9Iw5YrC4{xMD=u`+Z+V5(sv;Ua'
    'kNoy<JD7F1AZ?)$A12CY~03Uf`DaUr`#~mo17P7Y=V1rOUD8P1owa&r74FG%{cT{^FnSAmsXGCb%E0=3)0I2Z9%|W~T?D(iXo_mQ'
    '}zLc#y99^RMUaPV?Sg2iM4X&0-'
    '7<Red$#+*0L3*F+v)QmWN>*<7?arc_DT$^hlp$X{ChFI6J=fD={W2?@edsnWT~ziERt^Z$nb<^YaHt=e9jWJT#Kqnoc~dX9t%h}v'
    'A5Jqhk7RSX(IUjlx>S}si@x+!Rv)EyCg>i+Jo4E*kjT+E*sqiCB!DQ^@(`O&M?UA>e8Cibci%=BBz%>Ihgt9vx>Q@dN^f?NUT&vS'
    'd?=T$=bqEH_Qib<n`i`}rtYX!DCf(GCQbs8Vk-6Hq8}|Q=UjAr{{-'
    'f)&Hb`g0~s+!qESWJiT8|L&Cb{BYd@?jg_La|7dXuY(9lmuZ(rPh6bf)zd=Q6<){m5EM9hQi8Fab>kRD%DH+l2<tS=^e>)l=@q>('
    'OjKXr(z$qqesdGQ;Z78Arq1(4;8YTxQiYyW_Opo=@>ik8xL*iIINax4<^RtA0F6Xd)YZx_c(kCvD5K!B`*{;~VmqEvdGjN@fD6X8'
    'PtzNn1thFOd#|C{)*Hrgn#3A=~FxxQ3t?pxSp!{&kSP|fkof?`$xup<b~!Z9)H9`D&n4Yf<!o(P-'
    '9a*M2kcWG|+ae;lR)jurQTKT>qkek&ezRwZa+sUP?v~+pd&Bk!0sv^n`HKQ2cwVu0z#{rdX1;0_gRm3f(hvbB5t79)@>`a7Ozj3D'
    '8aEET&P#4lhS@~S5;7kCz2E%Rt4o;q4+q(nhN%`)zb+2b+bDHy$_}tqB(t3r3U{YgJ`DC0a@NVsI#S$w>heS~be3Cp-'
    'i5V9b?P0q)EET%fp8hDwZ-'
    '`wQzM9me)uUF!;NIbT%JB7WL(JoN*h7H>j#A4tOC*3SZ0o|JLtbfZuEpM9+2~x&YDey|7MOFhV>r_te^#)%(WNaeS#3S`<}Lbk%2'
    '4NC%60S8#Ur>~`=@A04i_$*lz$woEJWXs{oS)Me03=;cbbK&$yVq!?Xx#`vUD-2)V$g?J#qGDZm@w)-'
    'u$QE%5*#~udwUUk~CyRk1TMu>LOvXthYMouxK*TdeyKt?EC8j>uddG#2V)Lz|sSTK-'
    '4pKD@>R9)?~nV^MHOQ%xQHUlzXKOYkr=o#)FNX%2C+SYF&hRv(_>7uF&LiM}0W1mXFe!+dS|F1QxdF{OeHZRYMRgZ=#GdE6L)iRt'
    'mv+6-HSKuf@D}*2@?3nI~Jw;?b&_(u5+d{>pjI${Tt!-'
    'TCF=Ov$W3tdoWzJa02=Sh{b{^Vulw`LUnTI8cP^Kg!}lh{NQvdftm=f8VL-xQDm&(mOx&gMv4Fz=>+&{&^j-{kJ-lm$~=-'
    'qKnfRKxK;;&XuOpP{RtzOc)Cf^b(u^Bq=W!esQ^4`dH@e4*M<L{@F2L1@FkiQyy|7Y=yoaY;|OoK1dXhDzg<9cVjTVAGJ*8I#azT'
    'KRQ|6`|_3uO<;P=2`Iex-1D@n9I$z>J?vuY+4g979hXkat#CV!*-N2XpCzdI#zvj=qq=iY9y+93%r1>yle&-'
    '{#uW=_hx<;V^;?dAvD5Kw)yxNJ@h3j4g9fRK^{IAm*hUrkeW^R+1TR>f;{-'
    'j5t6XJ@6^(d_aHQWTiD<V**U#sj+4I$qSdZ+|uHqkXF6WnM_K|&0x9Q_r%@>^JeW8zcIKd72^?H7oKQ`V>-'
    'B1vvx9oJtHM0(9jXppf`W<&a^!7qr)SU!>KMRj}B@>&(M{%BwIn%H2pZ3>ZRoNVs{P@(j?N-Te2vO_3*eiTRE-'
    '7F*era0||GF4D;BtxbjUhC=Q^i&MSWNPF^<%1D)s8tT&Cv?Mo&0REXu)(uf7V2QwT>$1L3d}FrB_#dYF0xrjst35c$;OgZl~)9Qj'
    '(*gQ+z5^-zRAP=V*MXM&&ob!&INR>3S5Ic5XU4Y4>Tnes~n1h_u^BZ#IXH&oq+ndRH&@i56fX(sbW0u-'
    'wsiAmK7KJGnif>m#QSk=UtMnl?D+)wYEj@I+fb_30mCHWeNTUSdNnhS09MFGG#hX`#;Q7VG*5To1{KVv5YbORj-'
    '7pvxEeC`i?uUp*&-#TD^|bt|093uu{5wnk^3o_3?-'
    'IpHtke754IqZh;eq&VC=Zs;epyDQ}1HCA+S{adj3a?Gv^`@Y|aq7yGj1NGii&!P*$5Vhwod%f&VmX*oEG|~I;&Aw>0I>U_Vu@krY'
    '#qgdLk;>w;cE|S|!S=UVwW{ZM!RPUuznD88%{hCs%^%*Ro^P5pw^}F<`cWs|^Q}mfPupspldmf9fGp#shR0cCBE#FAx}a64F^5Wk'
    '(8zKhv&~ocffW>M#oDgVv8RYoCeca{+)br&H{YG%DVA%F_!CGvD9z@tL4m(%N7_b@Dy^T_t>eeCe9L|0{Xl1Ne*<Keerk?xK?~S2'
    'ix}0VO1<kJgmqy8I~(9o%#DNK3HP{c%@$E!ou3xyZoTq(JN_;ZH{DWTk4DVOW0-3S<OPn%>>Y%adP@$gT?7z-'
    'o7Qex=yQWta$c%B5VbKbt7G3;3fDF6>ZzS1LI3V(_w#NMjOx3E30IT;rv8X6?38=1f1D1u1QTz=oE1c9Fq^+^AKq<?t9l6raMNnm'
    '*te#S(5TgyO4K!9$y%({D|K=s^-X8CT4;-%=5e(C2E7w~rP*r5WTTuTsmB`ehFRZ#%zImve;2Cqjd7TCy2rrxF-'
    '*SBOKvqVH!Fh~$#1z*d2PwVvGuGs^Lrq@yJ#|Au&qw+)-?wv05`Ku;lLHN5JJ!F>b5z8uJ*v$na<^u-'
    'JKoh*;EeO>x?MRvp^^bF#9nV!5_a7NpA{4(%jzchpG+FWiotF>ENkkJ>vYfp9F~yomMmpk(eSOFc(%c*N#4b-'
    '`V&Y&qXC&N`U+#(<_4ZHWLEQb*zd}eP2MyYugTx2a@RL1bPwZP;KMx&(YfNs43jgiSBrHQPatE{Itt^vC;HvkHwMYy%SWaa!h6Du'
    '~BPz8sj=gZ40@?uN-hqlJ~WnbMBPsR=<R97V~i@Tj_1%Np9&MevDE3D5F7#lIpJk&t&Iv?L~aUoz!B7bS5u*Hra!Z{!5>?R_$z+e'
    '@BPMty<RfxH3d`x%Z6kk=X)h><B1t<TCc5`z6jPK5Rovb*xk(okLl)^v1s7;JBDSDFi%B;ty^*nCQ=DLFDvx?P8+2z1WTRB?O9UM'
    'PIJu#I^t|yD1->M#d7F$I+mMqw_nVSB~ZM?EgQ%0KWjh@0M-)mR<fWx;eG>Z@@3Q1l9FHU!;G<e!V>|cKG|$x1y81{QO`3O^-'
    'iUoxo3RPme+LU)%q#>yCS}b^X)vx9&FbtdnikK8<?6{ad5U#yoCzf3^GVm+%q(e*W_g;eY*WGjDVLwE6E(qwlxB*mv73oBsLoxlj'
    '4~wJy$90!jbl*Z(<`fBgE}AANoU{{7+y3V!wj;Fn*1v25qpKcDHZQI-'
    'F=E%3ko6zo4o^%=mw4Dt7!efwvdKbyGDPb)Y4mG?dSpFRJr_x}*$-'
    '`)Ri_n(FL*P#B_Z@*T5{iE0C&u<@T{*SKzD$+mN{ihbU{hycr>%YGj|5fsT^!h{A|NQ)Clfb@3f%o&xzliGOZ>&Eb;vc_;eiWEL^'
    '15sS+q-=v{f}SGy?e6$8qDv(=fcgsxxQEa?f2ilg8OIlzXkShui>8;fnWY_CHem$#s4I||0ubC-'
    't(9L3(@@BJp88&{_(#L;a{fS_sY+_`#(q^v~Qc+Ehzu%-'
    'T&F<zyA{H&u;<$@eTbs#iuiB#nIwtz=zQHe*fcTh2`|*ZvR~A=SyIRVR^d=Z5aH0+lKyH{=by}Do<MTH-+^9%t~-'
    'xIh`ggQQ=9a#1E#|=>RBS#kz!0ShoI%c5+m%sk#Xh6pNdfg*}-eAfkosKrE0@&Rv@+xvm{g_JQ^bD-9}<@Ha(D-'
    'YUDE7uT2QLTYtprq1uq{F3c5eA!(b9?b#VY!>3KfOHA04dxZt9oA7W70i5a9#*tQseyEbQyZr%ammkkj-'
    '6fMn|>}Z_`F~w{qxjHeyB#Nb7h`xuS`J9JGWM@Se>jlpitYZ*otX;bq1hvlT)y5ev=N1CF4{I$WygKO?u~1gh$56+ag6go=OzJ5k'
    'S9N7-OyipsSU}SAgig0(fJ&;)h=8bd~wNSdz=CRBVxVVX>!YuNYkry~zrl_be=)EFakQ2cBMPtA}=-'
    '3{;If<^id9Li&CfgDqq`>d<6%zt<ldd0V93Q*2!~+Eu<+A@Ysxan=Oum9L*I5691u0PWLuWvX){$%z|4<F+X^&*UvQpVdwCCK*?|'
    'v548+UHXRQwU@1W+sw~RVgpwd>M~m7w#T4Z;qcD#;n{JLyDlSjF6FuX3s_I9ud7#1qf@b1`?_hchs+^XxpNMKkIh^nt4`4wsh)g+'
    'nhkAwKFRmeWqYyEii;VurD`eO<cvjlXS&|s*QdC3MjyEqXPkn0=P9?^Zx>x@3$v}MgSp61L;HNQaz9?W^wO)zh00=J7UF=fPeGl3'
    'G1sdk(jSvhyXu_XIe_e>X7ja23j`#fN8RVf{eUgSj3LlsmC?W6C1?gb>ZfzlZwF)xM;l|Ycf{bjlWbG|v{)2rEDv|O15fY<t1*J@'
    'J>8ng&z3QaW-'
    '^PKYM*>_PV&GoZ6E{62at8^H>up8rjt|xH0mICf1I)}qdZNG+!W|eAy*K1P3^uYE9tWLY}y<aPYHk_Uaft99rN|c&MVRTMcHYQrm'
    'uu{TxnN;gwoD&`NcOjS*^er8)o0=%$E=Fo63QmgY;f5V3S@Xoo+OQpS+mvG>~P}nR?r6b{JXb7c?V@QTn9c(-`LJe#b-'
    '~O)%LDU0ZP^zIs~m$HMsQ2=B&~9oW!%u@4UFkNO*>CfOwgz+<^weBSp`#7_qmM?=^9N$9k7wAtm`G{nXGv8)rf6Bk%13sl=V=4~4'
    'bUa1y|<EF#!^HUnMO#J$iO7IV-'
    'z&o$?>f$4yqNz4FnD!#v?}1RabBp?P`g;53Y17Tu8!uu11VFqxnNM_jC22?>2`jhN*=7Ykn@+@Ryt2}!1C_SfoPMSV%wETRwcp>g'
    'iP6tuJH!V`!xzn7Z-_B>?NI6yp+r5IM-'
    'z7|{oJnlXid4SBF4ks_YkCRBy4`%olmXyTD&$66S#6HHu3$rVcixxC=QG(Xa^>KxliO`IL);SDizBaf@mYF0GAt!0!t`10VLbK(;'
    '@t8y||wahxO={gR`0B&21b1NkE3{g^(g}XR^@p-UUr8a9|2~wSBwW=>TX4R&B*Rj;%-'
    'TQJTm6_$aqgW@w4qc~0IP2SnP2YYWS)vDbn5*pG9yXJub(e$B!GBUK>D!t~|&=GPa+KImz=O2`zZ`hL+)xLSK&*IBUX!_xja`6$|'
    'I`%%Z`;lA=-?l*bHId36Zz^{;Yo148CUfe>R*lm7!Y9{vyc|YDQsjx-'
    'rx1z5Wiyv#;*%0wJAWk-&vzAL>W&L)j=G0FTZsV_J$2}_rhjEV#t6_7Qvt6)tqFLCPZ%Z>|QX-aj+zpj{G=(@~SX!S{zOPh-WAQ;'
    'Y<!x|md@HUf&@dW}=EEbUyMrE^+&a^eaO^WHsn_n7vVC)l<-VGWgSuq2v*)U{ic5pEU%w1Dtt!jg+Huw&ayirKR`J4P-'
    ';>K$qkOzywcBCLEP$7~TnUuv<jsYkJ27*&d(uRFFQZx1*Z8JzlToEy&s(RZrv0!vco*l;sW)mvJ>m|g-'
    '7ieIu~%0j?A6RzYx3m7&J%x%xOtC9m-'
    'y;O`N@h3zOU|Mt?TpBWtLtP<1}e*mKQaKwei8As7>06%Oh04l$%8;swK5ch>uGrtl9GG<N7zKGw!zZ?7_1^<=UCD5dS)BkH!SA_V'
    'lfy_Y~(~Z0XJ`L2CBSP)R&L?LejU=*(_c@5+xnuXF5*gi*Vc@`cg!Zg=0gc9tbmC)XVRXCngm#qooG0=hqem+Spn{_XSW_x)oVxY'
    'lnUZ1l&cFmfFCt_OZ}vxDFMLXm$%%y0j{!24gw=D)t*|2Oa#<{6H7U6`$w^#5<v6CAs<34pve+0-'
    '*i#R{L14ZweI5pj47PUNn@CZju9nA0C?G08Qy{ma%DN8W1K7CfU>Etji3P4dowQ^RM5aign$vjX*0eqfBwS328uy{U0Kbo*i*4!!'
    '{`$g)CrInoyIgBz=K7T1!MEyRz_pMk5XGkDZtk04HL53Dp5wSe?EvmC*^z3yu6lhfKCNI)~RnoV|d+8AAk2ie%o*w?F_*2GHE(|3'
    'QD$UJQ(R>giAeE=wm^`}*{YW;~&a0azytS@uSQm@`;r!x_q`*wbRZ(!rJg}Bi}c_~w<od|i{QD5N72^hd~$IUyWV9Isdz&D%ExVk'
    'w#me)UCnJP5AF%lO%Z|U*ynMe}51#9wK+Y>it>=}{f>Kp8G=yi#f`Z^f<Z2kG|#Pd5HDC-iF1mr(Rbevj&pYOCm=Vk8D=F9LTPpC'
    'ZFm2YH2kYAhQRgf=i+?*CSCX=_qUQzKeafLP-s8~X0Sd6JE*wQ8G#oU_N#2tDALEdjs`j(Wl;B;*-'
    '(7r~Q(z6W4*L&LMvGVod9*c8%6U3<cgFuiN+Eik*GR?!w=L@}_=IreR8#gX2PxA`IWWMkSuy^;GK3aD)W4fy(YY2>NjlYb0#MYih'
    '(=Gon?0cMB2cvG^be~?}&kE|K?Qz*>tMB=mH#?l_a122`GoMbI$F*T>S1q00#R>w`h@)=DIkeQok3*w=9J22XyALQLHDZ;o{Dc<{'
    'KbzI~GFxoR&qpt3JO$kXoyT#pdx9_R0U7>iQQdDG4C@NTbP69@-D$hm8`-B7=l9-'
    '&@P1rv*xNH<)}0GnnLj2c%BsCZ>fG`lDCK^gI@|Mblxrk}dN$EK)t*25wQiK%cC|@zmU4n+O-'
    '#>{5_m_<bWIm~*V9lzA4$ksEAQH!`^~wYumhpp(=Y4c2<`|Z)*YR`A!tR0)|QHF3h+CK^ecaNZX8%DzIF`wwz2oCJ*wjlP$g}s3V'
    '>oGBp35=HGklX>goE9>^cn$oC9^a7N+gI6{0G*e7BISw_Oz%5+j>C)~OIbdX^~-'
    '59l?{jYmuqqf^Y*S{ReJur1n|AFgz$jpUNOytIXUqPD*&W48+^^bSOeZlA!VtF*Blfq7(acU6q-'
    '<v0WA^3ZH&ofyO6#dFWd#;GAK_r#(VMZ0t5AOxM6HN2kbiQU9VhvP``G@9jl<AEVd+_{;qDnEHAGst@usVrN8Q?yMNU-'
    '#!|@pzOD&$dD{#REz=9dmS<gWQ>H^q%3isgCP45ni>4ft8(Y2TB$OK@sxw_K0Ek3|>#XR(`ZrK)%!pdj-V$1}%nD-'
    '97o<bcwIJrI|M!z3Q?Y4s)k`-'
    'Yf3K3u&$xMOlM3Ug#l(qE`?0OH<)n$F_giVZ>Y{@Aie!BXvAGb&P}#B%|rw3A4&~zh+kRj9<cjNT{!Ds*{p+V;_qODGq>~TSM|j3'
    '*5a|erE#V)pCmZRRnaw$DUzLuJo1tSPrE>Ot9dMeHP{He&C5QBgVPn+&W!@BA5E>i`sjP2{|n1TL>htD$+_|3G^|t_`|)qhECCy!'
    'zYQXV_ogZT}>G<df0R|XO4Ni73}xJA9S{sHi(?y{o<2Iketbass3nCn@zNkjWRnCBTUdtPGT+;)bFUl8+UInv?$I>y)$TD1hV6em'
    'uZyWP@Z`r8{s0?Inr0`6**StOqP7^JTLqNqR0aB;!EyiI=~0l<!ziJXUD}^Y3%u{hUdKysko1!Ay%tGgRdQ;1q&RDX)db#O=HmYP'
    '9OjubQ}lw=@#G*VFxBh=fw<jSBh|bh!}zU{OPusUDC>A)0iZiqfx%D;WeM@675}kr&$JtNP={QxcUe`!W}62hV?a@RByIExv;_^('
    '|vK-T>u<*!B4Y65+{XHL2fpM=adk0Q^*-VXNiCm-'
    '}^%TI8qAf87wi{jeB)Z^a(uNInT!H(`MV0SiXG6bT&{oVwfX;NbWG~2p!i6Fm1{*7`ef{)|aQ3voO#kdWuk<QJK4^Z3~Hkd}{$uw'
    'y$Qfcx`hhojRF^3Ng7(srtant)$?#Pd9XHHN3TaV2DOc`xt=Mu~?1wKS*DGs8JIO+1vqo)T9G5770_Fj8}TUVYn=Zw8c4$nwnff@'
    'nvNKNX(HkR;p<pkg;o0MZe_rt+rjxvGTQFwUTRhdEj=!Go6$ddZ(t&=-Lmr;D&p?S+h4W?+FZ8qsPttD1=c-'
    '@%&`h8R)AeTi$N{o!V}`tGvwbn1PRq%|Tbbe73AM>NR>=t>qOJ!i0H9i=1uHe-'
    'E2Te@Jaf?hCgUEzn9g3zwYeD|^#FG)H+HYjlp6hq6Y^*`?sdgxU2pUYn<t$1T4kutASGMta&>M!CvcrRteHdFSoXgKolAw=^3M!D'
    '@FUI&YA-?pXW%qd2QR-'
    '9)YG!1Jl&oIG6mM|ISyKkF~JddavAMfJIw0hgMomP>gZHeU!+9naI!$L=TER5%|Gu5Z6c_dh0C+1mD%zvKU^-'
    'N=_3Qi}#{caM?P)n(=3n?bd@mOxHk%U#;P3m1~X*5|&u-'
    '^Zcc4T}0ax$}csEKD4zEaX;EHStyFxF_*$G4$ZkKGT#9r|#)^$Oo_JhmfPdTM%>axR0r)G_5yWQ#b(!=-'
    'AZB(G9#i*O@ae6uwoJ^F9mF#0Hq_@BA6LYoECV@+p}<$|rq(spPNikpv&)bD4<ejRuDtP>$T=t@5F_oGtr3F^?$Lw~iq=oL`+?b+'
    'FHw3pvfmi?!2YdhIM!e=f;vK)p}!$U(2jFyyXK?Nyu9wyF*1*%x(F_J_y-'
    'eS0*ZNNp8U1@0uyp>tz*wY$;2$31sxu&xO|Zpt*<d$+MLMw-VdfLd&U+c3J!l*`MrHW6K!Yi^~WqZZHTENYc@Fuq4XfIgSPbyfTW'
    'ygu*eg3G;9MdI`9XF!HI=tAJiC`_2@%pD>0WcX9L5LyUBuHm5>JBp{VTDfUw@!3*OqG*N)ZcGo<ncJrq3~eT@5mwc#_kH9X7EoYD'
    '3(R!J#mv1%eh=QsTAc<<!l<5~t%h+^Xn?tsg;^>xTm2}CQ?@Y+=+JEF2C#2wGzXnKb9B%xf!*a$OQQ|ecRXd?s(%drt4=&D?OS%q'
    'zkMM8NnTi6Yaxziq}X)0Rl3is0U6GNGwv~dar&a9p6<hi3z}<C!|8fL%f!lRRQdF#zPHPn&LJOLnHI6p4k=y)XuxZ`{?5brdk@=*'
    'KcKinRd_FYF>0!{^h=!@ioJ$8@v2sJgnH*ft&VD0w@&pbB3ttPyyp<WVW76y@>^YzNu~w8I!zfej@sF_4}MJeUL{w5n)R_2z(80V'
    'd>2kTq~F4AT<+rM@zKHR!!Sw8Vy9Y=cHI54*D>*SOaZ90$#2{Hc5e7Gj~v&QBU_Ybr_rr^?HvF%=Qv{6EgNx1C}La0Hd9Wii2KD_'
    'P-#Q@p}v=3NY&i1@d|}rN_w)|ExOTRIKXhJnCB22e`xf$+t=V#wPMC@?He!vKKyCNuuPXeQia(Ib+i$+;f-'
    'f*<h$kh_>C+=jOv04O^U{#`CRJKV@h1SSi&3BOoi>CrwMW_jlxrp6JumPdxAzaT}OjLdp;-'
    '%x81=03Em5kdchJK9Gj8@=IR|&_Jp1QtgO$wt-Cs?FjPH!EsYA_xMqQKoz6D&qmX6?^e~qf)Dc?we7?KAPtI4!{f1oL%d51Sd-wV'
    'I^kyy9!`k0X<B2<6PRF~hoe1Z}lj0Qwg<GGUPwhf<Mlx#iA<g(#r6Sg?;o|I)jYe?I9q(bImI&kU@QsnMTgEu^R^3T*x3c}SH-'
    '2cVZ2Ioe1ISBSuzV`i&V*>Z{G=u9tA{jQDYO)oBEhRbWA>KmpH<oGy^hp&Gx$3nW6_yPg-fg3c%eHswNLx8-'
    ';h?b$vOb(%I0xdC~s~~v?o3w<FR-'
    '79+>VyO`VwTqcSU{%*QgRKlZ67(Q9G?arr2yGo9;GKpq=$Mei;Qt0m;MD#X6pXgj;z7?*N6c*AeD)uJoMWD-BjqelX_Muib&qH#6'
    'wQ4#-'
    'Pd%@NoNE!%Rr01nv6dg9@;dxUs=k5Crg0L*VE9S<YbDEB(E&fyv&a;`}@sN8=^BV~HOxX34bgJK^e@UDSFN$Dl1@@T@n1Rhh*W&Y'
    '<jr-1soiOhC-WAHL4Rap}!{9jy*4cPL^h(9|sd<UE%V+&e+I?mSCuNUXG+bFJlC900KIFf2lR3|Vg=N07_7Mtf*+L=$(BW`675T='
    'Wby7(?l-'
    'iR_TOE`>IALo?rRIJRw{mV?UO8;O0n0s`(J#j7QJ;=hY}g$KF&3Z1<@`FDe)QO`_kMm8n!6&k9L#apj@|_w|9=bnvZhs$ZQJ+rE6'
    'Pwgg8RE6hz(b<Lq!n~5CwfuP!N$;dfVTAT~$kK*J<KL7-'
    '2*vWG0Z!m^pKdDFF5Pk3GP8@|C<yJgd(cFzrTFiTm#4R>e(MsZINbF%dw8wdkJ?EzP5x&B>c`xERbX&E~RpT@L!k%Ywd+4(Dr3Sg'
    'z-iwa4_nv2Hl7-DLZVxc3XLuSi456T(J2%*<umWN6sh7J!j3(C7<t@y(=K2wC&h>pQANQ1<{e!=5IP-DFne4u$=}-'
    '=82*sh=Zwj!kCp%Rls!pKJFT246M=R~&-'
    'uwRgZ8fHu09>zBrCio<JW(@hBMjq~c;ffa){Y^)Eer@2yR9uhH69&GK<PL|Awed0!LWYks)iUmu#Z?+Dp>~yAc7`|$lk={+_@;S9'
    'P?w^<nQfS-7)x6!i8~(d5cBq-o3W8ZLlV=5g+h>I))czu?WvkeIO0Ob;fd)`oNJ~4o-n(_DyJ`oCh|6brJ!^9-'
    'drvf!d<_~64Qo=po0NLoy@3`aqMH<KBk3$<<sN^Pmt*ECY0Pb{3-'
    '=bcy6BtN;d9=!2d902A3mS6i7!w^=;iE2rE=v#))(E|q(Fhhb6wgLPc<_~HP0e}&DgvBT;|y7F<_^P{(jjIQf7!nuWE~HVcpO6R&'
    'J?}HB2L@GKTn*)`u-$r=PXz{s;qp#gR58ojDv|;W55~+T)c;mznX9v9}3PGt?K*oOVmwA+=0%qhUchz~dTv8K&v_TKFE7Gfta>k-'
    'zviI(-3$1M{|uEjkg9t^vC}PD$}XdLo0=t4|p{n{NkE8D1@#r@Ik&JPm(^Euq0k$Jx@1KTdAdQ|gpk<z|Lfmp3tf8f-'
    'Q^g;2V8Lz`BkSx@Trt45OS>FaI}FLUC~)hn%`#+|sZbk@g}#w=W5KK2dkyhtwz-=bMOOOhHs8*ArElc+bL-czvwVK@}*d>cO>VD5'
    ';n!sPj!q*>6cj@EcKq@BWbVmz<23IP15&bI5F@dJDsD>wVAaL9S;VMNv5C<MV|;-@`sj0fwrDBjhfrLyw-Q<yy(UsT-dK`m(5+k|'
    'F$kEy*u{-n8qAGsWcG}7-'
    'zNH}?~MME@xB513n6DiYBY7xZ^n#Jz4=8emTN_2LrxkgMh8c1;PCA#!F)%juBg(}B0a?Psi3_|w@fo*MEu)WQ#A$}z&!APiqL?y('
    'UcJ_&cB85`@GPRDc{&MDmOaCOEJhU2UewrM@fgcd#S-'
    '0I<upMr$v$^xM%cS{y$!_e5JDwxY)y6ol?eT;hEaSQtg>$4lp7~sh8Qh&C>freKrhY~r(V2pH0rSf;DBfOo;%$kV#w^Z{m7n-'
    'J)Se*FuRq2redy^%|7(E~rK0j`tSZ9FnG{)cfdiEmH))i5h7Wc(8b9t26Pu*UD3HCe&#IB1{0bD%xlq-'
    'P;I%rP$FW2Td3_VQomX!MTArHq(2KY)?RWKhbAspw^qF&yxADGzWYyj!S162k%4<hI&gh_6EJg7)q$ZBoO?)J%+#Y`6bU`YW@IBQ'
    'Ul`C^YD4_aYHX<f(P}Yp(<k(XZlT_K_Ld0;$$aJZU8xs8bZ1327r4d&~&9S$6&!t8$m{N7^uFMu&(SrHeHmf~p=?xs`_a-zFD!Ls'
    'M@nTR_X52P!>}t#HW;dC}Si3og($!_4#`?(&BA5vKR@vnWwsl57UP)tpRZ2_o+I*1nUd7nGUsuIAEUex-C-'
    '&+3LN0o>e3#`<`Q5VWKIw&QPeNH)yp0ZFK!P^Vt_sY(^4xzHTD2utBQkZFWA##ws_zwf8jE)1x2COLgzm9a4E1f2g?p))Xj)tq2J'
    'c1RuFT+(ypcL`HXiLs%Ny2pVRb~eINM)QrC?h;Yvb7y@#uYiTK|L!0-'
    'Tl7b9VW5uU&zA_d_^(rt<~vVGu)a@_L>@mZg+vZyWbo)1swq8Xd?Hk1bCb0ANB+&@k^ka=nX8KFR*(Sr*eQL>R~K?k(l|b*uLD6;'
    '<`mE$QG|l&|Fm{QF(b8o(R4r$$(=Pl&Zyrbk8~Ya5jIi*BXYS-'
    'vLksiM`I9+hNadSm^$Z$v~+s039MEsbLkskf(Hf+Wtj+^Et19Ov{dlr#vut`<0rX4VbZ@HXz%h{IZA`i-1LPVXpvziqllAz-LZ+N'
    '7Yu#{0P?NO5ptd%FSh^|2M&+s!45b`_mO=7bbl<bcAL6wg3rwUa$2M=PF&H-'
    'ZLHRC+A%0h!&J?KroYTqnSYWBu#oysui9Way!Dp<j5Ic`ISdlV_>DINRgz*4;$CwucJS5Kh*vS3l~AM!OG0noWm~dOI}D!gw-'
    'tU12!?NlHd;e&}81i$acD%0HG-dnn^gp9*(@+A)pZIGG$LK9F>J`hy%}_Juz*%=&5d31mnx7cO_Fmb(mbL52e}PPDl^6$KVTPO&I'
    '7R~V~JmC^~L>n8}#RaSEP;)i~VrL$~yc}+$2VHIaU{?Qs0YexiicID!1r_S{-^b;R|3w-eLAI{ilf2+j3*|d8qIn7-'
    '??)Er)sW2%x$!{zZ<VP1Pz_<#^UZ1T#)SSbohiVk+C8r!TOa0|*=cub^@*Y&kym47(cYik3&QPzcEPOzJ&2FFYYjU1FlHfW2#T55'
    '5@f_VB<*4cS$$&yvzJ?)8y}r1U{I~*_HUKo~!&}nUvy`z(Ef3(8E7k8Z1^uK_#dr(vi{)Z+(@j+cB_=+=nbR=D`5wzd`Pk~=weL<'
    'QxtSa3<RzYzi-~E?-'
    'V;rtXbEvPSzYQ@ep=M#`Ll<uJ(x`E&aj5G*XV}S{oGztZ@q47^kQuSu5*31JsRfQIkhsqcFaZZJ<}DkT>0^JYn|$w)UnSMa8W$BQ'
    'sy!TG6W6@nYbCPF69u?Yk%xKfBMSLs+#egJdo>P{T&mQsL-'
    '5`CbJ#I<;Id}nxF>PL&2ilGjLh|P{&s+8IEVwht5X~^ozy;z`WML*8Eo7Q#q}l3bLXO_@{I|3scI$^jyP6K@I76w;&x3JEbM!4d`'
    'N33}UpJwK09Zo88@UHo0xC&*`a-'
    'Tfn@qEmk7zJ^Qlo7)l8DbI$aLk)w80DFE+vze}IV@~eN`7OF2H=OnA!vEF0V5yXR&#5~>yHk@-CI!MbT_$qcPw@vGpTB7*#-'
    'A=l;1LS32n_=)!C$4v85KTUfhRKi$NGuo0u8V({zdTWCbRH(M@CSTy7O1YesQ7}2qT=b^I?zU(#{AHJO163KAKj_KxfW<VBXRr?w'
    '`J3exPWCS`Dhh3s>M_<*rqrhEk;^|u8xPlRZsbQQ{7@Pey0m=u$Wp@6w%e53Wcq4JT$7aTf@B6tZKOvanLI_@k9lVqkHYF_LSD^f'
    '_cq=V<|WFQTf&Va_t!-'
    'uS%uI)QA=uR7a)BTwHFw`!$QZqx5>rz({}i>lU?Mz#C~4cwuHJ+Od$9Tf>S<BP{o9Q)O96Tqa^85`b%rSDO?k4Bwx`$Rh4usK#fn'
    'B}WgAT5+`YCi|)i_MEm>W5KtL`{<RSb)j9PIZf<~d|zod@mdkTjiE{?wMQhp=3VzT64W4vU$q{Bq+|z3wi>~o#EY};$9B%)m$Hc9'
    '{73pOa^=mnqCcU*klD)DJ5mVCgMPY?4FJszcbDa?A&>~-'
    'wG%(3=GHC`GZ<eH?~p~OYkY3sil?b<KAdv%2$ov|<uDsxCrJbb!<S~{H-'
    '$kVSN!ZCt<0sP(Ya~}PG$uID<sX@ax}=VXVY2lG0#7>vNF8UuV%H@IfF;n*(%sBH}+or(*16GO+gf2q|>UmGU?zCN`rM5@81RTIp'
    'QApR)Ua;J|jMXv|dc3vAB>eJ@acLG?#z|#WgZqe66fNq;nX2f&HA)pI}8c)|b^3<%PYuS<xU_U4)HIfruT)xtb|N&I_+jp|W@`>%'
    ';gOzwH}<{S}*;`;6b^2ssR$q*(eDRe35buU%Vj+5;bI*dt@SXqm*lwN=*w;0%Yzu7PLG>U7@QhhEY$k%xVz@t!Cpgpm~ZVyw^&@z'
    'TF=ypl?d5UK=A#JpcVRk@t(FXfz#u(kNK8a~9I;zM{1m<H<NFrYA(QnX_W5=c8?DiXk;a#BgU>Jk<*D&r`u3kUW`z?+2^b31Xzvc'
    'ZaH>pNytTs@tK<(7!PVHjN$TVA)~H``um!k4yn<)^`v`Yp{h!|Aj@m5sl5lJeW*^yv&0zedA3VUzC{c76gy;VV}yo_dc~iglBT{2'
    'u0OF4(A4&n*l1gc2se4tLvm(w$`c)~xpurAo7w`pZOWJE_S<jl3lIl{vI{)j#~F{cyBjWV@{j?Y+}^t)2PG6=Lc~cqb0_oV4$T<G'
    '98WryNPEF<(CAW5unjHSx3qx7CGuJ&z7b)ICh%iNHU*&{)Rno>OfVjf1tJd8FOVKDyI%3pyarJ~|fWwI|#pc&9{90R;m}ELcHB(3'
    'Z)ZR2+O2(||dHSbUx6J#PF~K){g-H0SfOT7%ub6+(-dacUKNHMgsJ&Q0C<d;dNv+bba(A9P1|Vbvq4-'
    'T^=6Ftqn9?~u3Aaf)^L5sEO=ZQdUNmH$wf^8*lX#K5u$q)#!fGu#**B<K#`o#mXz)brxkj=h`e5cQeP=>=MW|Bx(wNF`&lJ%EEkW'
    'k0Ex7Meb;akXV8@dY6saFC2a)4Z#VFgt1L*IHmKv8NFUYR8VpWux>MwHlpWCAf3<M(M?|-S&qNGG(vhbEVROo72Kb-lI5bl7_TB3'
    'xH7UG?xPLu4cZ*cinz-'
    '7dOo393{Hmm3$h0+sRYsDTxI0YE1}gi`_WCGA(<t?=Bt)7Ai@RUOzy&ntUw0=}*&AR_CP@J7AiiVA4#32j<=3PNeFXv9<6vf9?)8'
    '5%~?dR-brBS-'
    '67JfFkTmP`&msPuE}ZJeT{a%c};*_t{(vU*0#;tN9F$3e_ni!C5j$&hFs@yN@=vhhDu~6^7;xo6KjZ+3N>vv=s{XKAafT&sqJ3lE'
    '@2ly^LSClWOP=TIGN&<ySc>7g-'
    '$#miJK2@2?L#D6(^3E=$V1E!kkO5%$P(wXniGJrMHwT5I}>b6{V1=*x*@*q8lnluQYBicqWd9OmcSpb73D5*^Uh{o5)jy1hfb+aB'
    'UGP5ANbYWY1<pC0fiq65Et`G7YKF$_exP8rSVH1ptQGXY0a1|~HkvIhIXHSa!Z)EiEnTux&c;|j1)I5?PscE!<XLzbqK73UQC6Z$'
    'F)4v=Wmr@0Yqw3Sb_+ge@e%HI&lBn?f8ut`g&>MgyFChes*tosGeq+eEVMMC4!zQ3TzAF&_yO#|E{HcA$C-'
    'Vz?A`D+a!m}xw^bF+4uG(<J4jLr>rZ)wEwpvO2Wp(&FFrH`u(IM&ZO+P}Cf7|qyv&;~m4Jh+BUXWKdqn%Y4Wir~Tw#eQ#HporpaP'
    'oCJ7W>1*iXnaI_x5p;G%~>4XKklSA-XsEG*jlo@$m_@ZuzDiKA1TvQv$HF0a2#$x+`2!`0$yPsLqAx}hf#W-'
    '4710y1Ae*Bm+^hqgc)}QB13^xETFeoV#2Be6`p-'
    'WcVgFWgHv$U>U9!0KY)zd898&?z3lCbb74nCr@(!t{^)+JH*4xK%m&2Q1EFu#P%+yx{H1WCaUM&S-'
    '_89;9a|R9M*gx=k_M3~%OX>{AESB;*tHhh#i4PVhyj-jA?JkVmQAEC`BR|0G;8fSdLuW9N1a=kqs8$#W}WvO_$=p_&ft7)mRv!tu'
    'iq;(`WcKwrZ8Y>X5q)S4U_HrsWeXx>(yaCM2j|(v<oM@RGg;s4)9>9RL|MOdouaTn%K#CFBC4lEIAe``O^Uzs%l!=*Sd9uszJ4)s'
    '8AOJJ9(&=+5Tj6+12IJJ-uyKo>{r{g!!})^Fimd-'
    '_$vBHE0$<>OGH@dd1=MSG4A8ctt)a$5GGbV=U~4vuwI3k6%xyH5z2tRqQ^_DLLfYW+z{T^TN~t?mHx#k(Xe+<l96lbILI9Ci>fAO'
    '=_ALpeG5~zAb+4LXF*4z<Uml%#iVb9DkeuqO?PHPlF=ygLRZE8zyJDZy;9aXlSYJ3OqA^TR-xG>J2K4lZ3^*xv_E)_B|2b?R1~PR'
    'IX`Hx&L%0?0NGF+lpbG*^BUKm^slR&ATer8Vy;0VoMWaF8UJiXuKnF1yA%AVF&I<X|bL@<`(g|^P7Cb?wPHHT$dIr3D%!n_G#*kY'
    'H2|8?nEP$Yp-'
    '2SDLx2Vb{DWN&sx7uvYzeay3dzl(BQ=kJdJAV)_n%`3nRD3{Lifp<=W>0?==K|4sU*JpUIxr!uc!OU^h3F#opGZ(WUpCrsZy>!)T'
    ';6)JC3v%}l~QhD`}G;iZGI2Z`PikMr6*7H&PS#S@r+R#k0l4V696wc1H94Ex7CS!#pw<H*k$dg<oe_!G~n+bxo8hq>!QYHZN%?7r'
    '#9F4A}8CY333!W3Ft_P#^!TPNu()i$?(^7+|*j~}RJgcM?MYd6UGD+NdKPZXq9Gk1<h?XQy3Ep)8Lb&Ac`7gMWN?wX5L<LvznaE5'
    '>y-7Tb)u6%h3<%dSST`f4ngccqH3g=u%dLs)|%VoDU-`i5{E&-u8@v-'
    '*nubbfKZsmnoDqayO`#8DX&|j`PXw2y~u6ZDl%Vx=)UXFRb@0Q54pio}FEz`9oNKj>NKNNEv9qWo{y-'
    'I$SXLPj@ptIB4W|Sv%_2r&B#9~wCdag9?B-RZLBD+>Q;m<U1xQmi5-'
    'ZK!6RL94mmz!29l|nE&=aXn!+RO8XD_^5>Q4*F@`t0#7rWU08g$aHzy#m5VesQ^lN9O(9+HIn#yV?L-'
    'ZzfB<G~Q%enzuFK1{|(377-h}o7zmp9PV5^o~oOhD^cY$MBu{{!dT%d#-'
    'hb{Kj>Jg_sVgVskKc5s!2WaQm;OU9V(2X!8KWqOroQ9T3@ODfmDGG&!~GH)A?1l?*)s&EbAxipu1y%twL)LeTI(}1f4)5Kx?iZn-'
    ';7FhLYXe@?&>?_SHwK$0pro@Z*dCETcg4Akk%8C9DE6#yxA)g)dZ2TJ~)9GiEorJ~XPuom+AALJc6bIE(jrwO}6TP)07!k)l@uiF'
    'fu?yjVSsEE$4ieNWNyK!{uEtv#9;+;Z|`CF8k3ZEcQ|k<thrUFsk2@6X~XmxNH9sx_(m%C`z4#8im+K0(VoYyu2dkuv?BI^AU}In'
    'gk6SC|9e$jusLO-'
    '<Wi<G8x*kcnT0%54E*BQPB;iH`Kh1z;~X!2$#?`k%AjgCQ(v{LirpHPw3lt3sjXPX^+{*m~;tbA>t`73Ek>kDXqnyoGl3_L9yK2s'
    's~u=4IbMo_8mSEL@k_pbSpOIEwO57w5oWV)}SMKFubm$Fho(kJEK~(`Pc#{hN_<75txdq3MJyk4r|B==Nse8`*G|Eb_{|?}B%0@{'
    '=?}DYc4**?9F+K$P6F%S-'
    'RI{=$zs7$=^{UHEWkK+cs+<%YkUnEi1l2Q(r3;d)Q8AJ18iotK*PlyLG}4qqNl>s#}6@(Bp3T}NHOxE|ID9KhJ-'
    'Ff<lTdDIm4Y-iQl)v9WApj@OFtcv-S4_XZHxb3q(jun-THXv^uPR{Pb0_#hk&a(cYmd;|gBQ=cZ&QvhzSSGBQ@X;>JFRk9@wLTrn'
    'fUNE~HjDS^dLIuPXB*G8x%>hbo&^R5{YY4si$6ICo+&^5uT1Z=jg&SJVXx&pJT8TXP<Ei=cyyR^=N6k?o2%|me<GyVP>wW<y?bB9'
    'l)1@-nVGQ-'
    'x417tZf8@aD_!0z*sFWjP}g>rT3xT+x|c5|Gefv&9U_6%nbqoHDZEY}`$Ys?K!lZL|K4kijM1|@t7bucI}N`F|E*UUGWkX|e=}AX'
    'yBe7Gm+P>0=>r{%Mu`~Z*n3&2J&gIgi$>@hI)zDt%2&PI;i8vV3)H|>-)mqr?6UPjI0qWd+x;<A+-'
    'b9TpA(aX)vFj>7bGFxVZv_(8QpUE*4sdU%%)a9o`4)WR{FqBtofw8WDTCrh|b2jp9S2aW_#l*_gg3I8vi^o|7FwQaW<!rxL)8I8Q'
    'lD-'
    '%xtdBR@C5P{#2PWSFVr0M^y&<v|mbYSxxNjGI<$F##x(!7Y$7<l$OT*A3FNk^yMS7naY|Yo}ZijD?h%yk<xy!yy{4`Nvy&t(LYT$'
    'VpYRj;l$+N-mAFhN#I&2m&T*w=S;LxS9`H$jl0pZE8(joukU5*5Q2pgF?RADt-'
    'A!{2likf3z&@7g$j2O`HOP&s&NG{@N;vq)klqCYWQ@z&YuROZm<_xG_=XTCLDGlh0fO<GO3deT<8FQhrTS_7M*eXtPExBcnF4ER|'
    '3*BP*KjOigCRvj31%(YzvZJ#j80E323KT3|kaE18C88B`LupAX}_`Z3<nbjhKdONACxff{#wlNGv_j_D9XVmEh@YOR+Qbv2eVVP^'
    'w5FlRrdfW$^xK?k#=gLP~x85H8!4d3*E2EL7lGES4;ACF`20=@<kwuxhP1tOl2Bm}h`PVWD*zh3clHc?3QDRK+i5C_N#p+FBOyjJ'
    'TJ|r!;ao=J7Pk*3jL*EzaX)z2^2gNC%6NAb8#g=ndP$qY-zm;n-'
    'MqhA)FJjY)ah1NuL$!B6Xp7odk&tl{k(Y}PuEM)rb$u2s?+ukrVs_!D_R+<Y62>#j9YW%5v{QYp<RoP<6&KELgdlbl^<f6$+)AKn'
    '_kP<fs&>b;W{wi=0ob$PL$v<sX6jlJ?8$G~&`NKowm1bS#{v1;!Qo*M<8ZR^1wrsI1-'
    '^oQ^}i}2i|Y5bvvf3j5mnfkk+FZ1Pd?>;td?JwfXE>Z1R-~G=2Rmv}V%U>6$cBBWc8kvdyzm*iKM}4OrezB{+H~(AO-'
    '?#mPZ1c}{{4?vHP53MCH_t{GEvCa|pWYF3c0472bMycC$R!B6|L40_H`?i$8AhgS>_XkP!~guhe~3Y>|Lc$6xt_aobv5{}$&Tmh*'
    'PW&x&4U@eGtpY5@_#Dd>@fCy`?`DEb$WR6Z0&tT_0McS&~?XuSL&*7xUBtM>?h;o1?J6jf8FqJsg9bNPVDUV?^Wsa&V!M6=C5|`!'
    'ox}bMXc67b*8#$oPIS4{<A_=Q~h6GX7`V)|GsLh+Tp*~|KA?0^6SB#zZDevv^WyjzBpa|A~F5Xec&&)(mxqb|N1-'
    'azkHp4{m1X3xj8*0*8eQ^uh05#1^%gwpc=mj{C_9@TciF;wN+=YsegF;@b~NeGxa@w%<$dWc44IZI9#j$s`@X%fImwty|4e*ABR7'
    '?M;xfX`X&BLEa5lfD+;cEbKrk-+W)QL|HIwjZx;SR_oF{XfBwBw|9c_-'
    'Wib3I=_~qRsfO|XTw%O-%<#|Fzgrqyeb4;=Hu!h(|J$>H|MC9-mDq~9'
)
)).decode("utf-8")
_V51_BASE = types.ModuleType("_v51_frozen_v50")
_V51_BASE.__file__ = "<bundled-v50>"
_V51_BASE.__package__ = ""
sys.modules[_V51_BASE.__name__] = _V51_BASE
exec(compile(_V51_BASE_SOURCE, _V51_BASE.__file__, "exec"), _V51_BASE.__dict__)


_V51_ROUTE = json.loads(zlib.decompress(base64.b85decode(
(
    'c-qxn%Whm*a{L#qxlp|*(mS<OGcAm|Dd;i8xIr`;@E8V+@uKaWG5>B!B&%-'
    'SjEsoPbBk=RL{P<B=jM53Mn*>d^1m<s{kPx$@%P_f{L3#dKD_?)>BZf}i~soTzy9sNzy9LukN^1X_y7F+|9t!TpBK}Q{(STC^N-'
    'nQe|ho4m%sh`;p5HQFK<4-xOj2<<No#6e|L8m_y6;0zkhrD^{d&hf7-'
    'vl`T51gYW?l^Kfe38f8qY{?IEv!e)rSs_g^3L=H~Xr#X9`@(~tZ8hj0Hed!gI?r_a;(`D%@KZ~pS-!{d`y-'
    '=6gFq2udMel`C%F<$(x<MR%Wc^K&G^y`j4{qW`8`?tS-'
    'owCngzP&#Ax)1MP|NQx2*pu&_J!Ja*53@7-emK0ZU+`v+-~5*spZ4$H&mIR?$12Ro>(Bd-vne_KB0MAT4c@$-'
    '8!3)V&eHuuE}+?FHlB>^{)e7X!ZIaud0dGPR+>)HqcP*s?G0?ZHm2+NRR_x*1{qB_GMq4Z^P>#S(4W4YH>Z0TSZ?-'
    'rXB%HWLnlMM|I|{eDUO1iaI;B#!kL<E?uY-of7*QVvWY4fA8ceaF>xAv)1n84pGuFeSuB2f_L(!7F8nlVy8Y`<^ZEb&XDz!OZF6{'
    'RZnnv9>fczkR_CSee*=wm_`i|o9)CzIvefhEW>{?8$q($YGpAycy1vp;ojv*CXonNHpHG`U93Bqo#U6L_{{8;V=U@M{|M>ac`*;5'
    'uJhIuNrcW<<sNe71$+vvFLeTdB*X#8C;I%Y+aB??o?o^Z$+&cdKda9AHYR%L9#tnCSTnNZlw#Tj(!rVgv`?wSlv4zz!G&xiB@W`e'
    'D!;^=Jy{Q@p)x%Mbp4PYpKHYqoZ-Ajw6zubL|LJghuhZ>)dFQXX(${CM?K$U}EXie8%|g?>T6mhBIAY`#{>V?8T^d^o!<~X{I}1x'
    '|xF`hfXm}`<aLC?e-'
    'qYp9T3FpEnkE4}UEjbL0hdt4aB*5eoK*?j$jlz@9tJ<PC$=?O%jfWywdHe6ej3;&Xn1;Z8rFP#`j4+a{#A{axeCW%J%qm+a<B}07'
    '~$wbeS8fR-7a|+wU#WorVn#<u(dO3=q%f)liry_c&2S|k|ti|^UTX)j=Xn>&em=7d0>DKi_4f0_U0*2@@yVRj)u(d(u=-'
    'Rl6fcb9M7DR!Sg&mq;pS@xP0un;^-kh0{H6Mnzs<`QJ*CEPzXw|8J-'
    'S%dZmn?{KtC*!n`r9(YOqf>o6YN&eg!MuXMO9^H7_0U?gI~VLu95P9N8e`<^)%`fV&gh8S-'
    '#tf!O<^SuoEG9JF`dKq<e1_d##msb}%TIpR}!~u#XYtr@snCo-'
    '=A#!NW36n<Te3{p1JlD*h&FCzB7i?DmfwnU@?CTQwc=P#T=Qw_tv+f-KX<4tSz_?jY-lB`%4h>*s41nFhmWOyU$)7%de0}@F{^Q5'
    'L)h5gI<6O!~oJi=7R{Xjl$Jc)qgCI8gDxM#7I|6h}{hR5}hm*(g4duyflP5}UBJfZwKe1%-'
    '!zGU{VF?JZAmjMJ`F%TJY6Pv>mk0=*31>vUJTaz+*35U_$p!QBu4QX7e4RsY1a<uV<TVt=z{0#mGJRQExSQ$QopNT83EjM3a(%56'
    'A7ra@f(H)ccz)TrSN&8SBdVNwZ=1w>;{&UCcG+UI2r<iIY)|MTR^deoq}?_WCYGx*>`4qeT*1!Ab5H?k<9R9q{!N^T$>Q&$n#fP;'
    'C2rVsBtr)9V~-'
    'a?l5exGEYMDEw?tuV*|D$P?|73XcMZedW)^6We89pvTr$A)1sjvZCvZ|{*LahFk+1GW5gX)W+dOUtREpDK<k7&?6`pn>(;9tn_6i'
    '&Xjg>nU|D_JW$vxQN(bc(b&qx)YI}H9@o%(s}#Lrui3EUL&rU?0@bY$t#9M5%_G>V92&r1STQLT|3{ybZ=>Z#xcdOZ0{^*j$p!|l'
    'z@`}?|AeWxA9P8n>62d3!U0wKdm`R&(h^=(><>xZI|&Ei$#rXP1vhP7X~2KEoVmg(L?eslZ_BRDlSIZjAH3cnkWkW!Cg4TkduwYp'
    'Mcyu60FG$48Xg`AHJUJgs>eu6rv`y751F(*LJkRKnd7|X16mGJR-'
    'U;!Q{I66hM9}K%}iC3gyx1<gh7b7O|1^#utmLE*y#As>}X2sWu18v*aDGCQiWBh@-'
    'z`nH@zKt#o9f_x;&@nURUejSu0NbEFnWtW+Z`IwQF|suf{w5pyxZm({K0>+1v?VoAT{|Gai<a9iQ9BGGQH8G4Nf`=|a5#$qb~q1J'
    ')P1Xv^;J3II`Lb91H8>XG`&pPtW}aLWA5zKc@$DDIl_HG^K6B~363CMhIKB1LogwVJ=h>=4T_eJF<tS8|GhF9XpBG*&;7%1=CR*J'
    '{JYXYdyIo)^m_OeaKz@Hs`<>vCnskZKGn0!fQ9fEBG#|n0?AiFcIrOAC8yUHh{qNw5Ie!UanJ_?PyOL+(rDQ21gu2$DGWz>+l8=<'
    '@!!3HJGD9a-'
    'k}cOU_}tB+#$tYB{i?YaG1UktrRl=<BOq@iDd+o9)Q&bO02z#fSQdu<Zc*GPzL)l`T^MNDTQY_Cl>g`hS~iX!ujq}0Chg)o*1*-'
    '?gN;)u(9bI)6iyc2*|?*!PRLfv$)BP;Oy*5O1%`9Q2$gxlNE5mAaEq&f;k|Vlme_R9-'
    'dJo(i|Q*Dx=2_29fIHTqFz@N#lHU0DgM+{x9EDQ?S<_+!i_{=4Rf1&rWbOC!eweU2S?u^6Of?B>qon>NrUED~=m_rpUVPlz66sSO'
    'a)@l-'
    'HzK8D$JL#=ebCp)u&gvIe;bOatR;t2wSdXnyc=_FVZvEkFcRk}76L(s+0%W3##(vH{z9I$C7uiTdO(IgtPyg2lk`7(NlbWl@_Z(p'
    'O$#ueYG2E3yQISv9=uD~R31Bvu4$WHG^(c!%SLR`(-|o>0w8E5;vsmv|M?O-'
    'k!<YZFk&T1?i*@q6)|143i)D{kKIF{ubiGMY!R2*lhoVU`kQ7KC%WW{k)sR@SQ^UAZ4NWbQl~n^@_ojOFq#%e2AAK3q5>NM#TuZ3'
    '9r`xbpu{mK!q$UP@70s)Q)iOmkK7epeMcZlBDKJOQ(nl?Y6mVJw|qFxRWff%UA*HYrCO1i~8j-'
    'BnDsU1sfWpVjiY$z*+LsT_218~q^+%4-'
    'G^#k68=K%LOd0ZWIzO?cd~3P5pINS`NQ{j0O>s&#F}lxZtlZ6`vM&ulM)tD%>yx^(S!F@WU|Ve)8|qmxGJ2nrS}j2Pw}0I(JZ4O~'
    ')Vs5-'
    'A;)|5C53X1;Au|d<&M<VV3VbphYUM>sJwn4?ZU{yhl`k*TjwZO@<KBY^Eu7+A?EV%4=nWv%ZUAUW>ViCm@Vrm01$uX$uW(VB2y1M'
    'K3^GIeO(-'
    'G2A&svFcAfrRzWG1`_e}h_8D8hG95qV2C)cHKsE`AMiVzg4{4AA?<vJE9;O;5aPC9D>g0TA2tUve{obgNNA7&hfsf^KVdJxbi&wK'
    '6%BTAPdE!#xk%IC@ta$t$F%g<G{_mCTsDc#z!<MH#@5DA#M0%^2rbSPyawXMaIo-1l^8g2z-'
    'aC?;4O8#HH^B`Scv24&||Uqrgf48C;KMuyHDx5CBaoNtr2P(@~H|MZm1EXm|<A=n~jHF|^(Ra7-'
    'FtD1gUs_Io#6uYnruda*}vosym$BoI)LKMrln<<|g48}XnH%v3Kzy)cKG2%>;VZX=aISjy@Hi|>Ix)OlqIGti2)Y%PeqJlxN0uBW'
    '$3J3@K^J(mDiNZX^GN~C2_-z@w03wp?qgX#LVyguK=$E5MDtJ@CQ-'
    'f1V#1hck(M45{DZGIb;F_|(z?)QXq1{mGt@>&L2S<dr8SHmYdcTi@FTo^Z`uqLoUybE$!<WM_0t^ue9z=4(^e@ow(k$SqbO3`-'
    '9v-*eE}Cz}!=+>&@Of}^gZPUhGwh{T>xEyMR%J|HEaC_BRRN-JyxnC<`3Xd^D%huEhOFaLLzD&|1GecYK)RU6;PL*$Z*Fcrq#IC5'
    'q`0un?o1^Ij2cDf1z{8^SdTZOT}c=x^?cNl(sBVAl;9xL3Js%QQQ!za{SsktC9PFB9u9GTFUdLQ^A{l^DcnQ2y7kR&6X))W?C$Rw'
    '@Xd~}5u}Ey%a85FhblxL5Q8H?Ws*+Sx7V~IuxHkHB`u}w+i7tp+0}(bUa_nREbc#LHRZ8<^sFkq?j+YLL(9Fnq&5}u?@r>eEv}|s'
    'tr|SQ^=b%0HTi21)$<XYG1b|&tW|{PX!eA^SVq|zkVf6qm}NByO5n4rPdcwSuGtS51_&Rdg?}!Ru<3AIr5BEz7gbZ&?qd;(>XUSJ'
    'VQC~0KmVxNqc<z>*B%#>6hmK5$t$2hknyyNN@s#VA{P)?(%@AWAe2=C@Y)(8-'
    'Qzuhw_d9n#unyffaLp<zj*uZ&rMzlA#5P`6TAWV&y17SP=s~)Vcs{v!`l8}M@QkRLZW~-'
    'PvMgCd(d=xAE5O>sx8v?Fa%VnsUe0tMUW~*-yz#M8PgV~H-'
    '%FCV4CFmNNOocrneH(p;q@zr|&q?2Uuj{k&od?kryPt`A;AVWk}f6E+5wSh~GHq!uLB{UJkG@4QX-8?DnzPNYk`-'
    '6bys7CrXeBgQiwOD_F(pP&H~_pDh9jS7&El6;!0RNlOKzau8r=I^bUURMkr>1m_9-'
    '+l;Q^zJ(v7Qoao<K`V8GMk1dlB}?0)%$g1X_K9jEsa;Bw;fFC2NNeL3PpLL439mtnG#)Bp4SkP3CjZhfhncOQH!??>*u`-'
    '8@N{#y2J*!_#yxc_eRhhnTr)^xwQkF80Ai1)rDvUihq0^CF;RNvE9EjXgX@i#AL$(OqDu=B(fpdB!`K3RFf7u-GUh1U-'
    'HQmZ=JxEh{+dt=WS!Itx#Pq7;Tc(`T{cT?Eq+{9Amn8>Rp-'
    'E@T5dy=<*($EO~%fH!3zbwp%dq#9JGX9nj_;O&dBvPw&5tB2OS5g2sc$=STzYGSZrTZ`z&OnW#otalASD}yjH@5n?mq-'
    '&63bh6HAVyps6M#tLgFDE<4k)Qp)G6bROyVZOf07dWwhZ3?Num0zHD%e#@0cfz;`tajnH2ie9FWa;@lmC`kq%CYJF8_?tYsZ9<&9'
    'ZiR{~=Bmmi?N7EIbB;1*wto+nHsvWL%gahEPzq!Pm^}O90`ty9RU1G)&k?wVWGJYX)?>{X(4#5(!s@l9S>h^($O>3gF#K_p%xml0'
    'b~_a%lsKx~2iBmL+6?pzW1%yPKbm<qnkixlDvLQ!>oV@~tBUA+nYQI<0W|vxmJ(3(&`R^_i==tIg>L1HDyHMwYxGc~qT~C7dNA75'
    'nv(vQbxaka7DdEQY!VgJLVqn(aW2>jTE?6mV70NZlZKXVX`>9cY&OM47RkSYz4iPV*x<@?&BYirM|7kYb#DY4dg5yvvKiB;@cu8?'
    'y&!zOw4O#^XCv=MoFu&of3+m9F)`r6=*CkRc38awChnsFK@3O!iqzbXuh%Eiiy4)`K*Z&JS!ge}KXYRXdpw>c&umN~jbU4i$`iPZ'
    'YqEr2?K+F}3`dEj#}cCg6i`x{buQQA75H@4rfw*F!f3g#CIfiw;i&{4h?No6drrUE!Iyau!l76<nt~}q{x<c6S&|hoBz1)tQl!_I'
    'X<YX`w|7mc?l`p5<;JPpnFQOC2RqM$ofbl0;n(d8;Z`MakK-71p$-mYr4eE*L+P}I17{GSEHCWS6`-'
    'FS8n&4SPw_^%;BeS&7L7px`sQ4%9a+s#sa`JCBYUZYt48K`RMrC51??-'
    'T5ehO4e|1)Bj4~W(IP)?&45uqD8nLJ%UBPq!xtijI*u^RI7v$%Qt_yMrXG<B#&()cbypMs!d*zmhau9e_f2d|1Plvemse&fN<^NN'
    'HO%4Kv|6%gE>HpbE5Ovnewii@ZdgY#;g&ZG+uqed)c-T4Ph6~PI%{1Eqe$g@(rCua}-9-'
    'IaIa=Q?i?VGO0yfwk9dR;1dtrR}bD68KB4FYEX&iY1Vkq{C&v*W#uA8pXFxW|cxe0A=Zz$(xJu$trr{a9Y*qmZ|k>Pa@UF~?6k$M'
    'mW=P7ZSfdfg4U-'
    'I66x|NrK0~A6J7#uhHQCnG)`xjW>6}X6r(5V*)gOgQsymD#|M4p6m$?|j)3%mTX1Jv?vx@1{vIVw_PoGe}XgLNaIou%#$7ScAW(`'
    'kSX3~0u;6<ew)ra*^m5Voh4JGGs{PNoE0#zm%JJ(?=3{?1{zKO!y>@|RqgR(VTptYA6%s%B_BXtWj#{Md0)kD2lcK|ePnK6Fye%a'
    'O-ngVHul?6ijrUd`Zq1sF0(+GDB{dF2}!ypa_8aO8@a7cd*Dd_z);#RzGvf0e;H><OEmK{LckGA)Q%ouAL9WM4cUS`J^C<zo@#>9'
    '>G7$=7{9|2Ag;X6kv+jcsG6AGz$;O&00GK-G2}mSEOkdI|A9%GFx@to@?E=(<RmBTOx7fRg&M*XH>d)`rWFXcSV>6!m!wQn%N-'
    'NM7RsOcrkfPbsIANK0J1B;A2(2~IqZyMHt|;>A%crLA0k1N`v=C8?a{ha#tI#p(_3${@~}ZFd!kPOnl7VoBhRoIRs5%7U$FjWAU%'
    'A=j9eO$q%c&^E)Tha(PJUenClG8Mx?1%RDN(oXy#-'
    'n%6YD!Oh5b#1{B9fiZkRA)tt56bWbXJJnDEe8AhJj9<kg~@59{GqIJyhsko+ZFR-'
    '^M>BN#wNB`1+hB{oX~?SmM#K>u+=eV3ParUo}I!&wIDS~NMa(Zb*G0k8egY)Ab;Rss~3E0xu(wNX0!thxf!WuH<BJ&jrQptn)t;^'
    'CJQFD7*J2FPs>8LYS-%u^mJ|p)N-g%y9la4W~mlHwn%3_$r-'
    'e`+a$kwb~~?^uz$qpL_H0a*cr3?8E91|l))?%{jyGt1XE+?`LgG;3Qfl=_6KDG><4m>OO=)kZYmcJgpB%P<sk`kMk}XQ6`Bp@Ub%'
    '&a8S>}#ky^Z36drf*{oH~?ufDN9lhxN{&|!%t*+cCxltGlR7RgayLJIZuR0vOIxJeI+8;X1fBi*<Hs2#cx<<-'
    '!Fe^S4LBBVx9j!`6E2xe(N776Ec)M5mRoNYe8Df(DZR$L5FIRoYf87PkCgxq(%>LbRz+UI?<;PO>@haLyZ_I^;?W@}HO>EGLD78^'
    '6O9AI8~h+e5y`lTiVu@?Z&S7$TrJrz_f#p5?y35+P{ak08Op8T;?=1hLps?I=@z0-3w_5pA!hP^z`a*-Ion8p&-'
    '%i^W!F4#>4yyABb64jP2rF>3Wn$bUcBluGlLAHg##7U9NtQg}W<e&#-'
    '(L4s42@eu$TD26ivhsRWut0@W7Dr{lYD6o`d8?=c7vG5sWUcRdrSoCjoM3iqd->$G%P@efHnjVhSW;aT$CoDdl_o-'
    'ko<-EJU3_NK@21D|z8H;$s#mxBMoo{?at}ng%DfHmw5juJtY)lt!(kMTNDeOJp&CBYe_Se6^#VJ8EhqXU99?q--W~B}gL*||8<FR'
    'JDKIOA4U*8j(Kx`7OicT8D?Jy6XGl7G8Zcb;h=$^<L~x+wo)v_=1yhTlnE+Ym><**DLid&gN4W1@Af>dZQtmHiZc)EtnGV&LF~1#'
    'YW#CFpFl;g@QcY2fCOHl`+5B>=i?6r3>(Esyo1A55YTi_^%QEzRVSoU5*cmXXh0*K`wIf9C+cvNnOMKsH3y3LxySt9um4(^V(3^V'
    'x$Oa~QKOp2MgOO(N1Xl_+;h0^WICeg$=JXF9wV;Y1&f(7r`k^K|!}=WiSPo;wr0={%Z|G3Gwy9ya6$^2CRc^_x-Cb|cO6ji_G62D'
    '+sB90f|FCp$TCbLGr_iYD=%|zkQqg%xpbJW}88C*sC<-'
    'fpxmsYPzGhVcJTVi=lJ#|FQz25F1%Jih8hfW!qr9apQeqCW1uiif1nZDck-LnGyjcl4t~BwB{~b?#$EU0>Qa{N>l%E!B73gV6dC3'
    '@2w46$rU-+H5Z&}r4m-'
    'bffq>v%w+#^v7wZ+V_<%(&|6s4f^wh%3vj;jGzW0=uC0vV!OU*;z5FrFs~{*q;pd^mo|9UIp@Bj&K;)RZ2D7TiM9P{2;2a1|qwd+'
    'emKCZ)87G;w6Px_;yzDTwF#t}tNQw7lW0=OXT2-'
    '_TO;EQmd<6HkEFrDiOzS~CNHo9#?BMojw0y7}Qtw$k#Xc5<?N0LXSdz*MuaO>}Ru`f=x#DEG{&XFWFRIH9_i$X(B(lYdrnm)EN?m'
    'l87-'
    '#2f(ZIm<+A(Ev@~Ih`wYso1mC4_0UkO7)p>QW#cRHpcF0jG+Yj>`Ea&%UP`M8DBP~!U*a^G9H1W`c*))u9n!}S^NlqS>|FXB2hg+'
    '*ezT9UTw=5eDZ?i5)%XC4g)pgxlYG+pWs6KkG+co7YLxD*F#MhY~npGe$%e|_366iQAu-'
    '~l&D6<<}w@Y;Z!lMS^^2vI&9Wzp}@d=*v#@AV8T>XLxz!j91TIZb<l3~l>$9FS4tfmYF;29c&?=;j}hja0o8G{Lh3R-'
    'O698O*o&yL=5=>1))HUtOzwb)+bIr^xb=z)UboW(3!Dj=*ZKf<pci?hsE!RRJwclTiVPa=Hsh6$!WwPT69Z=_;;!`1lDOTdc~nyo'
    'f%+6G7)u+F6$?gos>oh3ZTiuhh7QzLnj^4VM;QP5uBQgL#a{@QrXHXvw1$a-'
    '+aU~avD(gZ>)Ah|E}W_TmUFi@it`pxLL2N$$!+&b`I0smNJ)R&zLFRzugnOToD0UtFn)??OvZ`P*8u)O>+6vxVZTO6%1yeqw3RU&'
    'yLzI3Gsto&p#ohXeepWM`8BAMx-Uz$I&4+=J~~sWSfVB{I9VCU$C{&Y{fVBsy^1`AxEPD=6<5LG=`SY&#~MCTAbEh4kAkv<ab{Sb'
    'OhYQP(Y9q=vGBkk<TAManQ}_A3tVa8@?fl7{aSbhZf>dxjeZjKQ62sPGqU<(xV$ZqwX{^KTOb9nNLF^s;KGFt0ip0(kT<pO>9liS'
    'u^Z^Vv&poUp(xSjciPOqzN|35y>8T^)`${gSPRAn@BhkcK21F}<VdD=Csmk(?gQ2Vh_U<1kk-'
    '2;MC=*^Y5LV`t2yJfgda9lxDivt3~am)OKd`by15(blE^T53ujwE%ie=RxJ$g4(0({uo*z+(o6=`R8IS>2(_+26X&c%Ll<=LyF0m'
    'QN{1ZRz-'
    '{1U90F{^VvzbJMqp%by7&FaEM<YMx>n0e=t<i+&bkyMmfvA*I73Gm7s9F~752i)GUcr}f?#f~_Dyx+>bqYL^5SWmYC0(LJidfL^e'
    'puFmb>GJ;qOq_8PRmn%q?sgM8GJL)(~3ktl#Q3aQ#EXq9j&Ntv=<B)#wdz;{F;@H{K{e)UcB7ymTbMZ@BXaUvB{9UHr8akg<RBtX'
    '_mwxe}Av?+N@n8UXQe1OH8mX`<*zkew*1bYZOb4I1%u<UG(ZW)W?O(y=YdAb??r-G7x({<8kgekVL|-'
    'QCl;z7=`I*{N&@Zw~HM2IN}6pnJB5F=lil!5LUxy+2v$Js<qP~x+1);mEAf_N!sq$IuCfzvP2CA2nNCI81_GN{$@ynjM^*8fY6Og'
    '3)7r-ffgU-^vUv#Fn)#9sVaa-tE$UEaR%EBo~g_XMd{m2V(Q5t6H+84=q6d6Rh44$5UFq6STQo`Anb#y>i15A0%DU6YnAAMQ~EeF'
    '^|CZoMm{<G-{YAnG#B^vHXtDQRPoT`U~K6Rp{X%HdM6Af`)atX6c)Ixz1=4C<o$Y!l@?q2OcR=ST4Kp2EFMSmqApBQOCl;{N-'
    'Saq6EVkUexj9F$?giZIwBaN2Foo@9#Hc-'
    '24B;^wJu4EHKp?cgg;yS7GLoQY#lR7;4HfyeW=75;)gtwR_+Kry9B(5lF<^e`7le{SLl1O+C;qm@NrmcdLK8kyx&y~uXp~ji6K#b'
    ';OYC-2JW>^vlH6pa=G#ZL>6_+Ac|j@d2O3^p4OE_9jGu7XoV>^=9u<=JL|=)duGA2L08uDg&=tlvoY|-VNSOT-fVFpL3Im0kh<lV'
    '+`?!Ra^-F$1pNF=iA-4<%V|i7>5Z<w*mTrtXzF!c(W1d+EU)}d-'
    'CWA)1gt35u~6+a22WUe7;<YRYQk21%&C4Qrt!xt*x0_OP2E{>xMYe-AEePBhF<Fxsyh{SDGV{0ZWX^L!3*wE8<%77es%WO5PCj<_'
    'IWT`c`qWDROoGqr0epOM6}r{6Y7<SwwiPw9cxRGaawUkH47cKF>zpC87qSWVsfMVx<j)Jat#gwYzg7@QI5Wbxa#vQ)NS{U_Nl>u8'
    'DFnR2fpZ{CLCF#*Vvd!F`r%{G|c!{BrRVoeBi+zr3=Pt69m|K^v>0_*$2U$MxTu3EMVYy>>ELiGsjkcgMu)$#%uVpU_4O}li^N<d'
    'j}7m(_}C23jU&(>ZA3Nd!upPye{5ghzMK8iLVt=JUA4Q*v?i!yTLHVUASf^$GmcoY;<#(_1YN|E0}esYI~%GFE#g~-e|s~s9Rt-'
    '>=eV{ekWWhrMgoP<mwri4o(iMsF7;`6tQ>IWdbvx_UOK>5IF6Gln4{2+gG(k(vD#Cgo&vFaSB=;ur<0t#=fd%11Lj^wwp3Ec@Gy<'
    'WyH)0Rb~Y^4*yBrQBE$vTrDhpjV>9HaOVeXF?y{obB_r8^$$PZP^^Q*XwelLNObekVJDtZi-'
    '#=up2M1U6`)!fmR`c}qTlJYEvuaUdV1=*2REsd+I9H(w;?r7YD=UH$iN~NjbY=aL+wQ3r*wG1!ko>n<ID(o3hsU5Z70@oL5Y!xly'
    'SxkiV%F(25^s9#aEeCC}curyq|%EDrq)+t$JF_5$IWb=kxnn_QNi(QN`@Q0u-iJx^3V*-'
    'tA?VRGNdyH_K8vxmI1xSX1qrB}{tmKmvgvHbFugaaE7;R%Ak>bzhOmLZBTtNhe*}91aeC&}AExAr}(f5E>S#&{GQ57!4oV(8n174'
    'GD4RLWr#@FLl~v>vqpUd_S%AI0^HvfM`pG8R@j^?A2FX<%5DFR%3C7rO1``O3$U&>%=V-Agt#aansTf^Qy-'
    '!Fs4es_KCrz>Xk}bsNP78%3ox(3-_l)ARH$NiatMEwq{j3=WH_tx!%I1WI>O-5l_uUkrlslgmy}ZOxYBBo>4l+Dxd-'
    'P)9Q@sak^cGN0ZBcYk7k_amOk-dTf3-'
    'WoUJr@w~Z*%WMr)yw`VKf`1mq@(WE#eiA$==|jGDUP@s{`+_0`s{vung2_Qx!$T<$1i%AI>7v<*+FoQdf5yDw=d$4oEmF!yYabNV'
    '=$177uJih-G^|@M#{e6XL)9)yQTx3j0@@PSC6y6a#+haTEN%~!Dk?Nij&p89m(^M-'
    'S6fo@pup}bOUabP9E_Py`>+JMM?*crVq&zrQA*IF()f7u3~f+&_mfnOV&|z*IA`f<3y2mB#%Q*@d~CI0(?c@7%VJWzCO{#Qu}|JQ'
    'x!TUr0WB!KK}DxUjZcdEG-JWrM&A<A_aw(<YG=9lnxvR_5|M7b5?IUjGkuQO*T~;H(Srwio@k(?Y=yVJD_|O&kAR#PlE_wx7*+bv'
    'UDI{)Hi%oa1i!B&*cZ|?fda<WBcV<yH^;>MM8ix@Nh;_RAU#ShR3PMC%C#FhZ?(SGhe5IoA9uLN&dzyURPooXO@4$kuJyfG($o}~'
    '1fC~GPte&1TXlgJ(y&%D7INN?XsdGDBJI2%l2idTD^0CRN<cxk$AS`IoM}O~7sFeCzcEBG(27zNkmK1hX4m2Niu4-'
    'J%AOoaFdrvkOfu9R&R;1^|AxgqwZWq0v6XtdydjWNc4b6h&iSP>WC<_=XpqG;uvs*-'
    'GcbixJ6wJrFubeXfp&ITU;a^Wm#DBvfR$7_llDL^mdk8#H(C!s$$tN^NGn)O_dI1sPKk$;eMWam$x5+kiB_;wA;+XoWRjFbUXz)9'
    'StO?u$M(1t!Y=}k9bAwNp@3F1T2n!`PU|~muE;)HbX^>@3p!19gVoayEs`=()t@Vs*EN%);mzvqoZB5%tcS;8JpKz%Qs2--'
    ')3MO^gq3p(wME%=X^Z-k_mnBkx*?N?FMSKr8AVAba;);?vI;AH-'
    'HSffNgw!0`YG#q)d&kYBa)H@qHS{VqK910%a^4*yhgJ)(TO6AJz-cTNz0qXs+mZY&KBuhQ=CaV`(Zj&SF5{1)apmc@f8H{*0O0Dp'
    '}KP8*5wGA_c;AFXspM2HLGF{N^5Zb(}08?{pFo%Ctc|p9DCM8i<02^aZJds-'
    'xXkDltbZ4tQ<<Pn{0?GEz}ssn%2znBmGEjoxZEh{;a(bIsR?2zwF2WE5OL^Ie-xsoRW*>))14Q=bYA6G-S<45*g^h0FD-'
    'r5jQ<)3k52EnHIh0PS!D-'
    'riIo^SqLS?_~H5X<IRVPVO9$fXjmKhT5niULNz1$j?Vo0t|Agh1=d_x1$1XHq4?^%z$;KHLhxV+z0qOO#S4JNL0xj3jQ41(1nona'
    'ljaiGD!L=CiobML!Lia28?;Ns75jiGp0&eJMV1#)kf?Y+Hvap*ylF1R5Z@4UEW{wpfTW|AEer8ody3wfO=d)=nx6M@>mFAHu#z6I'
    'oVX=>Wj66sk`m&aEixj9_rQX0<|FeVB;8Z&^8}0v+-JOlttA#}og&{;lvfe*4AkF;kxd1nAIHkw4=$Q1vu4h%_gF-'
    '~E8Tb!%|{~#FHPHs=uuzx1^duXhXEdb(A^2eC+i9!heZ?-9H*L`ejz+Y;|Uu-W0l&3HTBBYf)vxXcqxuOEqDLC`#*6bX1V'
)
)).decode("utf-8"))

from v49.residual_controller import ResidualConfig as _V51ResidualConfig
from v50.hybrid import build_route_value_hybrid as _v51_build_policy
from v50.hybrid import safe_action as _v51_safe_action

_V51_RESIDUAL_CONFIG = _V51ResidualConfig(**{'front_existing_sells': True, 'front_on_near': True, 'front_money_deficit': 4500.0, 'front_supply_threshold': 3.0, 'preempt_enabled': True, 'preempt_horizon': 2, 'preempt_maximum_batch': 8, 'near_scheduled_supply_weight': 1.0, 'adaptive_near_schedule_weight': False, 'preempt_money_deficit': 4000.0, 'near_distance': 8.0, 'near_streak_required': 12})
_V51_POLICY = _v51_build_policy(_V51_ROUTE, _V51_RESIDUAL_CONFIG)


def agent(obs, configuration=None):
    try:
        return _V51_POLICY(obs, configuration)
    except Exception:
        return _v51_safe_action(obs)


def _kaggle_submission_entrypoint(obs, configuration=None):
    act = agent(obs, configuration)
    try:
        return _eager_sell(dict(act), obs)
    except Exception:
        return act


# v54 train-only route residual override: r025-1-evidence-h2q8
_V54_ROUTE = json.loads(zlib.decompress(base64.b85decode(
(
    'c-qxn!ERhha{L#bc~Cc-Ey*{I)Vm`rXDCpT8|wiv7+}{hV5|>g-wgk|r6Jk<`ekH9WY%lW>`4UGd|j_9t12@xGV-'
    'VYz4-TEe*MSaf4%sZpDsS$eEM|paCz|`zx>zV{`>1MzW(@+Uw-}1zyHs-pa1W2`q3Zn?mvH@efFn|@4o!?=a2Vy@4vkJd~tcP|9*'
    'G#_227<%g6uuwA;Nu{`&Ro*FWrT?|!_vT&=(T{`(L2y9@V+Zx6Zo@xu={w_hLg?rwi^xemYn^!;x4@!NmQUTDAj^m+O|UuWaPyT5'
    '$-`23{Rw<kS)==l1RU(G*GCNF;1@p*^GJPmYp`gO;jzWegw_WjRam+bSGZ?8|j?&IyvkDm_{d-'
    'A=rhfKf!X?14b4~O^l3*PPUoBwq2X?J@&dmOZmRalXm&%68ClAL}KUJ>{P?{4Ok6h|gk>G2_#aN1^bJQ>;J54}kVW=hubXo*j=G+'
    'm<S$&9Ak8`x%TEZ6a?4l{QcWSqj0;e^GTA7yBT{`Bp<Io-ox=4O9)w(;dFbTZV(Pc3ClaTMf)n=RrCuGD06KmFh1)8>npEmUFh!A'
    '3?46PLlCTJ*s1Q|ZyQ8H=BuedY{P7k(O@y4}sE`TGC%XRUcV&duSm`Ls=bQ~$>5Y;|7h@i%a?4*xgu+~W_)j4bv1`7|sx?&Jsd*q'
    'KvtmAbytQJp>c>1c-'
    'wxSKDVJ{+D7>BSy*cYC{g_xa~P?e0H+xc%^N!6TbJYWnn&hx*&SJNcGxR|xtZ;Ch|DAH0@k4^Hl;s|OY31h<ZVzg}wOt6J+czj4F'
    'e9t{Ec%J$fmA<R7#u#Za-'
    '5i_jLM3XZ`507jrFg$sf*qf?xP(2;>=xL2x;M3ig`34v|MZrE__n!{8_d4C)+Xvt3N?)J3w&z@DVv@^R%|gq(T6meAIAY`#{>V?8'
    'T^bt-'
    '!<~X{*A|x6a8U@{(eO|z;gG${yr;{HwP4*SnkE4}wQt~yfJ>+{adBBeoK*?j$jTn>9tJ<P7q&H8%jfXT+VVLjKMiaXG(5dHjoEyD'
    '`u8{Y|Ek8zT!mw>9>QM@Iam{W7~!a)KEDQvZkIfZS|&@b>BCwb=Gs{_be3JIlipcFc&1(9Bu%`^=b4wq9C_~$o!M>kd0>D~#$_xB'
    'd-'
    'D`1`Q1E_91WS@rKOafJg_tGWANaP53w$Uk&wLhO~q4(xCh{?Yvyi&*`w}AaGwy0UOMmju&1{PbP=OtT@L<^7Y)RHW1gdNJ0$mGJj'
    'tEAf`MV_a9Jv%Jf*-'
    'wz|@h69d@_ieCkuZ;TAAIM88eZ84F)K`sjS_mT^Yn7ctLz$QiNM?zmzo*lE4}N_`Wu^)7&7ImHvRw7mu9Bu$<d={9FTRNvp<eN5o'
    '{MIg7vW6ez4!7Utf)vjMOakVTew46so5t`kA)1Nz7^$kfT*z~X(9x1)`&XO;jpO$5}zyfjv0@w0BXf*G*RAl;rgHb|F{M<uuFW{e'
    '!dL74!InapG^#-J&%h4q|SXsC-n}-'
    'tc)Zmi4JScm?rW6(AG1PIH%8p7sug*J@^#YED;b&X89(ms4i`9A!0`r0A4a`6JqJyI}miD_|IPJF?A{H(PdDZ=>Hk#!zTFTB^%py'
    '`8t>GRYI3X#hW#!e^)!jG0VG_c=dLcjn$2a5H*TkjaaM#&Z#3vm#79i#)(85pd_)nkjZ}#8q?(hE!EFd0S+-'
    'd2uE93WIkPrZd%Mc|F3-)}cPo{<Zx`75<rnB#)qL1A09H4Dt1<A@DZ$h+PI$uPy-'
    '|QWRW)8qcAem{MSFr*EvGTCROuw^pGCr?AM5GeiZM=}&<}G80+nfQ61#<=wQHr1qFE%<&Hpv$mx9{m=Mx3i<=<Flj+uUG_$d?a_A'
    '#BLw_{KuQDP^lga)u*3ZgeunD>23q7Btuspb{&5rTh%}O8CyPCM|v`aAf>%wVf33@JZ=h^=}M+V}Ez|)nHby<ngh}-'
    'aUGwfbKvM$-@weB>e-w_v@wdUX}eG|C-_*%*{L81o4N1NoJqv)FN<_D`CdO(SVmY81#}up0A8R>A-'
    '=Aw&n2(j+vq3`>5SPUa#$XM&}^TCW;Bs3|n|7jfLhFG0=)**-ZRRe2J6-S2}GTlU6(mohP_pg*85&2$f^WTA&!FA1pQTZ{vo{-'
    'ytuHMh_nh=ioLqazoPjCI#}egwsYa*Buls+BKtHX}gZ!iGrR;dzr`Rl2BQo%uE;f$~=eTdqf`#EF`N_FY&KIbQe(scCzkcf=r(BH'
    'mDc4O;zMY$G?rWb?;a(xxo6tSOo~tq18`zM*;$3kJ7)oQQ{GkiELORgAy7`35(Q>a2}<CbJlZZ$>s?A+lq@u-'
    '1#;0=Es9;a@ZqxiwEA&MQ}8QRt4#x={NhoOrZedPe$m@$EgDz8u-'
    'r<b`SW5!|8wczrzn{LScy{#qnG4O>p?&@dp)kEQbwDolNXIW`Br(ZAAGd#55jct0;~Iew1zLyZ?0(W;TCdKqtH%{8s~mPYJArOb$'
    '~bi=#iV4`mpWbBvcDqr|W=Zi;{+07zi(a{P_($w~F3Afgy2cQtD+Hqulf+l(hxI<XQ3JAtYXes_x!H@t@4{1K9&U+L%XS>WsfWrx'
    '|8&C7iR1G6<F=(<)ev{_czifc3Fi+nU-12DLvx9^BhQ!9-blV{|`K`chlK9Th9$lO`;u#hGeGk{2~>u9>v-'
    't@RrQZMbS%35F`5qcSx<PajU?Ksd%VP2zHX)~Vss1BB;J876jD!NPH$n#b3!-'
    'w0yd=tTeF%YH9VVC6ep^C@<G@Xy1U#$u5uA*;O(U-}j5Z&HO2v{*+#nQGIkQ@VfgqaHOT4s@HUaEl^0DA#nF+LD?+U#V-+%fV-'
    'U9N5R(|3OHc7OsNS6{+{+=us*FIR&c!Dz>aH-aY{E&q-M%{}{VL>#o*rxdO&Zry?hN0CD_++3s#3_v98;uF!-'
    'uAE1_Du7cbfysQ|?JB87%DQtmR<z}K5dmi|18r>|yKk#`kutt(nE+9Z|L$s5dJHGz7Kqethak#4ah@5VtgJ%(1ddCagcf%MT7E~p'
    '*;Cmdk}B*@gg0SzLkyOwq$x@^tq7lm+oT%3T^WIkH@7OELir9u)n=PoVxJV%aXx#wXl+~%M2liyI*`N5NL-sgG)qxYpbrid6#APU'
    'P*p-C%YY3+8jR6-'
    'EDS=gWU*#wnPJy$Vu=??KFx0WLa2I5ao&{ZoRV}c3BT^3XS|7xPeWu06&hQ!g#lN|m~t1YGqmpq6q3(Z)y_xtXBq@u1oU9jYeEa-'
    '8lIY$aHMJq3(w1)sQ1)>5ef-ZmL&Bo-KbztKIr<vH-'
    'F?w`tA|9&N0QyS2CzrIRs@WP>lUgl2$sK$umK^%Dm?eswe8Z#IcUHB8O2~j#{&>#lE!aw-'
    'E5a?An1XJM&7AKM;+^lCVtAE5$4unlhOQ1L+(Q(NO<iOEeB_Lo!cDJkBeE<)-RH579qm-|Xn>U2-'
    'KwnT@NBC@tyD<XIM)$g4?sR?)#<cMFnBKjes#e6i32<Y^)&qjsj&`Jp9HJyQSN`{AEuFpH51`ryQ-KuCuuMM3Vl7N1W?`DS4yZOT'
    'os{?3F`^4RQp;Yxt(N_LkoX^%3;21`jH+})f1snwL(L87=^HgKu9_d0c*m>i(IJ88vB?l9p$!@o64jXP6Kl8#zj2*?gfu23cLB7*'
    '}|_k-nu|8pwnE7FPA6-F!=55V??kNQk@dhATT1t0?^J3W6sV`Lqk$47qrNopbSK?9tRKasr_A#oY!H5witazq0=pNrs-'
    '@v7@hyQCIGl3-M%B7XWY3dPO0V0-O`>PMnp3uA?|<}2WSNpUWL(9L6COs^7QxN(=vx|F`Vn@19{oLbP-jz<VRVBEzl6gni-hO|o#'
    'j_T>U&Ocv<qG&&oXn^syal09Z|C&AAy0wy}xb)KTo(<p3o8p4Y&dV;(9#xhi^F*avyNd}nv9Bqg8++mi$3Z0I=*P3xF|)K`x1>^^'
    'LN(h8l>^vC+&Ro-rb|S&g>TMm3r7QIKSV1WF=`mK$V!e9QdBVC!JeoC!|lO2zEe@|E_UM7pm|yGa)V@G*UM-Wa3m-'
    'PDK<9ZvswV|Ix4C)+M{tw4x)Gp0%c@V46BnFnNKCQ3%qogGGJ0i<@f2T8srTZ%9=J7C#Rxsc2&_g^L5#j7r@JN75^R5WeSD725*2'
    '?=~6~AFPLPTY#Gvky>-'
    '+q0|4V#V&=Rr@s+j}vm4oHg+<u!id7fIe0brFZD}ltM{#Aaouw_%YBwWKIMRtYHAK2Amsph{ViDtB=onsoz#w5PD=`?uRj{jgE!M'
    'eegchSBxr%cWszzRCM6&}6M7&_fP*;bl2w3WAy>4A&9tFr>#En%qyRoivL0}XFvfjkAbcioYlBztQWi9E3`n)FhL_;*ECEEHjVMR'
    'K*PV4s+@M@?o29FGYmy~)$s$-}cJ;yjR#X(OERI60Dh^{}is6<Z?*X_!qS_w~!Ye3{(3Ux!5i}#=R=%CA?PcJH1vaGnJ(-Gpb-qF'
    'j2AXXMdguuYCjRWlo7HXP$M1_dbvd#|P4EZS>hdB)jTO=LWM>#U7FIpf|D5!#MLqN(8#ZvD-{8><-'
    'Dx+lWoT4=XCy)6J^ZTdf#YGWQmTePEE3oA4z9-'
    '7i?CY%3>p;XGjmwr=8OIph{q0OED$OLd(VBv$Z+ljWK@w#otUxj*A)Yv!!KvgFi*<aULh;!jvBI}a{e!rBa>KJg%eN+$0z9nz0F0'
    '?#v{6K7V>tkT;Sg)&w)cEpjEY0XQL1{p0nt9gU`rFq$Q-'
    'mfB3HmzBB?B4Vm3(73Lvq9CDbR4E#Y(yNMm_VHTyIcUcIWwW|FORs9YgBAicT|pC#9e!nL}}ptR_yR>m;j;@ssi^C)Q1$aRk0nDG'
    'wlnXP&bRtsrrH8LB64KWv(TosrR=nN(bT#PjD%fb6eT96k3rLQbUULIaQzl!Ek0>(?u?CN2GCdG_5fjllV!`SO39(!tnwYIVyy`C'
    'Sa4gtA=q9Ui>GhvA=zqCT9*Pf*mzeK%rCw3=H7Y3O1n$DmHQ@borT}7a9R}n4ZSPd(~7_vz^I~8HjotD?^N*C@dfhWAb({>Px0kO'
    '8gA=Pgo9W)20mYFEd_qVOIn+H`!nl|WgtQAy2{f32HweBTlD$mcBXDL68P|kOz)4g(3eHLlpr4YxRY=|)@pOnm%`i=yDB;#T#J6*'
    '97uw?om*y)xUdWX}>CFFw<4gRAXF`G4T9qHsTht%^7$>{V9r;7_EEHya$<y9x%a-'
    'jOEP;3wz2!x=R<cmo&4T4`^r5SIQvm=BzddYU=3t7&Ns(90UJIFESwI1t!Qbl<NDCmm2HOd7n!ib?vK@{Qd%#<U_5F1Gnk-'
    '1})D*nZQo);6xmX{TM5a9fuX6Uy#xsF|JU>qvNJj=vyA4=AWoe)x9OGu5OAI4+?B+p^n&pZ>i#jFLWTX)Tl5%1aESxm^bX~na8*f'
    '%yPbQq(qaY3GnZOX@iHB}x=jym+k=|!<zKXVmpGq0RkwHzVSagE<Kk%pPBy*zyjH7SE00bOAZo#mj{5<KKo+5{@@P&jy)CGA?J*u'
    'e1GFwWR+l#|_(hAEO;!Ngz}gSUYBGC0N~t5fke-C{l_xv^|S(pZ>epeXU-*%9)g>gaME(&`jaW6IJ7xv-'
    'S`MpMUD?9_l$VtKM37tx8Vs{eMv^?6jaeet;6FROwP__eP=NSektIrK#m<&|E~PB)H?NFA6Znf_kiJ1ow4D@GXQu<mI<PRH3O?*W'
    '%2m1d{1a+;Jcvsl+wk)3gmO84#bDIk1c>XPoQMeo;!L?(qw%VLuqb=6XT1=gX~uW~vG%irh;VHwlOL%Iy@nfZ}z!>c5NyPTd>_1r'
    'H@I@LBz=DzZL5UoSdDTHFr4u+d>a=I!CFnVKjOb8sAAfS>vgy_Pw`pqMlklXrcwbt~r=H+2EJ+36ZYSwKO0N}}_<Ow~~&?;!REq*'
    'PKOg?Bcuxpj8DC>x(>=wHFwBYd~b9yoc`=$x{l!8LKeYdJ{Bq&wF>R2^Fv~O?for<EVt&kq5RCfRZb-AT4jffxtL@**jcVhxf=id'
    'ORdX&{HtfVJn$e@!QA%WimKVhQ9@dl6o0I@`@g_i|IaskyjWiJ2eFh`jEUY%N4yr(S0b@moJTNCtpnZg8%Y4Ohv+0X_b@VXb>BvN'
    '!><CU8)Tg*`4j#Nu7C@zx&Rnh02Un--B4T;bIH!qx-=>lGN`c5Y7Lf{M2h8oaw2e)x_1W0v3JwD~bUQm|NX*}4d`E|PvgPtvo-'
    'X>(v$hoK$-};gqAcU<^g?YZ9Egl7gpo#1i@FFq&N#cgU=8|S4&i<f=)0I<n-'
    'BQl7=_<|=NjSQ5)q3dQG0&(vTVn6+2XG5v>c*+{C}N6DrX$k}tevBGv|ItaDCxRWrym&b957Xf-$`o|>-'
    'pS0>5Ehf$o;>^(N*`zr1^bzu!%we9OyIZz@i3(BtIoJMN=CS0OgdCCTU@(30|YYkv!E=BFK@`jK>4+L@Uq7oPRM5g*Qb@C$$y2&w'
    '&h=W#qmwV3PyLKuKL_G9FtDFlGC+C#?Sp$L34}h!C|YquH|P=_UhvIyRpR7SWF?6|CFArmL$$Fe+PcYhlLC(h$$@B}2iX4RX=fDK'
    '(qH5}0Ms8uCh56VhxoQs~+`$eoK9IP_rIw_1vko!c(@m(eSwmc!$%k!h3Htjd4$aoc}9G`}hU1hu_cDjFe-{C7sVV~PAl-'
    '5FX?V~(!t`9ro70Lw_AC1}>=VXrHq*~`$t8uTQZWUa9nC}*N5a==roFm+uUEJQ&FmkBts(Mg`rv#2YSE4tMxoT8;qBVZiJg6+-'
    'T)*xmZ9i0tSq=5Q~^u;EDRy;0OSD=*<b#b-'
    '=Ks@3~B9pNQDvokT5aOd+G5EcGI5`$cu<4F_0JKcPmlQ<8VPn?H7Di;v6DY;2$8BB>B-'
    's+D%xd6Kavqq{7~jgBc1pAFAn?`e3RJ~djeAsEu9$;E5-'
    'k;sjob%LKOm8OY@qmE?iU+I{0)peXn#6ill}ygdX+>7ysZg7OpSg&1+?tdgTXu6s$wY%2r*yV(Gfiz-'
    '0!P9Qs9VqNJ>OUIGPfCn3pM7VsZE0;aKc<g&znw)5Hcmtr6Oy6nuW>3N^>(=cn1Z0pi&C6)v5sZOut9+{?74O1ZX9y0pFkRB(m1i'
    'j(w@JnLT$B1BY5eGc(Kqu6C`^UZ!rwxWu%c1CJxX%%qFEQfsv>7tY+=dSD$>0(~A+zP5Qe>Sv+C{^buYv&skN6;$g?b!NozdMi1T'
    '1sW-'
    'Z9m&gA8scVInr()!)BWqN|6BGW?X&dXrJ1;wlWQ<^LrKcB=A(n^P0F)GwxLSGlmdF1r3?mHVC1yaEI?*fkZwEU&sp<h%=IuAgfZd'
    '{IUcFA{<aK3Lx^BMy&djS4sKGMTW!E%kFMx)D5DuN$Vd$RbjX5E9v)xH@n+9gw<Nd#n*L6WT0d(v-'
    'UNDgi_lST<kM4J&>_)%u*b)F-'
    'vn(u(J2raL?2^rPTxGkI84r6k^H*7YBif3M`Ha!#D(EX}~(7Hx4GF>UnIkLruAsE)F5cz~Rywp218t?*PG)uQ}~Oo_L!m&VRg~#m'
    'L>}75yYE2uv1?q_kES&lk~^lM!&YQ6hyTMN4zWDqx~BmE2rnKw?0gYXRn*?1GY>zhF+qaiJiP=K7l^-'
    '|1QC*+wU~?!!>!nly*xVAtE|qIz0^=WBu`W^N`6@!=TvVl-'
    '}6d!y?l*ddrvc&dGBQCe8oI>ofxIER^e_7e>qi!YiDZ8@Rvcv5XzQM)6Uqbbb6Lda;+1q~yr@`7PUHhTbBwrzHtQIXgJmp`NW$0|'
    'ZpmOR6wx;nn_$cv3rP6+}KV}gmJh^Dx3(AEGS8D2r$6)*aa?n{JLbY$V75?ikz3QxRbfd#O|6?fSJUfQK>*88+t1>k}z(O9o;<1w'
    'ujo9oYns=p%6azX`O*P)jg$}pY$Ff@TD|4ynhH4Za`HMUxTgm>}TYJf+vYfhG7vmDst5sQ-GARfM~TMH5G?VvjpQU^|CmPn31NE+'
    '$12k1(T*bO0EAfcc|`|6=ur=W<Yoj_4RMO}cT>c1u|6^sLU^||^&klc7C&ML&@fSKog9=L*BmKRL=gw&KA@(@xPe~W7?kRD!*odw'
    '4x`yj1++6^$9$+;_NTHQ#oyZ@ZS1Yo_C;fDe-ds?xE_^z&*ph2DEZq!czt+ceKwk_oIg(iLiMnR9D%3tdiU9!x4wig9UP~FXz;!|'
    'nUDyWh;OpG?17eTf8S|r3px-c`KFhnwId?690vJ4<oeGaV?Ly1MOL!)98H9WVTwmSt}k}b-#9xHP0l%U<cyjb~mF8-'
    '3dDR9elpFmRzhAT;$IzFj%O$wy+#8zw$$hsnDQ`j2dZ`|g9ZYE~F%{RRUO%}d_F=bkR)L=wetS2Bv9N}yBdV;HYV&|KOKMobgY~Q'
    'r;x&&=(<&_dpvsy-'
    '2#;H1_jhOZWN+<yDLSq!2j&o^WG;rQ3x!49NA{$Q+<yZ~4yJfcm8o1DL8$R#TBhx+r2pkXxD$`mhw2xLM1Rv$oK#*PN5Q|sajrGj'
    '|(`8oqk-'
    'o|U>Mkp7;m~%0z2YfWPDe+yCE7DB&QI(yLk>FJlsHH9Y%f~5GF}=#P#FoeL41i9#uf5PE4l6#>&)cPYw~m3Rvcy5V>IXnHBU#J>L'
    'e#388l&@_H!#q;5r&cy%XKPnDi;c=>%@>|4l{QMQt<iLF?dWY$@Hw;I%&c^SUwt{i*E*qE7HZ(Suk5H*~?`UZP^q^gw7x>e6mho?'
    '9ojl5{$S+CG&7qv3;d3j!hLt2bFohjJS<2%2my8ivEg!C-'
    '5Ct!e;et2ZMH#wmY}6bVJVNUWmoinY26l`x@Me<@m|h!2IU>YieV3IcR?X{8>Srw#!K7U@BI^?%6>uBBJ_GEJbUf_TwS?MU>34H!'
    'V9b12{l+6AlhC(?O2{xX6M(bS2j(+grqD-'
    'S)WvZ;h{M|JKf{^K^eepS=vtCwRTN7dIrYiQx<CE!w!IC3^x&sWp_hP((bJW4X<JRoh<IqYe0)YNT6a3H~YY?SIU$=#NS7?cVkA~'
    'S8~yL#0Rh#AE&bW%Kgbi({(WS>Wk38P?mqvNjWS@gO{q@}{Lq(qgF(wgOOjCUdQ?)?H(re#&kkBf<=ax0~NPmIfv28eYf7o#tas>'
    'xFv9vfe>878CRAWqE_q&<))Ja288O2)@0(J%$XgXlp5P}LDNW8hCo$+}ad$LN5%rq-'
    '5;%HmQ>JDTfT4$;#JT%!d$V8@nTk@F%5Z$h=4OImtscI8xkq4BQ-PQoBxR=LZ}@O0~2*IvXH%w|(+E9qkD_$JTeXGEl|ZfHz}#)b'
    'z8x@N3Vy@lr))pf?&e{)U`4pYx9w*#psoWlcZx?sVUgL<@~o$SQ`Dr~6GIeI#dm`q*&1tly~ZZhd3%E2Lb#D3JWt^&g%m*O`A=qm'
    'VDuB}L=qGhoF5mVv+^SSLy`4o|-'
    '1&A#c<zc#wW|t9nw$tB~vMH=(mF0(~slANNykuY4^K2TLrnP#3sLm&7_eeagP+3X0z2q%G__9HP5zVuL*`vfp>aYRxH*HA50CAVF'
    'b}eL=h>C>LCNVa**bJhVqQ4m|FaewpT@=;|R%t62x3XmKad?V*d#$euqu36HqpB>M@+mxmeL#Xwk&><6J?<6JVKd_iumLH_7Gt{L'
    '@<8^~*npBp1+l8<E1>lV-7hLAn92k<Ge@CC8B?zn^kE@03~qR7H1_rd$V-'
    'e)TtWnu^RM4}TQ}teXl!8?Su)Ncq#TGgg;ns0o{)Qz!!L7A8r~2D_^^qFPv0T&7eM@BFp<@RT>h{ef@ji&dPDPQSHWQ*K;QKlC_^'
    '-1nJM$woxH368&s=a7GV;Ky)h&eh#AW|lL9qPnyRTpaMxwR77-'
    ';OQii(@=Qf%Rvh<r*t`LX+I0yCNC*~r=6OEJJjGI%2*rLsGNRMGH_H2$COhesmSR2)@@d_0+Tp;J<OWiDi++hi5uRE2{<z&$S@=_'
    'zdfp*Ry3t&3Cr|^kIv!n8!>^0-g>2%6v-@pzf71{8}Zh5^_%D7`abr~M(NZ5@xl%mQgxlXdxx2(b5(_BOqw8w2%peQg<16)q-'
    'hQ6$~$hHNCxk|RJU#?eEZh0xd55t%oYju^(U73$M=pwXl2nUZ9p|VY%6SkJ!I}7Z3;9Js-fqTh_<cX3kFI;h@0#&MjJ<Av{`q`U`'
    '@5r%g5ci}xl{!(o2@;S3Q{fk~BfzLu?V%fKhc3~TlD9igdx3Yln3FLJY_i78CAev(NG)T&^|=^GUf=cl^cU5JAO>_MVp2T5O+leT'
    '{n@SnO`M`~R2+IWR*JSav>iZnz|((b8+H%M0D}f(X41`^2Ko_8(45At!P%j%4r1<*`Z6QUsZx8u;m`@@uOGd?tFW<rMiOm9WHmoF'
    'OZv-M=FrrY_co^Ne_M^A8?rs$-A^l}^OYbLrLBmShGV0Ogu|}UW3%{Fp6sp}yA5p?q$X)@p9tfW+-'
    'S60oPemYlhmF8gb}WnG64dw>r{o24!dLr3ABp{wG;U5@I_|x>1xcZwtYvy9M+=vTcb==0vjPe1Q^Rq@Ev4iyA(IBv9qZXog^cgy#'
    'U&DC6U;}8KoEo)>bo`cCAd*Ih1@YXjPAVO6h3GjJ>Vwb_$(PVk;;}_V3j~LGsa?bl6scgG|*K6{V?Ojo@qV+x1Dn$%tq=5U~NSCt'
    'nT9@Bk)-'
    '{9WlHfZGkSRiHq{=|x&oOJK$hPD4Tf>hyyc?$Sz|YZLrvpUG7ZG{N;?HxDK%)Te>%|1yF^T$+V7(&DI3fCRWob)j|qH7ke3@X)%W'
    'yq&ii$Ei}5h_!mZ!!^08z$Vo(m>C!?*Lc+jL7Ic9HQQRS!4?`*2?yVM1>fK%FFAUomeI$_M6p1-'
    '(M|5@P<Tl<x)7yj6*X9d!YCY%_iP%p7wH*Lp^3_uqYRD1P7pSWY-'
    '3aL@4Yf27Cq*%VdZq=&UzwXudC?xBuJE6#%J=`qwd8dolZ7p1E*xhcIt?H(_CGElcaRl>^*Gc?z?(}g^SPHwfIEOkC?_q&q&zjez'
    'lM;=9Wa(Q#%*sK>sy0w*1wFsPqCi6gy)WVwiEHWVHQOU;cFa$Txz9Tva3tlbtHbRp2Pr;f_{Z(u!0>H86ZxR`|;MfQn{Oe)VrBIx'
    'jU9=55b&*n{=HBB!B4rXe{eBE^i1!V~iuDZuK<?pXilF+8}|$Npsz5)&ujKm~3C?D1;O2Z31N&z=Z2^8SUjx+GS&)z?C1ToMvcz('
    ';tR`4c&JKly)EYTQ{O!5|nVh8iYSy?ousw%=!Lq`pvl^^nmgNjRY^ghLGmY-laKJeFf+R2CWGIB>-'
    '8W#MU^fxT*V9^LO6%8|9)s|vG<QXZ?qRigTuReYjk&lOY_WSetRmO!ZE>|o}d<8^4n`rN^+Ds|C|A!<cf!O0CX2EVU$Zq<qQu7lZ'
    'XT-Ox-)lm-'
    'D3;$8Rii>ihcqdQUBZj!|w204)xGkVSOfN@l%r){fYghgDD5X+uirzG`{AGom&2VLo3lJNSP6IXDmRwb)wOzbfx$9m~vu+-'
    '?DW6GcW72!0asx|e+Rq|o$p@IkDoBgbQh~zRy00BUw4NEa9K~)(&Hn*q`zkT)iZxYx-'
    '6uXXDTGP{u3P0%6`9AEC%Iq&<|?Vh1Y}s4%}Fo61zA1i93zZnzHpR{osV>-'
    '7+S0;3b|`ez^PY}__=yrNj2q#sUSLW>RLPEZa(QnRHGmS0R`f@_A;FE=R5DJ;)q0f5uGWfo2Vh7d}<k+no?mjait`~qGdYL*|@&@'
    '^5ORV&+qPj6R6{5Zoyh(w2BO%)uP<y;m4Va<sQnF69g2wrwB+A+Cvr8n)qb;U9uQ571VL4Yy<5-'
    'UL%8%erhxvG8{^N3Q?HA=&?flJiD`5=rJ~N(d>rKg;f>?o?9zPtvid%+sRQ`1{S1o1&;oiN2-'
    ';<7Km|{*(s+3ju0}Un=UDEJ}B9tNA)c5Ov3Is`UG6Po!7my9C_MDYV!NkGXbYW7E|%N+;Rge!3^`6sKyNgaX5&eci%GH8ehGRYKO'
    '@wWPyn)U-'
    'IgF?LF29QbFYy2($s3E4bC1BuY!ptX8m8SXT+ZsQ=e`DyFi;>48z=gUpIISHCAUgeZ*pzoA&k$XIAu%g&IYa8*sV#kSz)#%F`ARo'
    '>7tL3Ui3Bc;ExhFZ9Vc-L98=45CJ-'
    '&jY{LBU;Bqo}$SdhBcF&Z^S5Q}kz1L={~OU|jYrt0#nwxehC<KiA_Dy?&`cgw9TIp*cM|zkNIPpOLNYWbtitCl?wpsVJ0aK~$I2>'
    'z2bcC*a<vsl7B+dDNbfE8eJ*XH|63DC%_-'
    '+$?E$4)7wsuPzyK1+d`+JT^jFK+E!8R6^;=uFx&RE@P_5RbpMSkw3Yluj`CwjLSd28Tb|Gj$&R-l;N{>_MPmor)-'
    'lU_cAo~D`AWTaJ~%DtRxl`7l+y3<A)lnVTz44SLxV)=V_4+FLQu3jtn^wHUa~-'
    ')s&B%vxfeV6|d&`ae(cfP68Y8+nDmauCC2Uuju{<iA7Gt%Mz`(hyMrX@sP#'
)
)).decode("utf-8"))
_V54_CONFIG = _V51ResidualConfig(**{'front_existing_sells': True, 'front_on_near': True, 'front_money_deficit': 4500.0, 'front_supply_threshold': 3.0, 'preempt_enabled': True, 'preempt_horizon': 2, 'preempt_maximum_batch': 8, 'near_scheduled_supply_weight': 0.0, 'adaptive_near_schedule_weight': True, 'adaptive_confidence_alpha': 0.35, 'adaptive_confidence_negative_alpha': 0.55, 'adaptive_confidence_decay': 0.99, 'adaptive_confidence_minimum_events': 2, 'adaptive_confidence_activation_threshold': 0.3, 'preempt_money_deficit': 4000.0, 'near_distance': 8.0, 'near_streak_required': 12})
_V51_POLICY = _v51_build_policy(_V54_ROUTE, _V54_CONFIG)


# v55 train-only live candidate: e103819410-islet-full
_V55_LIVE_ROUTE = json.loads(zlib.decompress(base64.b85decode(
(
    'c-'
    'rM%(QX_`a{L!Q^FbUADamhIY0fL0b}3NO4bBT<v4GDoV4NS;elz^<mc(ICPiJIAWLA$>wx2|hqn_%jtg6h&$jD#*>*8O2`~B~K`~'
    'Bh{ez|!6>cfYNhs%q9{q5iX`9D7Y;`5Jx|LymG``dqh`T4&u=O6v~?*8MC*=K*b_~FxEe|>*{_vX{<j~AC0`yY3&KL303aQXO`54'
    '+u)<FB7De*M$#-'
    'QCX@msguFzyI;={qDm3;mbo_{rvW)SMNSQ=JnnF;&Kyy{o%*m?){fPEM928`|xr8KA&gf?dv~(djIsKt1nMFeCYW4vtKPgemWr^c'
    'JJODU-'
    '?RZ`|%s52Ooxhbvl6KPd|Km`|i!JpBM4tr!Ny?tVkHg`**K?{y43{$$%D5pAT$$+NB)#=P!7@J4}+8qDyzs`&S=#_lvcge+^zZIQ'
    'rMG;>`8O6&CgJ@t1Hi7c)N_^WzUI4T`Mr(UcFf_qcFhhj5tUX!++`!{ayo>C3@zG9_{TRvpdmRX7a7@=R+<rfu=R&NjMyc}`~U@l'
    'z{};_&{+e!w6Wv$d8nFD@*!PO}|<_}k;tmP?l{l-'
    '$(E$p?EFElgYny};9103H~AB99)OvH0o5XU;Hn;iu85JA7!q{$Ho1HE+kcnI4-'
    '@+w3>$8^>qsaXht`di)KXtm$u^$vXYNWJcC{{%o?=9e45rdu;SH61Q18x!Oi{OVf@H>hUx!`1gs!1kQYY2pw*u*|VoR3Y}_?e<aU'
    '~R}pcvj?azG-txJ3@80cRfBf}NyZeuC-'
    '@W~(rH2ClPQ4WLKT4<BlaDcbz+xdLyZmtXX}J#5RU7_0yl=0U_I7xrxb&Ysm5p{_L|fp_qWLfuX*wT{!zI3nH@uB@P$tVPM<Vjk$'
    '7}6)84O%-'
    'Z|?8jpWXn|E*&{ZXYakn!MyT0AGgtWG`R13>eh7>{yz<_<5R5rw8aUuO+6HL9G=2@Hx_CqJp<y<#N*lzQ9Zw98JdRkU3mx~60SH('
    'zzd^K)bUZAU=l}KV~mp=##4;p)TDyggrQQ>XGZsCVYtL*!D0;=EgGMEo|;WISo!k6Bb@nD(GU6Y)%{=8h~tD#D+HFx#~<R%qM=SB'
    'T*X$8-*Dm;FG63v%NXX@Gh5_2Z`DyV%|Bd6cs*=!W+q~J%XAALNyh-daf<eqzxwEb42so=%t_vYkCO#@((;M7V3^KXosVmpRqQw!'
    'tH3Az3GO&C*3F>ZkCKB^xPxrB2K}`B>hTTK^Gv*p862J+r-'
    'u)FeyJEww=WemdXVPmz~=ZujK`33qqBoI9WKj6)K(o#5}Cr%vLg=^&YW>bi&Y1{5A!Knz8iD2!q<*I8sHi|x8*uHoZ>ezzZrTj*Q'
    'WO(q2edl@3>^S=@ei8N_w2g+M_R$ME5?}4xQao1g4mBShzTskd@<qg<7TQNfY*I!RifftMgnlt#(3uS-erf4ZEqjVY6R<o`L(jkB'
    '8m!{bNAqaEwy_tG?sF#sFCa{ynqB`S9`n)&7Uw{rz9Tcg4v+ZavcrYj~~TbxPitdvk)TK|h^w^WgLkfpF-'
    ')bzCemslW}X;U+GE6rB*Be5*MS!1r9*O^5QxEPk?*aDfiPOvm3PP>RXIa{Z1uIR$5si9vYh6bYwOPi&nPLw>?4_qF%DwH9maH2_('
    'FJa1tB$rnw2Qvv<~_IT3=mpBFqUhXoz9Iqd~DehHqxVFNv8r-fFld5`eAi21<O9$vf-'
    'n%S4l}q1KvQOSYhzzjE@ufQWJyoZq@aW=#t?2n7$1>bWo$QNb6|F^I#TX*M6D#S396dNvd=B2gY!8rM(|5F319Y#k2#5f<&S8Qcj'
    'n@_hLWMl6nS288ps#-LY~aL#%%)>BpfqDyQji-)Et^UzW{?k^8RM@0Msh#5);w-'
    '!2Cy#aUEQ>M?(JE;^SqiWxK!wya>gNd&A>UZDL7!!^DMmcnTX#@b5>s6CV|oTSy`=;<o;Wk_zhM*I=10sgZD!=`r~m!#(yow52*9'
    '`;Pu9g)obx9<!8uO!gmJMY2ix|71{n)+a&@IpHc9u|Hp7{_IG!mjp^!{$D2p*o>D=?fR6FRG=wsNoSlY;zkR;--'
    'l%%#<CAF&$o$QCRYf9r_L&Zco(`0;gW_nwOGF@Sg(0W3e^T)SF}ax3Iu2ZI5%L~wUpJ0ye)h*HM6oBDRu5oW*3CfkjKwwaHz4Pna'
    'qmh;OrU3hcy^hIgC*ZdEl<uRS+klaM*NdyCZ2WNX}TUMFLj?ke3d-'
    '3^5IEU7_Abuq0&tUV*?>UjioNX6U9!ES_7jf!7Lgn{<W(58Jn^Kte}uDA_(kY+s71|4xL@>E~L<!u#0|zu~KoWfMurj#wpOy3ICV'
    '1c^0Y1yxR|Z_N7ten2?T~X-_#$t)+rT<Hiw0c^U^^8!(slB6`QQUj%*PLvL_#5kn2O>jc8&=tka-RUNIWy$zz-UWT_<>2O3KU;i&'
    '7RA?aYk{5rkpC6h||LJej4{6e1jYP!pTkuUVeen2$3INuN)#v^ncI&eLh<|NF-6k9~9@wgYip5}*wCQ{1<!nqkf0Uw<{;z?-'
    'U$>7ZrVB8!6lD~V^O4u!sl=!)8h!}cK?FWl`M{Fb>|42WSo8FdbO6~HJU=qVt=sR6iB8_VLvy3EVNw3tX<v^nzt}Y1Oc`sy-aF!F'
    '1xL11qesefebWc_$)fq5A+Rq&lhlx7Vqqu<hzPdTNP$t(M?SG4^JZR+`BWGrxz(gHK!9{~k*43IzRy_&uHp{>(D1*~5OnoJuzFI`'
    'F$ycWcY~sqtq=SUy-^_<NP`|yZ(RcXpRSCb-oE?u#pNxINGMSapSh<G<+shWwvV5`+7N(RB)@2!><axdtrPC`05A%`I~qeYfaGf<'
    'Ef2u>h2ri;=3i+7rxD!)TLND(J`i`>>?Fa`x$;Imtes+)6NSheY4ajPloOcj%tp^3VF^kaEnV`e<DMZlLIzrbQ;N4%H&ecx9IP|r'
    '#dRyLAZc>v6d8Mh9PSJgJm@4!S?;Y}B{%2md^i#}z@5v$P+I`DZ;*KjF}@j@_D_*LE^N)?l7sY}IuZQk1dbldE^^47Mq5?^dzOs`'
    '$E1fX!<|4aVr{*vodr1Y2^$u3O4EQTfiBTSg<GO5+**=nrCx$cN>B<wK{rTBPRaB*3H~`%yj(F>w2h-'
    ';0GsH7PW8E^lb)ZGRO}~JVf?O7%5A~lsYrc@?lNZf2_hAYrg$v7sq*bgb#6_f7|0)zY=~r93Rl3nG)}p`+Y+TwvX3RZwJh&24bz='
    '*mKUL+GFupM|E#Xs?%ydW!d|YbomT44v?WGCSj0}%Wl<iYDLap*N?CX#!L=rYWe9Wllim?<BsPs)NZ(IF6N?#DzMeqEb|K(GkzQO'
    '<%5q9)vt%X-SD1PB7&oFCKdx!&kQ*|k8g!D%06zfOf|vI*g%ejGqqA(ZBiM<-'
    '$A*rJicYkZvdFd|h`5GW4~wawavXu2I8|Pt64AS4i54zuhyI%8=}U|`T3(wL$i}KvN0hHXZn7GpY}(bl<OfG3$uF+DUB1U*=1_#)'
    '9cNBZ7*##aWN+XP{)f+0vE2Ki4oCGU1*^ag4N^A*A_{WKMcEt*D7+X_s-_`{_5Vx=;U*2UZdPW~-'
    '&FFhd`WwRI5t>H<=`IP^1oVLlpU~%2X?@<;tuQFg<_(6@*1U8CAs5-{~HrDk;M7VRFf>CR_6hVf0E%d)-'
    '{yz*C)#Ze{(9oE2@Pz4+Xv}7!MT~PC9HnQj{KBiQfVg0aKKoKA-WZrswgIAAgcsLVVD`6Xs83uSKX=#(9l~$A=t&z0T(%`eVH6X4'
    '|<z(btp8?)k?k__y3^=Ub#GC;|?BibF8`t(}-$hP0UCByeKmYM4IzSV{c)ZmHt!b>u{A%+Cvd$)LItVjoZr=InqW3U@j5-'
    ')+eeYvkgEz_APlEiT}x&duUkT0oCb?%1NbFIcn;__!_Df>u!8HFgE@{pr^<yHxX1g&BwV@yxU87;<owbB+s43Fa)(0uKl{7J8=Ur'
    'VBP;q&+aoDg(tA6%Dn(2nGhSG{OKKWJoXqkqnIMEFHnGRWbaDbAXchKCAwTSa8)4o7-'
    'HUk@Nwst;qT)_Dk1{juSDhjNV}us5qS~INycA?XuQwC(2r|Y4o&qluj)0KY3DtPzZ<Hx&XKXY2THkS1bn05C_*+>r%HkFH}{$aOg'
    '#j^|;tMw<yiv$lB92xzDz-tEmLR{;`P4d0*n>+&-+hD+&|6-'
    'xbRW#`46rq>{v7Ji2(ffJS?o^2i}wZc~FY*+;8p=mBMbF%0DSB0n(Jq7ejnz~Fhl@LcsNt1)F<fw398AdeF%kUiRCn|c8baKL4=i'
    's(73XFHBGns?n?2F2-@5{)2`^QMs@?!`vZaXCt|j5b-uK0y$7M)Y8nx^PSv&tRKKyJ*ssh_E6-'
    '*cgX`MI!|u(UV+6E=M5!5NN2S28rsmdgwEuQ_*VNN&^^Tce)&>id~d;zNHz`sd?$aDrLgSi~j|LlWO}USIv53@dzN48NbwOz!Ym+'
    '>cTKg*NtRC*x!cAJVD8VA8z=c<f__>+J{1|3~Y^n{B0Cyym|YNf)i62ChLzA18m@ud35iXrztpsKvjTUWRQ9T*1X-'
    '^!PkaY*Ow>YzQQ#cV=&G<Dv);JT!Ab+SUjA?bX~^+@jj~V#HopfjMOKBOTV@i#kjCh9bAdnPcgBV%|dlrELkI3KMkZoyCBRd(&Ee'
    'P^~-d!t;$SpPfzFiD&p?yKv0(<GpY1%H7#6{`!~f7ywb#j*YoUQg%)&74v$o;`b%nE$7U(SwHpt6HQI~$d?-'
    '*7z*<LMJ``mjea$L}ZzJ=pbOf83dlqlAkS$u?dLoa#f{Mm`EKdOyD86LL^1--Kz)q}9u<C7AjWxZx1uVmN(3}&EowiBJd0WV(qqC'
    'UArtDyJ<*zq|Bq7*Xpj?q9V#~wpHz!7OX+vFSnc2>5$P)0#$+9zJJ=O<JYtuSgE1S@3eSoOs$R89%6>G{H(sXmO=uX=&OPITEnSK'
    '{&BLjP>+A^)uWCJ~z8sIupcU97p+f^iFIJ%-'
    '!leU^%!6s{6s@fTfaEWkT9lViKG5wmnrmw;<O(<#4H>%r4tP7{G+Xgm%=%uX*97_X5C|@y(>oqQqc)sxy0?||!3dC2o6eIy)t{*y'
    'Gg%r3)y8R|e#+ryBbMOe%#|m}*#^bgM1Ol?<-'
    'nQs_Ey@M=iHI2aQL>fVr$Jqbkury>^CW|4kbb`W>huG+%sTDS0et+&XI8@jX!FaXUV4a7+3Aq?7Lb0?OBDDgha3ao2xW`jsU6ujm'
    'Jefb7tdRR{9R7_-'
    '}G}E$`L@}QQXFnnzKq)j56RDEUn^>n0>9K%2*jf=XzMCCrVBTI>b&=+P63vjs0J+;3_4%$Xwq(lq}G!izI1m(gk2P0g@PS`_ML2i'
    '+0tC=2x>=R&{9SH`7SePFh~Qu)&vUG@2ub91z=Rr-'
    '5lAy+?+I?le8m*Xxt4Vp`@{GeealWa5?ayJkt>`6A1svrw}zcyZGe<`7j5E;Y%ZmP`pnQVV2CyCXN>eeiTQj>1}Im<A)+{bpDkIn'
    'PZ<vu1Y;^FSvbExyU(Vmh^6?S0aOlw@eQoZpjEQrG5|UeS~xrN9;4zXoBhwxdC8Irp^Zh8YvQoOQU0AYPlDT!@vIvCC~$lK&gikz'
    'ovc<4dcNUKmaqx|D0KrIc?<eSe+)0$YK;o7H&EX)r~;m*YK+W6wbXg`9jbzH8VUouenS*Qt;m$(o;Db)<}2R{C(KPXWOKlilk~`('
    '_30K#F&kRrrSM;i9LQ1|VK_<Sed!q2HWIVm&>?YYuW^P{iVSwVpvl)fhNS1l4Rk^GkV3hEnPE@QaNG7?i=O*pk~?$U8u*00$Tdh<'
    'tuFd*?#QA;Rdm`JR>$%|B}%<yJG*N`9$k#|E(-PbOE@mop8m!eh9bjY$ZrKu)l-'
    'gJ`sFwX`J6k_UAUwqUe0=bbVwh=yycbVOo8C8&&%=hre?SpPD&3(|s-'
    '7OF#_ET%~q2hq@hqs;`&{(}Vp*uj~l#QQ7hFc`whve$Kk`Tdl&pJ|J|5KQn0c<?Hgm~cnQcnhC99j0tlVA1GlUCVM!4;cQ9q7)D&'
    '{`81d8VOkJgCdY(_O}?oS6-'
    'eSUxD|v5VKEX@U7j7wZYr3VJVvm`=VNPK=G3tXo}7(6Q>Ati#3525_SP@TsWaq3%Kda9|7l=>i<JmomIq9g}>49t*CS7bV2h9_~?'
    'e96;^(81+qKjON$~>&)$6%2oRjsNVFXE?<wUHRV3guVos0*=oq23TZGqDv2$Hh&PQov=<8C*+yLsS%3i57S2W>1|I!{5gJX^91@<'
    'cl&5VQ(UbJbt1`r0U&mk<*YPmWl!6Ncf?Ck%497$2EIMK7G$#ixg2}V2)$621fX(mW(Q4%;bdoMvWPN`Ufd?<PLq6CN|Wf=E1k?S'
    'v};6Y@)EgCPW4bZCWj8l-'
    'iB&WmGsK*2bP(~A)j76^j=HaHexqJny;Q(u9>S+g38uJ(m=I0a`9#LgSb*W@t*GCJ5v3mq8bP!gfrmT&+tgV7@R{VtA-gP?4cCdh'
    '>iJ<te1jBu|H$tJ2V~OoR#vAiF*u8J+19tAa=ro$$;%N>1D$^z}T9rQL<F^0v(EO_S4V0l~`CWwW@!xfXrWx(Y6ygP!X>WAEd54T'
    '1)|rjqSNL`<O&^h#U5C`v;NZ~2WfxHt8C;`2o@XmzI(RhFgHQ!w_5imrI>R$+6ZL~^r7%&M6Rmt6z~VTRi8c<Xhh06J>n&k+7H?T'
    'w+Z3Ypc<Qq-nNdoFS_HYJC<K@cP6gP~eN;TJ$$jBlLKRn0(GmRKd@~=wgjTc{iuq=}VDPmB!D#dXrR}Wx$Z!r)kq?-sH$XV-'
    'G*oEHWHPhoC3tNm(&k7R^AGl#RqVR;CzBoVPQw(Dup64bE??Ctv4<f;rAZbM6hDEJp85S9As2XV5?*&rLeE%?%%Jw%swyE1*f3w)'
    'k)=Ex+_>7s%Rf}@!b3(P+QHG0;FWyS;+@-'
    'vLVUe<_zL@7;Rgc3G%)~A`GWRH1fM4zlM7?>^Tq6#0a5JoDld&sg}1)f=__bBNzM99Q=JdmV@pyg@+^EGm!STI_@Ghdu{7f*K4Hs'
    'yC<A5$krt1M^HMpEL+B2rtTp#iYg5iEb6c@*=B0)f0HwMVW!HT3;b>Rop;xwQkM3E@E$7`1SxEcrp~R%&Hd2wL?6!;3Q34|;Sn?9'
    'gbw0IdZA%?82)`pmDc#P(zImTUX*QdOF);{RhJx&lp}qO2*dQ;)Vj7N>TNQjH!h76v8skx0DhV$2Aw9;)ZA6kR+efv3Sj7rua}}<'
    'dnA4Y%vr^F&M72aTe1VKN$4Uqgkd6QJN5SkkvM37H9cdECT(^?c0ft*YX%r8Ho!^V`o~z=f)<)4#$+>>`?g=89TuGTR;y@r#_Jh{'
    '>U#^USY+I6`jxvh_il|zY5&4XLp<0&nNsd<=8t!TZDKy~bbcP6y=llYy!G64q#Sq=D1O3Ei-'
    'o>w5{*XD+JQqV3Lk6aL$P~~kws5{QwMr^UnZzi>fH-'
    '>r%q}ruF63V07sYYax~}!jc%4RanrZJPqJ6~2)S*ejNsxWA3rcj|I4uwJHP90iH?wm1u#5XJ8g`-'
    'NgdS`e*`?a#6J=Y4RaYS40<_>IbbXw@W7|a|p)CXy$W00#3wF#vKT}kK#f8y;nNW_Rd{7w@9Nx0&1gNfU#2(A*@yVcx9JC8Ap+%)'
    '}mDSpR-w)MN!NV>##W>BuOBN&{+qp2#ZD?#zg9M3_LR|pTPC33+$MH+&l=*p#yC4}<)-mo;8VKY-'
    'MNzErE2N~Nf5fnntg@|GFmpnK-QfQ>m6y3Qz753EO>FIX^M63gL<n=-'
    'YB>wuedSgoF^Y$h5`Txmna7pg_P9AoBoI$0)_j8~xOQ+Dii?8-'
    'C`;Q$HzW;f+5>d;FzglqE<Vs4dQI}M6a6VnXDky<%S`i^TfaJ0^1zvZr;t1YhMVjD_cC)yFNm53K^_+>b8hic1yI9lk+X=`%;5WN'
    '0t+l)a*_%{)A_<b=YU}9hKS#W!X|qHu^9BOE&`wtnB%_FPXN7+Xf6vkJ0d$&h?^(K5xmW-oUT@h-'
    'd>%&f+MGHP)ky%gf#AVPG?cB%)|U6CM41+A~j)iq-'
    'e6h_(I6C!PgEU<I3Qp7GbwKzBl}+Udh^ZsRd553z;%tMZcRekh?b#D>%*tOOiLm93RoEts!4xD$S(gDy~0fiiFtY3#S5-YKACw2-'
    ';WDwX^adjg8S23c-'
    'jjt+Hv5ju_+wMz_5FXW%h=y$W0LHexiJ@1Fu=_VC$yjb664gouf|Jo;Z(>xjNMRd}@P&b}h)kzq#ywoB+oqTy^V2a8^acdWHt{Mb'
    '3&YYre~?`g>5k1zI7U--B?w_SO32K-'
    'j%t&yva>ztE;R$7Nqyl`x+Qwo?avtW%hx9!Q4M5~4N2y75frt&yC>Lbx|X=Qn0c^MASp@hUa8ZcjFl{8eK0td?S9pwVQV8ZMdwx>'
    'lEjFw&Ckh8<smcL|oUbJY6Y045HbvhF*2b!Bs`)rluRk>0J?cvZny!|^!A45E$&lW3f9?L{X)TRR;w9a?NTXLn<UuX(J+&Ovql|c'
    '8@mIHAp_+V{i;y$8fDRkF2bX{pe9xlmsNP=Efw~+K8g(y3fucEPlCC9aS5nl26L$TczL_}`8D(9k605uA`=;~JQEXoGqd^IC$1)g'
    'cSE4jB-'
    'm4Nj_ibxNUD2Un>lzoGsm{8gl@7z>5rG(a;xM1Ol@UQZh47c%b?`sKne~&u0)bZ>n!h(L@0oqwvpe5GfS$K&cN3hy=BJq~vC;I^z'
    'SDHHUgk(V+Y2}ayIVMV}byTR0;yQzkEbCQF$S?IZy&4)WdaAiJAr703KH=3#H6%26ZBLTp=CP-'
    '#!1=s@{lYV%sXNFR!+R^mr~F?|o}ly%5rSz0-'
    '_^@%KyWCAp_AF+qfdNEL27)|T(FxfY=WnLU8Js3EmKmZNw{InA~Hsd5ZdZ~X(kh2TBA#~*{QYEFo=;Y(y(uZiKaCligZ}$bgyB9O'
    '-T>KsS%=TH{c0R`%*?Z`0OK6nt&J(9XtSgI?7rlM3Z4;ouW3zzth#G&Ro-'
    'jdvBR>f%aA4_O$Mt*t{vyNd!Sm=vH&Af|yJk$O4lrc1k^Y-j%JvO%6ifkulRc-Od#{(3P$yGCLNjZKKPI;~PG`m(e$}rMx0L0_74'
    'qw8?YBT^M|UqL|ETorJ(PdHIAooC}#LaW*(92Gl&kf+mk*;=IBNS}_2~H6+s<VHighrQSam<rY&4Fli^r(VBq~mopwBq2cSuceP+'
    '^SdxmIpN?5yQ>KXJtdJ=unaRa1!9CveH%01F-'
    'gn4y2GdMfM)2)*?L3bm)0C#w+M(2iCIU%?`aZhpWXc}Gc@6f5=ztVV8KnSH?+BQ5J;}!UXAp}Pg!+;}8yiuWvuIxDo3j;tgWb%ce'
    'n*OfcG+-iANC&e#NU9?o{icr7|}_|RhIX!lsQHNcTe07F&4j;4YEj%5|d(<XQ8LPwKs~QBnsm-'
    '7=qRyG@htLoYB^}cD*dyH!+n`!B=&+=+f6~sE^v)6zr|&k&Em;+LkVRYSvLwFpnaeiY#?Z`w#}januv#gDpXuRS4M<Ioz-'
    '$LgC%O>TTRbI1Sk(Ln`7EmKJZZee<*y8NyL1qhe5&RZqo<GV+HCUaCr&{s=r}A>LxQIj;USSmGZ5vfMmWMOjnrDXm!RNZs4i9|zA'
    '65(V7lnGqgD1%p&zZj8L%|Ba=hJaT;;{^K0fWeSC$o^dCbF>T6PYD&aty*NuAW?#&5m#Sn_e$4Ft6y-'
    'u7&*H10)L<?w=j*jt5JHR0*GHac1P-EoE6<*#tmjjB3Q1U0E~?ka-cVb-'
    '(>9cS13NWT;KD<;y6qt6ohdX~n3C?2+10hAdKkGPqSe!>As_I}psT4EJMN=GQk`KC;Hr=}kS*+Lb~yJN3-'
    'Pj#hQQ+OLsbkN1{FD2=_*UR!Vld&K`C3T0+DUp9Nl5)<crdNSYa;%H;ov3kl-xJL>F$IQe`5gL@WUGrYpu#To5p%iGn)q)+iq<u<'
    '=MOp>WFBt~Lr22USfNKhfaMo1NL3V-p2UC2A(EJ<RHozA34NwuPQS?_Y7GHCZhQ3iIOIl^L1xE`>UyQBq3|vs?vI-OH@lD62JUbx'
    '2|jm3iSmS2nici%Zkn1aAXqvZVhqjj>}G-x3UAXPc1$RQWOBGVnxd)joU;7~XZ6@TBZc(n-'
    'Ce$uteUD|u5^$_uxv<_*^6;p+Xoe)o4ymJfu3w1=uv)nnlvolxL#S-c%j)YOcx${WB&!b(0YvUDfpXzT)I)_~c-B`Ic@*iAhr-'
    ')nr!tX=>=L@SXXQPUTV_M%pMvLoIMYYRMc&WJI<p7XuQh)W_%FQdb{E_ET!1TKo?qnQ%s%Nc%IObFowMT~-Ks}ZfQQiZv9N-'
    'zPP$JW196`H5)g677fFahN%g33$(S|SteRagq5D3y;>#FzrPnMi%xB^=<^jX*A^LUT*j=7796TS#Vh8z@S4s?uAcLzNn9iz)9&&D'
    'Xs<uYn_NnrnS(362aj$Sgt~%Qi;z^R@a;C9$#|<dHH^NY@<>Z-ii+i{lnLMc-u9yb3H5YYm@g@P~2#<;{i#Cz77qL#ic|Xu-'
    'bBOdqUS{?h#JTGO7En~uJ{gyZhL5?OFXmz-Tv#^qx_f*anc|EC>)3TpbIm}gfIVMTa@LZ^7|mqE+uRHF-pe_txo%6J#8lQ`X8SqB'
    'Tz@&K%Y({Rr^k;B&2N_!HaNfp&$2RqjJ&*)cVvo%mQW<aMt!<XwbUzjKe`JxygLt=otNsXNG%8g+PmzcF%NsoB`3P;`4H4-'
    'HhtEU^=!jpQ=2D1XzEw3VWW;ISuHEKI|5j$fT+?G*p>IS~gHRcLIr6|W~E1@09*##_!^}nLUakNZO`t7XlkaztXc1(x3gr%;a)EO'
    'pqDl9QlVmgq-Nz{DhQ*4QjbTm>-HU<3{tE7=Mj6KC3)&&{-raK%2z}-'
    '7Na>f9>P(c;8`W<n5u~_X`EAVi8vSZBSx+pKp_zA@MhmWX``Khl}B1Ry<A-'
    'eS@ZEK{_?irgDms=NytT4$S3H1`}voi=l3pM2t601M4657XsBg!TV@0x8!D|&IY^q&eZ3cX)|2b&++s(nz!he$R^p|)K11}6M(Lg'
    ';1Z9dE3x=aw~&f>}W7y%vM7){Lq&K5KWy%G)~UZtPp+2D)5ETb;0QW$=H>*Q?3&;tlL%>jkSnMp_IZ1IgO}_BcVBm{|@un9I{h#g'
    '+<2DellnJX=B_{uJ{92N%>dV2G|K$8>9p*Bkdt<uJX%y68EUPvpwoCVfgj8Id8|Fc(sg9xACtkP~iS+xN7r5;xJq7kpiGpLBDc@$'
    'eOnBQ_X?2y|ZL_Q5X`Nt9w+RU{P&H_40mHrPa&31K1)EZpQwiLZf48KOu#%3N36&nWb`9P5>0>}d5UXt;+%;Z(Ee@RiRiDT}-'
    '~55xjaZC_15DubyDtO=x;&dO6fZe8aJ1di;}m+4$3-8`eBrd;+cnz0h6U_oeQTt9qz`|i!JukXHc$9SPnFv}POB8;NdVArNm$C-'
    '<adb?>fOU~BXO{8s43Yso_GX3r^4DAV89JK75HqWh*Ge|2S8m<`LB$~G#a}4z`AWoj$u_yG-nK@#1=h4C{3j@!sl_YKb7JeqM5x!'
    'g?6y8}_S?=sCBxRUjYsBEo>`+naWx^<KZn~hrFQAF_9#ycwX$bq})cK;BQc~k<`*pDi$f;V1J~pyYieK)Q16YY+n9D?kI~exDAq9'
    'i(x(bcM*Uh4WMvTybtB_cDqUv0{I!k-'
    'cc{+v!5SUjISq<q0RhRP<X$ew{s;pZi%7r>AtFCm07Ni&{(xnxV&;Cf(1JhNuf8#g`aI~pLaJ4*wjFpy2><j^b(T=X>@xTUURcs`'
    'Z8-+v794Y-(r?`Y&Uc6bOS?SOm7e9wov4bj$ptk@^HztP;Bk_yY4T{~NdFg|-'
    'FG4Ss%S5s|<R*T@?MikF5XsoW===`G)V)Twwv+Xp!w_Ae#$5nQamuSp>UG)R+5vFylhj_QJh%+eh*8hlsIJyM2TD0fZiO^V2Y8a-'
    '!P1#pDilO<9?o531E+PCnw)zuBXp^-OO|RGmB>y`-'
    'Y&T5&kHPl&~X9$3Up&IZz3AtZ$OB#DYt#|85gc{sPlmweqBRPJsxCxTNx&<8Z*qu1~-'
    '?<6v=8XA8Ho&^g0s&0#aORPWbG(jZqGhaHE^0kO-*iuoHA~F*Tg~Hs0q5;#8_ZvkL$$OrP>3Q<*{tT|E2`WwhN5'
)
)).decode("utf-8"))
_V51_POLICY = _v51_build_policy(_V55_LIVE_ROUTE, _V54_CONFIG)


# v56 sparse public-state router: Islet backbone + shop continuation at step 72.
_V56_BACKBONE_ROUTE = _V55_LIVE_ROUTE
_V56_YARN_ROUTE = json.loads(zlib.decompress(base64.b85decode(
(
    'c-rM%U2hyoa{MoPo(Ih*Nxx~OIj?ZKrJ#=+oEOC60H0yNI6tiYX86Bb(vUOVoskid+0E4+{G<Uz_EcA8Rb@s-'
    'M*jRiFaGVXzyAGizrOgVpI^Lx_3`72ht-RJ|LcGL>wkUu!IzJJ|Ld>+@wfl}`uTrX!(aXB{==sqv)}#s#SfqV^2_@V_isMG{`6w?'
    ';`HP3)t7(w53BS4d^{fCTz`Bs`SG8Q@9uwkv087w{`|+cAC52F4__bh>ZiAVdiCzhV_x5%UaU6Z#~*(@9^ZfckI4(2jvqe_-'
    '{;G0ynX%0&+ng}wEp^}$6va>{@_Q`Ums7%$K$(q*H>QaZ@+%S<-w0bUylcH{q)1<x9{Hk@?{Y}ef~Nj#)^b-'
    'ynpxVr%#tP7!7Fh^x?oRPg}`xfBAyf$Hz$$Q?zmieR}oj_+hek!>_>$2S@+<Rh+s0xWb~IAHRZ=Ihpyvn9m;;8WdUKt0_Ou-'
    'g)7^4dHQ$qvb!}8eYHY4_^<4(UipbTXZzXSK%-'
    'S%X3*vGHsK;dbZK!%QKq2^KUIQipTdy_5%hnnXRRad2(T)bsFsW$NxJ&ZMt;XLdi{ioqVu|(Za-K&<lJy3%~=zC-UgIGZue)@;lE'
    'kb>Y+8seAmT;rf4@me#yo=jQU*eA)&-QQtU!w$9_Jz0~<9aI!A{*O{#G-;x<w>iL7oT6WyY2lm+LX(Vp5baJ(g9H*uo9n|Y-'
    'TJY}^hY6hd`Ve}&kp|Dc+)?OMJO3wnUc8Ekqji05boQpty?^)a`1;c?e>i^l^!DA`f0=qH@c*fog8rg(nmzd#g9l6&;$oK{?>|r1'
    ';d0f6KZp12c4}{rj}({w({E*?oiU;vaA(nc7>jf{AFjhCzKJ)yjdoBjmRXKO<fE_G+VwJ+alyU$aQ}XM16+3LoRf6$-'
    'b)<J3!n3G8~u(3_xql@WgUh8PlN0D6w5wsasusA4}~3vV_0u*p?1<UAP!ADuKf_z^IN8&X*l1NhX5ksilYR)F#1FtAH@kKailfII'
    'LTo=#TZUaDu_)ODkXhpbZ-`hOKcV_)-'
    '0n%<CD)*v&jZ4Umkdb1Ai*|AwRzQ@MksRIH8vn0!!uN4{>JEP%k4~#8$80F!G8gp|9R$4D;)mE%Kaq>ZrNQKU_z6J?wC1CSrNhbP'
    'FFz#{j@_iuRVj`sjfSiq(kBC~v{X$pSrT`NUf=Oy^mhk1fqAcAShw;1mA@cbpjOW{_#anuAlggKW13eVTst{0-'
    'FeOuUO39G)GghYx#rsTfbUFBLR;kmk^dpKT?{G`b?=!Q|ZW>?lrOfaNA?b^xZ0Olt3BMK(5^Ipf$Cb^zj0=4G_Jxfnr{$(#G=eC~'
    '>l%+~!P=14<#W^1}L_S#)n3`H}Yw^!eTEIr=RNv!YNKXiR<uK*<=;*&>CW9<v<1$vrcls3-'
    '4t#Nk)SM2y)xwjEJrthomtG?Rc$6qGk!~Lhhj(Yt0$4?(#oqjle`0$rUZ0R{bq{$R_xKb4OFurF#l;l4g?4~3y0x;&;X_2*FA(R%'
    'GTn5Xm(e>=`zNzh+E&C#Xo`?>9yne*}V?geBBg!RY=(yt&k^^z*Hf0Qgg^v1+lrYbE0#jna&32-'
    'ZEJy0}^wy%gy7n3<sz?djorQCdNsS*CMqw6=4muA9%!4^IS$drILV(A=??0Wxmf$cn()>#TVihNAx3n`gi(<52_|joC`8XQM8}gE'
    '26Ar6&U^_3v{73ZdHR_O`L?g&mjh@KBHMtfP2}DDb1R09<N7Sk~zkIx%WG|(_qq&fCdUcy5jCXMoH1Fu~HXhja==mdG4gK!$%W89'
    'u3q8;`v@)f1NdbnTZ&5H{l)-'
    '#@pj^<Cxtf<J%GG2eOy>6b@Y?Dj@*sk*XH74{i0tXDF@72hJ>nG<C$seIIYjUrJsNvo@}l3*x#*SKvq`We=3Q)O<qi#k^j;(qZOq'
    'jl6+H2;w9WAV8N%4he1a_=%cM$Qsjp4=$_cmyXy(fd!Xj#q>Y%I<c;vLUJAFa6@9*E83vQwB;Uk6Y4QLYbGJq5hd;Fg-'
    'SJImoc~Nip`{CSdbdK|4AmEy2BqUaJ1J`Mj(qEpc2hko%j4IM|!qd?3&7oH6@umli-jX2cl``X1DtPFqbXk?i<xWeiIg_A+^G?5j'
    '*T@WgK3Gzmmhl$Ow&`Q4Wj3*VpvK~xkyKCzSN#5ouX}kxgzI-;)RPE}0Q*n{O!D~YRu!W>aXdvpk<-'
    '(pk&{MmNnq}BxmbRG0ShCWb9h8gQV4iS!FKJCAL6P>69L~-<wew_1~Q}|E5jwBr-'
    '(>9DT5e8=KP422w8c`ZAMKyBDfeKp9}scOqXTKW0zmE-av}$WxF=r0vQI?@5<UYZ4}@2yIKV^hoH}cUGsH8j%SdZwSJUkC;T7Tj&'
    'g^9%0FFh!HM%!ayr0O8lQXlaJkAR_xPMb>8B@=FS&le7Z{BnN|<T(1-$_zKTbk5&e|}-'
    'Mvr~SVBKWE(=upGO$>y)PNpcC1X?!^m3FdNavD_D?>d@{fx$pPjfOb-h;BEt?oSebK$JI0?-(&NzsZF8(ecxWAN<-'
    '<^*EX7u2iPcx)GMc7*1~X?9JPMwlZ}9j6vT^<ZJTm<6K`mZ0U<)o0FfOTedXF{w6W26Ll8ogK-ETPnE-pi5EM=anAE@S>(M)y%?a'
    'd)?<60{%XDV{19(`j&AiEssgZ=`)xFndf#YBk1kmx2=hyzX0ZlkI~mhWm&;X9?TH1wE3UlAT&n~){?prcfBY5-'
    '@{lC_dSv_frGS?SJwJ`4mbP|^xRG))&>dhk)R0omgB3E%deB-MA@B#-03!v%m7cQXj-t<a^>-'
    '&~w43aLYtT9_uZ}knrSORfQ?!u&^wCH_#S`>DQGl|99ZF;yjAiJhPLg35m-lNloRV3m8apB&$%<SZGtFcoiP$W-'
    'W}%3(T(ky+F58r!ixZp%iP#zd#?d8UfdDTK29*0koC9TO8&yNw2VY4=`rA`$8yYC&8qQ)bg7v!&0Fh=CH}RDzf$nG=#)SpbSU8>9'
    'q(8E&xg1PJ{^(T`#(jveF_FsV6QeF+PY;KQ%w|b7R%fYiV+UJgWd}6(*fBB9qGiD`4S<2Beks}Li)ONK@Mp)PvThg2jB5Sl(S`q='
    '<Z}+QtA!THMFROjct92TwUxSM5#*I<wv75jSg>j5jD?(0aEr#Y02yB_7cpZ0GqZD7qh(3DQ$9#5^K%)LJDH8@YeyJ~qOMD%o55uZ'
    'upJKbP8TwGt;<X?$yy_4>te5ro_lm_n(X{FEJX8JhL$9pJ7d1412qFP<K=7EG4}>67d68adg@G=MU3!ltSOaRH?u(ygx8j$7@C0J'
    'J^$p%4E&$m8K1VOF*OBfs0OAGd<{#)lnJATrw<SaU~#mxVwO4?m;#?%OeSkd<7ZF+Rs!kFjnAAVX%X4Q1P^|00~>ls(M+G8Dwe8h'
    'X-dez3t82bsaCU{L7a8<|EPr(^y10^FDqkB)Gxf*b;-'
    'Z`hXvH|SH(PgKk2(jocgSKu`5CTq*3df6y)tgK^KAX*{tT5PH66HEP@uI1xisl7y~WyIzkRucA?7rMW1LKq8J9=gnGcL&1F;YIHM'
    'iZJip<Slv9lVACCpyZf<g6Ur8?5$T`&QpwV(M&G1CTI5*-'
    'wsNwQ~f!~W{JE4z!WpiAH<jy$D(}AJI4=8UZIN!rjP8Nv2RblMtyU<Ws+7XTuQk$l^IQANZYqR&rRbY50Cyk2df}HAnMa4@R@_(@'
    'kJCG#sn89D7KL9tw<t05pakOSkwIlE59mNUP9S&Vif)20Es&=juCZiEh-'
    '0N)8=+Cb!jJvFLG1mQMbJRMI^!`1}+`iP=GBhrPPDl4LyYK+Bq6*xTMP)q0-'
    '^HCsba;H4q7je*%W^W|o~D7?L$g$t0u9DWNnC$DzCygmvpq6H&Iy2Nz-kBujpPTH6NZAUos@F{T}g0K&JmYl+Xn)Ckt?T`HEup~w'
    'ELt<RvN>}Ch6%CQJc7@8n#JG*TIj@Tj=%u{re*Oq-&^L;>&bT)>~X#y<Rs2!8Y54(V^6*-'
    'n#^cB~UIYo3t)+*sY3)eZrT^HDj;GBCW5a@`TUJHqDB$lO&U<<74mEN?!yXv7}3~oC_V^(ayo9+EKR;g>sQv?RCL_;YGc!^bB$7K'
    ')euN9mETK5ZDu)cozk2RAzWHh_i9SNRy0YW8Uu5mv?32gy73)T9$X<@|DTT+r~i@+nYtO{pH%x`XHkTSqUyJ$U>QI-'
    'w+%9*d?2g;%jn^h<0Qw6=NSzI)lQtMdPC5TjaN(rKrq4iQ;*x7}@zzQzJ9W5E(0VnNbN3&B$pjLA0J|-'
    'pqno{8YH!wZjCA<y9(J7smn^yo`hqu8N*P6z$m~h!`3hb7dXeQYdN2vN);L1wGmVZ&nwq!D)uLB3*lX)&S045XmDi#pifM{KXNmJ'
    '5<hvh;INK%vR<kj4<YF+yTG*P^g+!Xb3@rJf_hc2?jYh3ldsHtzk|xo7?Ze=)oia#<Jk>Mnl4TXEgU3vGNaLA4~?hu?zGei-Iux4'
    '@O%{G-Kmne_Nmj<e6X+g>S3vS>ttoJ-!6D5lk<5+vy6@!LP!srzn=A#T8*6Dz7mf>bB9o{Q8Fz#Jw-'
    '#EPV*X?Vr^XowfS}WNHQ)w0fm4Z?a|(Tqr<)X<@~d{b7d@|I|<-jYIQ`8dTgx=-'
    '@28q2uq>42Suo7kqF;=9Ur^5TuNmoZmZ`YjXF{tuvr81nUGEM@$3h30dT>kKk2nTA1;5x?eJFytt=f;b^60yk&Co9{8q`=q6)*Fl'
    'uwVgyBK)9MOW-twKl#+Bo=}=J5<!sP{u*rBi4OF(P)t_vMW+FX<<@tz&ODZF>VrN;^P|A-bXHfNEZD7O+CJU1XD64-'
    'g`q<eJKf70Abqkx{s~#}tUW@2B6ece}%`W_6RrR0p&7(<#?)U~*C9LmFR`m}sByS~g8T8u$gCpI9j5Y_uGqQck}6$R`#flSY9HPw'
    'UPk4tNdFg6!u6nRLn;m_P1HUFVF(niLu%mO!;c=1~?{F_mV3Op1>Ma>HRS*pF$~C56~yAwFi+UMqw4(ts>snHH@##b*U07L-'
    'tU01un7r*U)-Q_hq{>FT3fl}%%^%v?+2jP)F^FKfYjE=}y!P-vi<AZf^NM<tzzgHfT-?jpuokS~|<g*sMI-'
    'D+JkfJ@0?<J|O`+qJ|TSy1Ab<fdSfB+mpdQzj$O=p#g(HxC4jMG?<#kWjOU>?p#+FZiA7imIV6CrS%r)DAMt5v9dTuR@P#OUH3mI'
    '}N@=n@R3McetS=zbmA=@4iE-'
    '8^+_PFa;)XQHq&I9;O`Qx}(2=V~HcHX+H7n5>p)Wu>_F$Wlh*Pov70Bz#&W0JUbwP!o<h)_3Tpq>!08g^rkO(hmBJNN*(x7Caoq%'
    '=}o-sAHPgr4F&ZW24dB9B`uEUm?W@I%$rHbL{oBj9jkz-70?Nih^E;Zq$BU}ITU*%GSCwHX!4xfmM;-'
    'eYW0UwcRh<trIhvAwbQ8ciXbm>clmg9065oTMU>Ks_V>?Ym$JHCaep$=A3EI{UG?k}t+R!B7!CG%_DbV2h`Soi0-'
    'Bb}RHg~e%Co!$likfT*@^~22P~M0vwFH`UQbu8oMoKxMh9mOxiDwg*+PYAjri+8HzF9V+CL4%YU3<0FH)>_Cr&FGIw;m=*Jm~H>k'
    '@?Qv=^qzwX;mW2_6(sgu*ed5Q6pk*&zamV(bg4enFFmG;Tvpa<gRO-;=+DQ?V89sc5EHm-'
    's(a(!Q+igu86;4JtfU<`F=QCaTV83i?hQ8@-'
    'MMn|Tg{pV1Ix=j^RF)prF%g7}hVqx0ch)S4eyuO<5LrLRSC3*smPdjg&a&j5;DLvPK;uQd%W&z`Z}gGNfCR==-'
    ';0}v@BLQ)a2h{?3*>51H%yG9C!Q3WYZQ^(@w&@H?TC`ZO-l!-'
    'w|4^*@dl3*&qt1@w>7E7t_^bRJ%d!E>3WbGGhelW*FJ5h!Y3tLeMu*2=wWe6-'
    'quJw}bI0M)c*t|}sgv6A{yznN<jLu#ZkZ8(ncwuo&RI~jshhgr=aFq1H)B}kyDA}}+BffEX=82i8Aifq)!@Y{73@efq7RY1Kl^GL'
    '6*8I+GfK3T?G@4epkK?Xv3RV4#h6>(-&1y;c$Qq=brD@$P^!)2|5w-'
    'A=dLhap&3?YW@&NHGZP@`HWl`3K(eZSc)1L#lkT*rcNykn@9G>yFWSVeL`O<)3SO<|pdV%zEU`hO%CU?vmrtp7!7jjI_@iV+B_1l'
    'JaZ*gn75ul`e5Zn=l(wcF$j?iaKRjkWkhsw9Nde4fR-75GPd>95oz6L|qE+X~wm0S-'
    'iiE{Gkj=4LkhONG$g=(cTOh;o!uMdEPM}R}cT-'
    'd~DnvEi9tToI}pG8#%n`M`HT?P|hZp586vkWBhfj1x)al~D4<^U(#UV|y$V3%phOYMDYtqM$U5QYEj-pxSwN*d;5oRZA$tx_>+@X'
    'oe8kvkDnQSGj?;0nlkJaI+Z)UXc)c5)rw<^9Ke!ii(v&YMtPGNj!x+AQ2E7W4ql<4I2!G%Th=%^F3qO~Z&~li{_d*Yrb31)vZ}Gl'
    '6d4oMT|PkC=gu?e<1D_<hzpc|uKON7LE|!goH05nmZzd62QL`UMnRr`Q|+BpZ?Nt{%VRx);W?kCiZ!GM|omMap9zKKmx{+jq0t)L'
    'LX4ArYyW+CAzWYdFDo5=D#rv3YFPcuU~Wn7}8z8?#9etVkVrei6Tgyttx95~RS759bh?{i>9*a=T-'
    'D@+=X?%Uu59XW{fyC#GK8L)yrUvIGWS)QhM~X_1>kLf)?q1BMk(3sDoNof@kkEWQSZQeZRMDOfRJw~URcp|D@fz;SJ0#$GJx!&94'
    'c0@SjE466o1Ckbl|1y0_%ebFQ2YzvDB6`tX2;)6+Tic+P6iJjBJ1`89fN{=|vDIpx177Oyof@bJ5PsmY!%5kfVy%d!ks)Qs{LAW4'
    '~$~1&dPUp+KSw>A-ShS}%OG<$vMYBv!pL(ogF#=r<G_8tRO1$2l-<RX>E>Il-MS~0fGNxU^OKHi)LMZDc-k;?-'
    'J?>6R0SE(FFF}g)w!clIq$sf!utzP%$Xu<@s(MI~$MQ@KGk!N{N~a<Sp=>GMVk%3F{82^fDYQV18cpDS0rm~b4#?}*kd}<UvQlLS'
    'Oyc;M=CPCj41+_{;PE$Be~RNMu7WQJwb_)Dh=melnu-%5IRxAd$Nr{-;Hdg0KpL^~U-KF#&_c6L%Z#yOtZM(9K*Ew<gTMr-'
    'PNW62!r{dw_VwNio?L3v&Xu{j%0%hwog7|WhU-CGP3QVqUTT*0)4<s-'
    '=b)+ocCSWD0&@(S=ABe|rqNE9g3EPR5b~L=rb#ulnJ%f?7NuP3`cRT7E)@%LW?RM?B-'
    'dPTV{jf1CGHk>!;C9{O99jN6kyC8=C5dg><i7_XWta8brkIw&JkQkjODhFaP_GTqO>x*A5xsKWc(B{%WgDJ0-'
    '2V^%<8{FL16Ey3X$2ASOh27hpNtxzyZO_1sVwD!?ucLE8-'
    '^RyG{azm;E#y18UiDQ3KyP3{&d}Q!is$sP*eVDp(ZQ!!BaPcsiC)?Vb{?hBn+RfZDaf2429#{vc!sV@9T~Jaf}}iHH)hUt$Hq9g4'
    'HXy`ckYrdJ9f^VZ6VCvp<iM5}B`Q@0D$oMv01SGHLCIYEZW#@QX0Eoct-'
    'k~{=uE{LTnS4=fytBKo<cZ!&)BX@E;cUqN|oKxiM$rZ@~)ct>1vliT@g~1Qfz$<|+rElAWAcn7aly#q{kZ|cn(LZqwnTGo;mb%-'
    '&D`)B4RBEAs8(ZPC;ln@#`$w&~QL=ril)$S-42$C}D2oRs%bjDB0vB@%u9i-6eC<U`=SYSUf#}q-'
    '##$DD{(<U5Wx)_~OEMjb5vZkVHx_?nXdLlHU{y8~&s|adTaw4Nq*YlPo4Sm;M=;i-icF8Vw-6Q)4yH1V7+UY0L&3SlZ-'
    '7qYaGAq|txKRcQI^~2fZsh7v{=9^Z=5YkrF+cAL;hQC9vbp8u=6u!uEk%4M=b$jJZ9SO8=r|dun@pKQ~;X%2}=}9wRk+cN;6n0Qo'
    '+<hFrh$qCEC~A1lmCt9O23PFj@?4I8+&6m^>w>Za1$4V?DonOByWhh#YyayA@LhK+wAxC+Cb<zD!C7w~qR6%&u_mG_r4;mx9oUsp'
    '>O>1?EbOOAY@R850DtCtNc?OB(_y1@#xknP8rB-'
    'l%A=;bAGTh)#f%1;fIx=?TVj)Gh5P1t0L%7PONwU%eW#Lk=sR`1jdMF|6pYkX)KhvPGPJAZ9yRz7c}!V%{V1T*Z+VsjF1`$LKq2?'
    'FcY<amHpyB_hP+JP0I89&D?)CAe%Ey>zKoU_7)?p+LPnjP{K}&ByRPp*)csd~3<Qmku6~e(<bXh?MHv%hIW5?ASc#0Sk9h!ECF@h'
    '-}o!7Zv)Mh_uJiJY0=_=JmY_7K1xC9cngVj&z!eZJUk7&AzHOURt}vD!o6TaqrZnRjQ=5m@n21HW{Q38QJGe??Z7X_#hF=U0+DZ&'
    'xIaIi|5o8F4K~;Sn42A8}%xd0Wrm})U)VO9IN=eAjTHP<Z=;FM;BhJ;tTqUe%GchUqvXVq(V_`((JYGPTxbgT^w9;YLs#YjoI2I-'
    'B(;zniJKT-'
    '`K0AVyR``6TMW#kcz1E6mRNr8pc?Us=^A#7_6?ONu=Ly`s83!;(;;?PEMoKLdqmpbYePC;M`1`xO3*JG<?i^&u~u8&nO+Bj_}K7!'
    'RirOtz#K}k{ZUd^3;V)987LLH@>gXkB9r4?hvny)DjvqJOm}#F)m^0GbKT(z9_XJ#k6%MN{JGAr}uD#Mx8MMtT110240Y~EUN#gm'
    'k1{T87+C^oX)ESUiRrs?fBS|a1@Ci3fB_QRiLl>?G<z|e5fTht8(RZZ$8a(LnP-'
    '$+dp4xG8|i5xYtkb=3z#r(&wpqg}yu;)#~D_s{tW3t_-y31N|SZ=81P?HH)0ul$p`75H)em!1XK+4ReVHSRVq3JX-lFccir`vlE1'
    'rB$)+Q7;q^`+N*PdhA=hYwN9$>U6<RkybTC^;GN`Faj@cg?PAk9i9%lzJoPl6;o(BOD_Q$~=hPCqF&Z)+EX^q>VKY0BJ2t$VbBFt'
    'asGf9kSD>R-emd8%z0%J{kcOwW?4MHCu%kWzESRLY-MD48o^;fFGmGwK66$<`W|mfFC6oFre_1L@5qpga7wJ}CBtE{ao!LNlVi+T'
    '0bc%5{qkH1Eu(_?!MrniZqmgKH)B7|WOLxHSoDJX+lyn~?7z@QOVsBUxp}7n@#KIy&=aSZ>P6g4+B+Z^NpN1VIq;!bYpv*Jx{KnI'
    ';$@Ia7n{w#$^#E0YtJ1MGF=bmg!PqDwLlE1xB*WqYBkj7MD1lIukC{P~c@C|Z5kj!pB?SiS{WCF7dXmFTK;6USoe|EeEn>=5v1|('
    'JDOZ2rY~Z;o^o6k|TDXnTeeV<)`AvPTj1v>4Ef7#{dH~sJ1o5v_`rdcJeH9d=leNiJqJ=beA(v7T&XXZj-Noij@aWAKo_$(TDG^g'
    '{OCzt~yuJV(M#b_czX$gAp;avyk~l);qX1{L`u;LGT_oI5@3+L2n`#<CL_$;%$7t`5Tgj}kpjaMZ_Vhumww#OrWT+*z68RDhNA?3'
    'Qq@=_^Rsfc|lEvZ2?aDyR%Wl=E77H+78p%E|&x7Dw)g1{B8}gHscQPJ*9oKrdYBD(DpR#DUjE+yr0wGV~xQpYYNb7tRnA=JzhnQM'
    'z=hWk?*iCNM3Vl##zWRSDE9{sw{u1D^!x<;=4sUB@D)9Oy%*e<quCmXn2^k`LMv)JW$Zjlsk*p1l2qE2VPxFP@OH0$mmfEc<x+o~'
    '>`*TY&MHL9EQdq!J%H5;|I>y61fTct;x#oY-'
    '3ug_Vg;ERoGu_NO9v8r61K7jh16CAqLjR^VuDp|(iep{##0O69%oP_B5G8%b6HR##Sc@_7*M>wFDn&M!A-'
    'N>N0^FG4_PeVId;n8n!o0$HEwsr<Y@}79%JirKyMxTQVeL01i(rvJ&Ehl3hE54@Nh$Qi^lxZnCd5J_8~eNu@9=ZT&aIz7B(n{>|7'
    'G4Q`5iK9UjIxDO5OrmK#bK(s6rUC!cFwiMfH35y<&xq%wuNCAhn7%`+O25zaBcl$?=BYKusox#lZ&7j0M=$T;+40Il^j58Bk)iUb'
    'FR6lqcIOmOj~FpubH=k>?!{lv|e$9kT_qC~SM$%Trb$=L6MF7HH6qKMEuowl^7Y=di=EL`RmJ!HQj0CnWI3lN-'
    '!IR1CLKny2mIn2<R&ENV1&6#=1C5lYg*e0c#)SdEy9*W;-'
    'r%HrDa#0K2hX_UlWW3tKZ<i}qI_Tm21V>0_WxF>_HjbIO>vrmGx)VU}Iin1w{IWV10!u2RoSBwrbl_9f&9nv|2YHW6JpMqG($xwp'
    'Qomgoxl5<q=trVpTD>PvjDodtIjt|LcfjZIcAN+I$y%u$IVb9F`mP>_OD8^zj%JvivD@iHZkwAoG(eGwrN|N$b2{^sh3J_=bW;u_'
    'SO}FpH(+pVcSvsA$imfBK{?E}*c7plI5N~N(k~qN?dzxLj{2Ty~Lv#Jtd<US7Ss-'
    '4|Nr4umM(8#GHCt8rbLyMFeDHAr0U%Ni7prTV$=+k6RI}T+sG*&Eaz8yYhTJWt{Su_Syvg)tT_#<L2y|fBm<l2!un?fbUU7)$-'
    'hkuWQR4NQG6SUi<W(&L<c4Mgu3r#>>uIOe8>c_djk>%ne}b_Bd#hDZjmb+<@qc1KFvBuiI8DccQ(PW#S5!QTCSC*H%1O)kuRz(l4'
    'gIVFP1IJ(rf3g!8kW?lJ&<A{fZuEvrp^%WK<av!ZKa>Lyl7LX_hd3}G#ei`M=n&e=|ryim?=Mwq*;LjIsH+uF16r!`>Jbnw07U3='
    '=@qLHwwb2iPv&zZWWo9bqKh!n<-'
    ')|#KUIyUoiz=Y&JjRL)3R4G4@(#D{1diJU2@rJGB*uiqI+DgG>p^X)$Ao)T{34hyG4rYC0^RN2jOS#({tZZUY3)t|zd8!-`pTH-'
    '}5anA<U3Fj_1){93rPvS|p)&b+)awMOqpj#Tuz6tFO!Z@H;jNi8&*5f7pn*;WwnJ4I1U*`icXW|O8oZQ`Cds4XQ+#BNV+8Kj|pE('
    'wNPr^K4&oYB4mPX6So9Y8&2kzT|1FG-Cvjb%&njVur=H0;Pf`u%y7m(#E5%3PZnCQeLMC1LRq!0RxZgt7RB2*Qk=%Ne@L7X<AS|G'
    'Z=}E)-'
    '#jrCkE0nV$b`KFzWfNEx02fvPD)uv1);=^q@@9}*r4^ou%(itKD8Tke#KkqT7~<1>7x>OW;83L&Gw`c!DSjVLm_iwD7>AUG2<<`L'
    'r;DOT`qD&J^Igo2{ETALvr5Xh97t5L$}O)zu<i?%NHPZv6EA+xiSK#u62V!v2N)q`QGtdk#Ko_g~l(Ok<{q0J5nH}F|ZVO08APn)'
    '>3FEW<+!1&Hy%AP9;rLV<IpDcf1kDHAjQf1FlFiO#XQrCfNB8G9rIt})8dU(Bl@a>+lI;8KO?oX7LbkvqBbOgV<)rqB5Y13c^AUV'
    '3JPC*BU;-SMK$~^NrSJrQ4XE~(+?+F@W5Qw4lre+3}P)<YqX_IbL?f}iM-'
    '}BZgECjwVO_!@clS9?oj^m)g=A(xpZ&~QnSX=cP=uC(=JR`T$Iu~NF#WFyiMD&kf9i<q&57YAiN&j4Kk)@Vt&{yg^;k56jxRTo{f'
    'c|N-'
    '@=WUr@dPVK>0p_ks+8?PRu?@^|MuB|5!O1X(9P#i=%LI3kdD?0dx@w0lJ6U{%rmE!9Lf|ar%VYr0zsHF?@?If(31LM2sZ!l`R%(m'
    'zr4P`e=nOjbN&T98ogQ{N5jC@Q7NG3D&rg}z?EE}$8L%O0iv-'
    '8%f?<wY*l(6_bY$}Gdb7E{~7q=Q=<yM;T|Qm$}D0|`sy`zxG8x6Vr#k~B&~U<+P3iq`tD63W(;4M1d9Ux!7YXQ-NW$fn@x@xp&_`'
    'eZ9q?oyV&xZ$jrz8vJGN{sULEf;jTi5!uG;beH3}H;`MZ>+_*syD01DrlzEbWu0>_aPIyT&>p~U%fhD~16V3k<R1x$Y;)s}8TFKW'
    'MvF0bDm<jiV$S#l*0<<hnyK<i=?#8LF1ct*9xy#^{Hu2N%rI=@zr;1I6YJsxBv{{7FtVJ(KU>$>iA`H>)re|WgQD=kmyx2;!(V7='
    'tVVr3#=lPTvWbUIG0Bw-b-zD#*UAlcu!FCCGSWe8C$%3U#k6wP)Cd5u};bP;Q@tOJzl`RX8-'
    'W87;xnQ*tKZ+P~jZt)<vEfz{HWXT9VS{pde2J*rV#T?*tLO<Yyh+1ly)6odshUVpicZ)mBJuGQ@*FBPkev98Z=pCuc5QW4bkzDYL'
    'Ju3*sjm%EP)5L3;EsQkp8POE1SKq@98@#n0v1A}vD%ckoM!G{se~d7aT^0u=`Y4iN`_$|3}-8#`#uN7HjaRhZ2yT5q@z_)#8QH-w'
    'q%>d@N6ysE{Ye(vd{)(tkVc96`dRg@I5ZSW1SoWOkhIYE)1C`@F}01g#X%D%)T^_69I>QnIxE&Vj(6?Xpw*?txg*;ioAUg-'
    '!+C!^bO5-'
    'y*#6%@<#Kq8~p+*^#oq<+V42o3{W<z3e}HR@97xc=@(KcavVJgUg;g97a+%#x5m;au7}^Y)`;M#5q547=M8&rK$_~%{xc8%2cZVr'
    '<p'
)
)).decode("utf-8"))
_V56_BACKBONE_POLICY = _v51_build_policy(_V56_BACKBONE_ROUTE, _V54_CONFIG)
_V56_YARN_POLICY = _v51_build_policy(_V56_YARN_ROUTE, _V54_CONFIG)
_V56_A887_ROUTE = json.loads(zlib.decompress(base64.b85decode('c-rk<+io1$k^Gf`p65Y*;ceeIQhOzsGZZLl8{Ppi7+`G}FzkofeOv6mFDa_Ks;eS1BJ!M~G=`tlVqfaqPiACf<j?>6>My_k_V+*k_Uhlh`}x&}>yIB_J$(P&tH1vGkN^7br$0UY=kLG%_P0O(&*%UB-}m30eBr0tyZd+9H-3Kg!>2#}^5O3G?WZ^QuO8ppzuR3uy*PXP-1D0sce}UacP?h{{J6Wh{ps<=YW?}Gckl0ZudG*3KX(1o`ya1wo__Al?f&tfHF)RayWQ@?=l5nk-S0l$pLX<dxZc0{<EIb9Pp&@y<l&Q}(HZ}7{-x=NecavLj0a?;wPy6R;TeY>t)>kcz5L<R`<u7FJkI_7r>6lEClIvi!_D<i_rruu+BbR3X*-8soir}$%Hy-%><*(S4B=t2wVv#+?{{~z={|X6IMq?7-dv;6ZEh)83C~XgQ~N!fq;Wr<U-fQezA#36<1oU{bN$?+!&HF%^di$fdg>pZ4y4J5fgxU|al3190)fdKW<MX;>33hEz1d_=2Kf1ty&H8H9K8Nuo2KL0eRIq%T|BSjBj)h-^UuyFJDFJN1R2c}JTLGxqAAms#c=+>U!K1t59u_f=quCDEjqgMm%T>!@WGRX^Lf--hITY|!voTh9sf;ve7Es@ZeOLdU;Y*h=kRuYI43`m4_Nm{jfZog&V;Yn1E6gcJ0FUJpe?c8e7hi<ess>;o>Oc(!W&9E2@f~w_%XvRi_h5S_sI{Vn=~~%M-M=z@caR{H#fUC_rLsMcX$8(=KX)pEi?QHVw|Bb6%N&-MK$`J`E(7-`{V7W`D_iw1NfD|g4oO#?3dpbteWE|;|{d9a0?xPV6>$991f&W2XbpnZ|+(%$%eIE^!22tjIQO;t<`=*zrDNtFukdUW1z#~J|2{wm&Q_;5!$2QaC3ie!@H0@^snYN+D{Ap?Ccoare+yAq^F4RnGE(y=1*?Rp=-s25p;8Hjvj#9h#Nu>x3En`Xp*v@*4$Dw4XJ;xw;D~wynQ8Snh!km00~Sf`5V{{a66E%emJ!~mOpN>^uv6_N%N&~fd=!~v_!VoyX(9EQ2KxdeV9%-u_mU3h99^7*yf&#e)OnQe_{quXginy#Vs2E`yE^5j2k8@nE2ot+lCQGg#CgDB5hfH;lL9fZ(MWL;9n+azXrigqHeV5#OIcFQ*IN9Ywx9OtqqO8*A1$!FqwJFsJ5GYk7?GHZ`!%Hr(@6Im$PQ{+nz19m~L;tGrex`(XO0agyM6Yix77R#_8&DoakOhr=V)BkSihS0g0bgmI@ribd(Eg1sm$Y*os#OT`JJ*Bi2)cElcdpc^i5?1R_=~w%R5>8qrgU!x7kQ8^>l7;u1%wcr?S=vMY_uN;1pw?m?DU2+NqEpTIqsU~Q%F*wnK7{=0~TXFiV4>F|RClrG14$~I^H2}WFbLTa1#)V4>@iuUOEoyP&XyS+bd&EF&Tx1?2=n4#584R;(2deKLYC-UR{-Sz&5-QC@v@MF;=jdr(Tjh3x@*h$|kHEaNQiD{1^%->*|dVsXpeo*bqeBhDIRRP8f_z+oKBmiA8lAv)uTXA*HHQ7JI@|qh0-B8BSUqh_SplBNQ)d|Tg<YVNkNIxQT#3M0B`%W)5gSuKE`VaS=*)Cm!be;T%o98Ki=3p|qU>{u7XU(W0#jatmr$*Yz-M)GFdI+d*ac%{(vd^)=Ajy&$iv#Y9nYWNIsCRL0m!&JI@lNQ2n8Li8z&z;l#FF{tKBO|c{Vic^af6$*9zYbhguQw85!{ThXFvRvVm~7)-@(=yZK?bX)_0k%!!|MTFw>ZTe0<@D1d9PXnl5R<h^oSVX;uw<3bgc5&|h9}Fa>UwmX$830_h;nV#HoYyr6g0ehP<1!#Y7{1_A14w9iIjOJ@A)DL83zEHEhXQ&UniHBjN9vvzGzWSG0dv3SzUd~+xk?mEU)>Cs)wvZt18G3N!Y8R!GdKilUjOZqfA?DAf1gkHhiqO?ca34rpJ(esthk>>~F0h5wJ3viZ&*96BLgije~Diyw`T6Fu{+o!d-dTpc@;ZaF=TS5y*4%(<iwNx5%JRjbEyt>~i(j22_FfW`~<mjSBsW9>9>X}BY>5K)4S_iv^fYE;4$P%VVUS@#V!qDxgJACuyy=(IhP(x4eC^X6#48UWr<BPLI#$cI)gh%iv$lQqeyM?n2kToI9Fb_Xt$&xtNGGl%%l5L4_nqhT^UJ2U7S`uj{;xc|pS2_pxgwkYRra55Y?dv+`3jM1>qK?!6?584*9Cld+_FxC~301^~khg8f413%N{vpTe9z}{ZaKiv~L8Q0=Qqz7%oK!TBaCs-f7a34g$82Wl*)mVhF;x!d!j+f`A2SQZ`AJBP4HFxj&}&tW?AWSk9^r6XldfMPt}@5O<yeQwp9J#R_Jt_&dj;EevTBE-P9l;}_Y&r?O4}zOFXeA`NbrEVYnfollEKd5o*LdBUM2CYj<K@Q^MX5T`0VHvccQwZDktV}XyJz64*o9UA_nl+4QSv#EAw?3Q{3}tiebcTgc+$U`)+fOHmzqP(ZCtV&yq)$B~|n!mmx<PZ6tuLK#ZhI+8CjLkR~vjxnlcbsT{K5XiTpQA9ueKCnOw~IvbXal}a0K<x1$uL$mFukEA$TWJnN{YTEqu?Ce|z!rM)7ofG_}WdV`r;V~>rFcMe*x}G__S&sBFT2?mvLbTbq;nQ)_h_(Hdrl2=EG7pEp#YW#t>0Y8&5T7!iFN)-wj&C(eudXLKuzeP|gj+KZ)uE?uG@SXBsTxQj{B*qFetduP$H#xqLtl^4S)<!v_Ve_P99G1aZ>`pOKtu@fGC0Gkyuif8xX}kuNeJpm$g>!=*oXue7#NyWJy=V01r~-Z!!mF^!l!j>mou<V2y1R->iy`YS?1(=0x$)aN5JShr7l{bxRym7r28fAX$oDpFXgHqMlvCNH+QL}PA8uOxw_}ROsZ@^(cY>07P_XDGYL5cc<KVqx9rZ2Nt>EksstUhZeuXr6Vq>9)R}Tcc&q2ieWi>Ux>)u685p@1&K`66q18(w?L6qi+*?_CC82e|^I8pHM0<-Zq{YN9cQV#U2egxPV-^Wd2)D6{e6Y!Cy7#`cJ+ppz$c*uAT+u&Ca8lr$<aiCujj3h-7FN_q4TsEyS!!hA^oT`i1wFGNHYvQKRU<hoChUS(Q{>v8R_E&wQq8jx(7U-c)vH{DXbmEA0BY9AyPNp@ZE4&vTu(^>u!WQ!ZHe@>4XeWqs5<X`Bkyuv0;9Ij7@e!VVy|SF1}Y;J8H2M#+t0z$F;kh+R4i?yW^lwMzOaxQ{G-i{g~2{TeZy`ebHt|^P?szr=~6?a(QTy0HAcgwFLM&pS7QPbtCL+L5reZVdC=;;6K1y)+RM|lP&{+VydSJ_#a4RWw&sDQ*ceLDfb1>Txe2xoN}~&Qj<rI~w9kAaWu7nJS~!J1k-e?@yJW^|TS;HA4TPSl*CF8=dBURU2ojzVa<2KvvJtDdjFS5{v9pYKzB+O#$x=Y+Xm@}s&ywEG%A+0h=Ip`MHYo!XFU<+*2}>+g;DLa%H1x|;BTfV38Q`#KNb@N4Z6Ww&li9#$eKJ{`mk5=yD_>Q74(BDNZv_+7ti>AGM>HDmP;R4p>cn!Hfd&PzD3&n8orpi5>z@gFxMuhj$<Z?Bn9D)5X#>kGX3huvC`kZNHJXV5#l^;G2?7e=J(q1iP}ipO5Hi<Jz7=iQExjqulEj(uGXjn+?u48;bNaR5&zUI220MLh)Ye<`YQd2U++Mutc=vOtpQF=a-&bopFoPjYKKZ%9gwp(&MxeO?&dMa;IOBCR7^-T&hRB{MT24on4?{zZbl7>^xxC7~aPB41AJGiaCv~d!@a7iOF`=6{7tqJKvos}=q{r8%l`uOMg^dugNK~1+&t0nFLp8xHEG{{SOm_QcB00PwMyJNm4J30zIJh`-i+0T7!K>f`$}&kce@26lugHjF>RgAD!7XIW5UwECnt%m22tYj<t4abAK>bkukvs*_2%|9R^DD-KQ<d|DOsFD^1$6_iiwmU;nT4%$bpraZhJdLU=TB`y{gTzHEW~=X6pF{42o=~;a69!?CJfm`FQRcPf#j}8cTorsvwo2=-Ak*{=B`sLYB=3sNYol9DRxT;G&wsAUND&VA-2yMYL@R8ac5`-3XKC!zsm_<M&+=XsdO&F&lXo9>`N-wkYqE5)@MV2UarOlBcav3lp)-0dKK127S=4ISW%6vwz+_go3h3f{Y$!~5>39gz=%-Kf@Pg3s+5^nN@q$O^yHM2kkn9y)Q5&ryrk9#t&a!WgBZekO5bubktZoZH;#88|9+nd$xl<yuOq@Cv`~5bxkgl2<iswL<0sSMT3KR>rao6uPOl-nHvOulFfk#Q_GPePq3$TlgKdgEGRloYj6&z1PN*uCRn66c5$|ZP6qt>osp^7Z+Pq0=A7Md}+sv(8qpxn*SaO%~4L_Z)g5EEw6VJvQqJyQ2YnG;0Dx#!9ca^j{cXbpgYFA&IqNXbpo!J0Ro?_<Yx~{f`z#Yjnms8=&log(iu**0p<!m;R(Jq)Sj+vuQEiLV%=KUg+V)PRhCyuII%yMgN*-uiBhNY~znMuL6Kx=WnZ`V@xPLSMQw@;k4=_N>{gqmV;F1{?;oC-ucGl4#UOwnn_LX%>YAN`H-ZY=y0wOHbFQWS0GCoH{Y9WRDuDmuc+YH<YK1D30lr_{K$Klf_NA-XnugIFXF!dV9}xn0(TG3&tQ0pA8ZCpx_viq~?4HmcvDmIAWJHpi4<9!z{9hU4zSMMORhaWx151*5|a0@2P2gkeTT%M!0f#LA%!@-|0G#3)zgK`kfwV#qU>I4=DeD@)~oVJDLlQcnHIi;#J8^=<jzeR8F$M3i!AG?~Gj`{CO0V^q(D)&mpiN)kmnmVd#pHB;#*D9*GoM{vAGuwosidzVWv3z$n}-^|!;(_SIrrAX;D2aKBnO_p9@9+!!ztg=u`V_rCJvJ;Tes=79U9b};<c$%Ui(^*+PN@avx9J@4#4-}XxSGn&(m~9@?q(KRe6s`;z2>GU2)<Z!a7enjtA|qar=A9HoMoFNbseGUX?2epJu8yC+n7x+g?8uH+VYO0a@3OEGa$<Tc(L7cW+_^+jR61t!WyyrW$Q6qs%P+S;nbsF(sHHh2V%k*h9Al$NuyGtR2N~ubPCh%j2_Ar6)yJ1h)U|m3A`)@*ViT?4Z!Y2v-GKnW%+gHGl=|MLQU?S`u0WPalsh68n#Xl^nCHcEEU0D%wJn|UP7ZQ|{oTN%jszj5gSMG{0K{%dmp3-7<2rQ2VL_SG^V&;&qKCPTaFn8*k2wOo@}$Lh<d0(~-?%xJHDyAa$9MzeAA|hG8TsK{3@4KEu_rCe=V@=OIrIs?Lltbv+Yh@A^0V>k!N&}%3xk6|u-j<Cw?&zWhX_;Fh(2PzuwCfWKxiX1r5?-IU8|m`P$)h;cS3fd#!>sS6{<z)d18KjVrSjvg>ob!Qm|cn=z0<N5xU2gKc9f5-SB(nTSlBJBe|rqNXxMhva>Q&wdcxBWP_DbJBgd$M(oL};s}+K9fY*dRKk+Wx&ADUCll&i8V0E<%oJiWq_hBhU^1Oi;>TOmMBckc_Cb?`huj<cGUzEb!KEmGkcW!loY|C!M1Sn?Vc~L4fRi=z99HRI7>Ef;k%c`4O1C-29SBgSL3#-;@*OCM)sD_pXYRSKW|yFS5FsEMgfvURAl}WE-^N0(Y^=cwD#4p1T4&RtSl9Z$ZbBkX#zX2OJT_>zcwRH_R-RWB<i8*@pZc?WV`(We+lP|h=kGAw_S{CR7x%G19&4{)VC?Ptf9L58KE9O~j~nBf?jDhiT2%_9TDX9*ZgR{(ubUjvF4UN{<7VcYf=C$z+j)V#Fdop8^}{zraLc;l6m5)#Xi6n4PuIR^QdtNWPCh<jUXiat9B+2!9bP;%xUz8b>hZ&Rrmy9|G9nMdl=7fR8|X^TuZoytu!&Fp3~S(a5qe^w4N{?<7iyMuEmG_#vW<04rF_-qJJJlK5<)U;J~h{Lo90U__2Qu^)yE3p@n{-7HMNvjQ6X8*x3O~n$gfr})~|~{UAm@k;JW9W8XJ}hL7ZrToJibW_ClTVp@5A{yT$yoNNIpr*iIGd*S<0X%#OE$IC&AA*@aR|(IBZ9N$H_9`#+2ORRA+9{h~_Q<cJj+bOo;9m8n>fFG}%K>shsyqJpiH^O44{PTV<DkR~delDjE9k(gxdi9!&KifSHw=!K3ecqB13E=x*E5g5eSCIYmyXXbSy^22;aREK?h>271YQA;9`uJ&!E_BKL=ie$7Li7iWydu}CT_LxY$48O;&MKA|}p9_QLLYcofHep0Y;tI5T@$4nrL(Y?A+oHvd4na9%12BS7Tui-CoFuO-TEoW~mgjN&L~5K|t1}I3D(PPgMN+d{PY&2weI>?u)pY{ooGk(dOxxQq2Zj-pr^DK+X-r~Tg3?WV(V=47DZ5Pfn<cpJL`EhpE-_D3IFM1cl&(@TFIdEaF|K%d-ZbmrGz~-5H`{$%IMh{JG7(zixQ2b4A6J)!nYqeIiMI|#(q(d%kPL?b2G4EHVSExOrkj{TX=ZB)i;3V~oME4vgpQi;`k_^wM7QAR^{Bc_Vs$ASE3@D)8d>q;kfdu#oR+H02Eo7hKh*K@s{LxpAs9p@VwNOkN|aU`5LUV7M0Ab>lVa+tQkdq;#a+?t4sw>}5X}i!YO;2Ua;ts-6%ek%8**b)Wh02dvT+TCt2P}eLS(=P5aId6s^}f{*SP4`$-qUY6yHR){?WQ*w3DPy>W8~3L+Wv`amlU5dWM)NC$yUMi2MrKr+{EgjYFVe52{-+(T4Jna*d=cO|Q~mfp`HIKbiv<ZRjIz5B&BMpyym6_YiL<!dK|toV3K{(!%qbCA&wYd|3V4*`ERM_u7<TqAy8Ml_)btc;D;BTsc(532853fjcMGx>(5`1}F{GK|Tn>XY+DN@$KX)4u5sEAtZx_Luxw-HWKQC1fabGE<r(_6U2$5ZV~lqYZsx_@0EEUx6Kfb6XsyR0=vlbltFkl;Gdl9=Ct#iat1W>WH_A*a?`M1-PLMg0)(-Ii9%&>DG)?;9ichhQ293~=L~G)K8{7e$&&H{2}VtH4?RuZ5tKkxV)3N$+-JT)=oPUx@*2;ZW{A3c5EWE3j8Az;WyYPLP&auNmm&73WOm9k9exUk2BJt#MsaX<7iI-nKC%=}njU9woG6f@%?px@jn*$gI!L+(NgT;GeJ^oYmVBIT8YlP<*O|-{rZn?CBZ$!hTQ$l^Ws5#FzzNhtDEk&pjW66v`#lMCQX|yhao3Nh{f=pJggjY%VaS3$6cjpmE8yBj=ab9}L_WhDs!^-_(ajzydy63*iq2RE95bXNS&58Vl$YbMt5tBvfUD80ee2)y+p=LSusMQdxK$2lgn8$s{)|#0(K6g>TN2@HbTKyga@1q&q+#{dAvRIMihveYcA!roDp0%5`vYx6*-FW57ed52meycVux$(D6`4dAjuk61)r~+P(;#5+csFcT?@1_CP!^|PeWO*u)$A(nB@lfoLG6}C@$+rLoY89iB^HrX-28}-L_}XT9)%;n4ljMUb(_mJxd=kNZmr;r*4Z(M)LXkvO4i#Hr9xt8xu}pHRB$LSac;2{E<n_f7_U~-y;~?S;l9DUAqXIHY}VrHN=RQxS|(WKJpO?ti+7ezaiVqHitc&~3q!I3@MwlWgvBN6pfS1zk{r#AwuW_Nk&#kKcqPqiCoY@WJ*lcS!^LfuJFwIuRK>s!>U%h-5(#4NRFN?$%Bba-s#RD}=@pRJo;y&{38>fSXv={|Do7-Mou*#r%KPIV3V53J+UXes(2=7e^)-vPr(@wT;$SXc<><PnV`c$ah#{94tjlygsBwTs1ajbbjRc$0|GOi)5w9Qt=_DAA0y^t55H}Z=?~1v}3_!7C#AQ-ztYTcV5DI6Me?uoazc9?)OCAb}<9f)X6^eK9OQPHxMfAifzY>P@BUj#m7MBo-Gbrqigsw!ntng&dwWA=TBsuYK0y&oIN@U$zYf&$jyanwi7l=ISvK#9DNj#k%9HFA0q^}+A*&aA0iB4;fKj#9+=mQh^<#ocM4Bq1tdva0GH6`#?&?V~>XfVlgI0O_XVk#^Yg3s-WrPM_Ut#UqNlcJv%nYhA94{cPFc*6u|3H6TYb=N^DPKZ%dRCS16hph&LHV>;$$5L8%2Ae+918?0!3gK+0Cj3cKEX`(haX?f08C5llEhnay)tdXK5=Hlt;6@rEwvlhLGl+mDLA0Q~5+QZz1Qs?4tDY?C%xaEJZgMwo7?tr>cE?!4p~A&4bKxSP;aJf82%yc#YHn6=kQ_JtEt{qI&7p6ae%V&6=jWhkDORN-0tZRF*Nv37m3?M2vE&?1%l~HHtW>`V`pQQ2a|VEz?aeEbNG86gl2z)8n!0PMoz+NeRC_h+R~b%|w?LegmnZ8a<qmRxzZ39O+c~){4UKxDLgtEFi)21?Q+eEQ&8Se-ffw6k&db~|-An1LZK^WR!woEb5gMRpOB1$-wn||2V#``D#MGsrMn&0647huQu(~5{$q6#SqDxJ#8=``GhM0D$odRf+W~vJkO^B3=fp1$r9@b5zO(s=h!XX=~n`jipYc)OzDN*;gi&~Gq9fwW}%usA7IL&f4TEyDvOjw2Fm|!0P>pbPMQ%m$zn)=ALK#VdBfSe05ge0p@SENn?R~qyovW^hP0d<0vO(pY+Y=;6ljx!oi+gXZ8Slt&)tIF#ahhM82jQS)C5-McCm@QUeFoNdhuOJvEA+~g4{^=##Qh7Fu$wp!{<!S&gsm(SuSGYVK6-~0JY-Lb{(eiSR0J}Jd0=}C;MtFC5D!e7(#2uvEMQIL(WYJHqMZgwU<c`DnDx;vZUJG#_nO8!nGa^ZPY@L}zHZHGI)dV3bgK!7xNwmcgSU;GA9U*G3$LgVnaaz9piT_rm#yj#>!a*T$xjcYU&IV{>02{K%67tOorgbbR8=jJUkEwBemXj~CEmsewzfSV%uq{POfJ9zWx{FTiiHde&gLs3m8;yIvrnPj54$CWT9Pr%aY?-LfN2;&GfZeM%WKuKI5XU4IK5+<@_Cu7T8y6@qnM%)eT7S3?GcJsIrPUvzoN<I$APcc0JB}%dHS*+GC2x)*s;4{U%`w>_#@!(h#_>#me4*Z?IoPfo%OhwI`m)Tw`eLG9KDe|w2<qgx9utE=-;vIyMvfeu5(nJF^}CH9XynL|%v>~6GQh|4R9!xti|9>RUaPnw*Ov)h5(8|i{b@<Z={&evUDL)SR2WVn!uwixiPB0eE+<*vqTZrf1&Wy~Ej=h4bS~>arw3|cYI0ZfBAV5jHmvO_C8k>SG~X#9XjsijLaB?X@8eU-^34IKDN0I+t`cC>P~S-PLz9m6*-S$2x6GBNBhf=BkA!3x!=x-2%V-0tprpLP7`HhZS>zBv{}$}1^7f&~L|#C!nDAFF%+_i1(5?`=APsO#56FcI7OL?rtt5r!hWjU89(4%XMRo(bvJEPrw0Ce2H6Jj}rxn5uw$P=pMe@{Yj7kyKEU6Z<m&ydRmvavm6W=FdNQ71nspe)0Dr@u9y5W>jVOpSD6$V+-VuutQ$S=%D#ftDo3Au+;OeOXB{O%kf5Ng6Wqy;0?gVhk1T3@~*33kKCvTjMvW<`vm3Y^b7^OlcXuap8?9Vl|X;lWCYUxZlK#aFAEa4rI290YO%*r?`fF96LYzo7+);_G=LD3h*IDln8Pi-V9kQQozx7nWNaO1;{8M_C>+>VC+~AtW5PYy#JOccCQDZ8v62>`)Fm(3fyG#JR`Rj4x2UPU@;aJn+h>N<dWB(Ay!>G?mG}RC$Ya#$POK1eY#3N=SJK=vW3ttTI5MWzx0$^%iPQ52<W{>y!A(nvWq<9D|h~1I5AF8WJNp_*|+natJhD+BbSo^D;*)#4--;bwpCZ1!Roi<g{F>B1dBE>|Ot=M`0{4%U7?x>WC6hN1c@uawRbUC=qQF7lkZPPSN@bnWtpw9DAluPXqjm_6R2Y8}Tg~EcR9G${R(xh2+}HUgktgDVJt3D^|c0V<w{D<s4P@`K}RF9L7{p)C0ODORTcIP8m^1(N|Q1R-$Z|D)o*@EDAwZbF#R6b6cskyvYc!g4{=lyor?mhKd?}@=*=RHwmF@q^)fd*4lZ9<gG5gE!rAnVg!gBRgnm?r+R>KA~OedY#jdK)g)kmD6YAXpmtTp5f3w<6PZ+ACHID2fTAX2lZ(@$L)$B`NnEFBpK6OrIDxyAVs(0{X4{iYVc7|4nvzhg-OI#m+9_~_BOiuFMInDe_Y^m%b0VvY`0vQEQG)Ep>;CZv?r!BuQ@u8ikpGDYR>(-9^vSxyu)8bD<sQb9koQ(T1dM&6nuBcXq{(`=n?n3}mWU#71W`^7o{2?vgOMrks5!;ym1R_m><yt@c7TskhEbt(Lz{7h2D*~W33foQA}qX2FDt#83!9F&fG7Sna2J{)Ee@eHT|HEeZC~Bgd-*u`EXky}u#(8A6*tng^ocr;Ll?JKe{tKw_$x$4c-i!6Om-s)9UMN}Z$HCZkJ1lw_F{v`t+Q`y6f(A{va#t~MXx)MwJ1&n3TwWMmYM{Lo0SAMBAYCywkQ&6i|1K}1>z_zEU0vol3|7NrY%{Ox}GT2&VlB-n}yg6o>5cQ6S1A$K&@sTY;;Z|NWvCjanH}st0I_|lyxjK$pUvYS18XeU0xPV*A%4GA6AVd3w_o*x<MUH0v}=#P^lcf;7tjrE32(lVUV?y3Kf{ANt%zB)UX$~bJAA^mzzmM9yc}k1Y7jZUjMSBudGfp`5HrYpW5iKs;5kTZA)$^%d3Kaa5BowVK3kdME*e*$X09_oxl)dY*0$gS&{Y3B$jo6J^5Uc*AE=%Dse;)lmWqAbR><8^?e8*T#0#gMO{sL;JLYZN=?8D$BMtZu#gHzsRb@FJ1`p9idbSOt&JgnknjUqA{_?o%vE7oexxaNAZDQ^wR~c^O`$A6_ky9#bume{ja{<@o#(x9w5)Jv&l;YS3wd?+k~IftkyKW~^E@%pW*@%LbKg|W$Ix%=K>UKoWJFqnzUEFV-6<BBT%?X?Zexi$3T{(7R2ww8=OCvcQyp2Xp5U<^X@iIx)FkVTnTOk~)JC1NLFxTyJ9rr}+r)#}h)y-yBg{ky>~9W{npVWrpx@g2#wjvL!{Ent>l7!K(m!h(N<5)*&6NZmY)elb7S?>@OKMumg;^G?LCe0^9;Z%=YV_C2J<FA2lj8IsHClG&flxB6N_U~=LDRhr*9K#o38h}U)J=t3!eSEPb4RCUyB7h<hva^{QNzO3G_#h4cxPkcp~J8#Xw{<)y)Tx6hLgY%a5n`Et`!_A!<&fJhvFQXF3SZb+mU3(_)bk!<NFOQ&(uKX&2h^T=2cyBnCqHCfG3Z7jQ1n_y3WN*2>;GO!YAC@uncNx@pOH-$I$QURCJySD84BCb2M^Bad=h@JAV}?t;orISG`D4OetLL6Uk}wi$s3e<_G8q`>tnStwU0{zqUn-oFR6prsTC!FeC$|m1nbNPR+~q;nb<!Jhc&+-6hGNb1?^v;P`ZiJr!Pw_fsuvs8D_B1mq|{)Z2n?FY6859Bl0ivyq1j6O3Gh1X~%{#JprgfCizA>6N@%yIB)~xkxgL5_RY$vY!~?LkNH?h27muE)_5q){WjKh5lnOEZ6JKoE~ddD1dC|OjW!yhv#arA2Ua$sszBtpH&W+LY1qvTR|fgWoBx3>jzgIJt~H1GH3P-miRhz#5)vV8rU~Z`$a=#C64KFK^+~H3ki5bZFO>-M6c<>BZkwt3yz4+LP`4`74Qr_r@*q*u@BOp=B0-^gU_s1A$U^KQ_GGshQ3i2-tTTV64H^W^P(_R9uZJkGzwUyB;lDXp}g_fAS5(DNjKZ9UWg<XbRH->`HQ%Y7Glpe9Jw^9khP|DuNkB<AT1$#prNS@^fH*7aeN3acsnKERJ8Y`J{Ue`7jX{O02_+E*h&E)rT6mDj#`N)0u6NTYxAFfxUwvaTn<tffE8kGSq#yB4xF2yfal%q2Z2B>tq2d8<#Rl=P3fPIe=0f#Tdf1xVWbp&EhNzvC^My2>Lg2>)&o67H0MD*MZ6|(-`E1OBvVHc3}&D9JKxmNb49H+9&gdZSkW-sFsONuHWZqRO9?V}Vzsp(Nn}#9^+gP6v{3WiOZ%i!D-_v5D%Tc$0`<nL5B>ZLw72T+f#>AVN<H)pS6;E+_Np;Nu~*B=RwuzqD>uckiF}i=JcsGy#M|j->4Aoh>ebVPJ^VkidwE&')).decode())
_V56_A887_POLICY = _v51_build_policy(_V56_A887_ROUTE, _V54_CONFIG)
_E032_SWITCH_STEP = 216  # E032: 2700 帯の主流系統 a88722961e の step216 以降 (C9S8 継続) を移植
_V56_CONTINUATION_SHOPS = frozenset(('YARN_STORE', 'PET_CAFE'))


def _v56_visible_configuration(configuration):
    if not isinstance(configuration, dict):
        return configuration
    return {
        key: value
        for key, value in configuration.items()
        if str(key).lower() not in {"seed", "randomseed"}
    }


def _v56_first_shop(obs):
    town = (obs or {}).get("town", {}) or {}
    shops = list(town.get("unlocked_shops", []) or [])
    return str(shops[0]) if shops else ""


# E029: 実戦で我々を破る v56 変種は「2軒目が YARN_STORE なら step144 でヤーンルートへ切替」。
# 両コントローラを常時前進させ、切替条件はいつでも評価できるようにする。
_V56_SECOND_SHOP_SWITCH = frozenset(('YARN_STORE',))


def _v56_use_yarn(obs):
    town = (obs or {}).get("town", {}) or {}
    shops = [str(x) for x in (town.get("unlocked_shops", []) or [])]
    if not shops:
        return False
    if shops[0] in _V56_CONTINUATION_SHOPS:
        return True
    # E029c: 3軒目 (step216) の切替は実戦 4勝16敗で棄却、2軒目のみ
    return any(s in _V56_SECOND_SHOP_SWITCH for s in shops[1:2])


def agent(obs, configuration=None):
    """Route only on the first publicly revealed shop.

    Both controllers are advanced through the hidden-shop opening so their
    public-flow residual state is valid when the branch becomes observable.
    """
    try:
        visible = _v56_visible_configuration(configuration)
        step = int((obs or {}).get("step", 0) or 0)
        if _v56_use_yarn(obs):
            _V56_BACKBONE_POLICY(obs, visible)
            _V56_A887_POLICY(obs, visible)
            return _V56_YARN_POLICY(obs, visible)
        if step >= _E032_SWITCH_STEP:
            _V56_BACKBONE_POLICY(obs, visible)
            _V56_YARN_POLICY(obs, visible)
            return _V56_A887_POLICY(obs, visible)
        default_action = _V56_BACKBONE_POLICY(obs, visible)
        _V56_YARN_POLICY(obs, visible)
        _V56_A887_POLICY(obs, visible)
        return default_action
    except Exception:
        return _v51_safe_action(obs)


def _kaggle_submission_entrypoint(obs, configuration=None):
    act = agent(obs, configuration)
    try:
        return _eager_sell(dict(act), obs)
    except Exception:
        return act


def kaggle_agent_v56(obs, configuration=None):
    """Unique final callable selected by Kaggle's source-file loader.

    ``get_last_callable`` selects by namespace insertion order.  The embedded
    parent artifact already registered ``agent`` and
    ``_kaggle_submission_entrypoint``, so redefining either name does not move
    it to the end of the namespace.  This new name must remain the final
    callable in the generated file.
    """
    act = agent(obs, configuration)
    try:
        return _eager_sell(dict(act), obs)
    except Exception:
        return act


# ===== E022a: 終局スイープ (d29 h18+ のみ) =====================================
# v56 はハンドが抱えた肥料 (8-12個 = $500-1,200) を shed に戻す前にゲームが終わる。
# 最終日の残存価値が尽きた時間帯に限り、在庫持ちユニットを shed へ誘導して DROP、
# shed の売り残しに SELL を追加する。介入は PASS/移動/CARE/WATER/FERTILIZE のみ置換。
_SWEEP_DAY = 29
_SWEEP_HOUR = 18
_SWEEP_PRODUCTS = ("FERTILIZER", "WHEAT", "CARROT", "TOMATO", "STRAWBERRY",
                   "MELON", "EGG", "MILK", "WOOL")
_SWEEP_OVERRIDABLE = ("PASS", "NORTH", "SOUTH", "EAST", "WEST", "CARE", "WATER",
                      "FERTILIZE", "COLLECT_FERTILIZER")
_SWEEP_SHED = ((4, 4), (5, 4), (4, 5), (5, 5))


def _sweep_get(v, k, d=None):
    if isinstance(v, dict):
        return v.get(k, d)
    if hasattr(v, "get"):
        return v.get(k, d)
    return getattr(v, k, d)


def _sweep_move(x, y):
    best = min(_SWEEP_SHED, key=lambda p: abs(x - p[0]) + abs(y - p[1]))
    tx, ty = best
    if x > tx:
        return ["WEST"]
    if x < tx:
        return ["EAST"]
    if y > ty:
        return ["NORTH"]
    if y < ty:
        return ["SOUTH"]
    return None


def _sweep(action, obs):
    step = int(_sweep_get(obs, "step", 0) or 0)
    day, hour = step // 24, step % 24
    if day < _SWEEP_DAY or hour < _SWEEP_HOUR:
        return action
    seat = 1 if int(_sweep_get(obs, "player", 0) or 0) == 1 else 0
    farms = list(_sweep_get(obs, "farms", []) or [])
    farm = farms[seat] if seat < len(farms) else {}
    private = _sweep_get(obs, "private", {}) or {}
    invs = list(_sweep_get(private, "inventories", []) or [])
    shed = _sweep_get(private, "shed", {}) or {}
    positions = [_sweep_get(farm, "farmer")] + list(_sweep_get(farm, "hands", []) or [])
    acts = [list(action.get("farmer") or ["PASS"])] +            [list(h or ["PASS"]) for h in (action.get("hands") or [])]
    while len(acts) < len(positions):
        acts.append(["PASS"])

    for i, pos in enumerate(positions):
        if i >= len(invs) or not pos:
            continue
        inv = invs[i] or {}
        carrying = sum(int(inv.get(p, 0) or 0) for p in _SWEEP_PRODUCTS)
        if carrying <= 0:
            continue
        cur = acts[i][0] if acts[i] else "PASS"
        if cur not in _SWEEP_OVERRIDABLE:
            continue
        x, y = int(pos[0]), int(pos[1])
        if (x, y) in _SWEEP_SHED:
            acts[i] = ["DROP"]
        else:
            mv = _sweep_move(x, y)
            if mv:
                acts[i] = mv

    # E028: 同ステップの DROP は市場処理より先に shed へ入る (engine: 物理→市場)。
    # DROP する unit の手持ちも投影して売る。超過注文は失敗するだけで無害。
    proj = {item: int(shed.get(item, 0) or 0) for item in _SWEEP_PRODUCTS}
    for i, a in enumerate(acts):
        if a and a[0] == "DROP" and i < len(invs):
            for item in _SWEEP_PRODUCTS:
                proj[item] += int((invs[i] or {}).get(item, 0) or 0)

    market = [list(o) for o in (action.get("market") or [])]
    for item in _SWEEP_PRODUCTS:
        n = proj[item]
        if n <= 0:
            continue
        covered = sum(int(o[2]) for o in market
                      if len(o) >= 3 and o[0] == "SELL" and o[1] == item)
        need = n - covered
        if need <= 0:
            continue
        ext = next((o for o in market if len(o) >= 3 and o[0] == "SELL" and o[1] == item), None)
        if ext is not None:
            ext[2] = int(ext[2]) + need
        elif len(market) < 10:
            market.append(["SELL", item, need])

    return {"farmer": acts[0], "hands": acts[1:len(positions)], "market": market[:10]}


_pre_sweep_agent = agent


def _opening_guard(act, obs):
    """E029c: 序盤の注文順を動物優先にする。

    相手が step0 に小麦を買い占めると step1 の小麦価格が上がり、v56 は最後の
    SHEEP を $2 差で買えず農場が崩壊する (実戦 52c59c34e3 系に 0勝12敗)。
    エンジンは注文をリスト順に処理するため BUY_ANIMAL を先頭へ、BUY_PRODUCT を末尾へ。
    """
    if int(_sweep_get(obs, "step", 0) or 0) != 1:
        return act
    inv = (_sweep_get(obs, "market", {}) or {}).get("inventory", {}) or {}
    if int(inv.get("WHEAT", 0) or 0) >= 9990 - _E030_N:
        return act  # 相手の買い占めなし (通常は町消費で 9999、自分の先買い分を差し引く)
    market = list(act.get("market") or [])
    rank = {"BUY_ANIMAL": 0, "BUY_PRODUCT": 2}
    act["market"] = sorted(market, key=lambda o: rank.get(o[0] if o else "", 1))
    return act


_E030_N = 13  # step0 に先買いする小麦数 (5 = 自衛のみ、>5 は step1 に差分を売り戻す)


def _e030_prebuy(act, obs):
    """E030: 開幕小麦の step0 先買い。上位帯 (2800+) は全員が step0 に小麦を買い、
    v56 素の step1 購入は価格上昇で農場崩壊する。先買いで自衛し、余剰は step1 に売る。"""
    step = int(_sweep_get(obs, "step", 0) or 0)
    if _E030_N <= 0 or step > 1:
        return act
    market = [list(o) for o in (act.get("market") or [])]
    if step == 0:
        market = [["BUY_PRODUCT", "WHEAT", _E030_N]] + market
    else:
        market = [o for o in market if not (len(o) >= 2 and o[0] == "BUY_PRODUCT" and o[1] == "WHEAT")]
        if _E030_N > 5:
            market = [["SELL", "WHEAT", _E030_N - 5]] + market
    act["market"] = market[:10]
    return act


def agent(obs, configuration=None):
    act = _pre_sweep_agent(obs, configuration)
    try:
        return _e030_prebuy(_opening_guard(_sweep(dict(act), obs), obs), obs)
    except Exception:
        return act


# ===== E022c: マルチホライズン・セルフオラクル (K=16) ==========================
# ファントム対を K 組並走させ (+1..+K ステップずらしたストリーム)、品目ごとに
# 「いずれかのホライズンで予見された売却の最大値」を先回りする。リアクティブ型は
# 各ファントムが同じ (古い) 在庫を見るため、合計でなく max で二重計上を防ぐ。
# 日跨ぎの予測は状態が不正確なため使わない。
_ORAK_N = 16
_ORAK_BB = [_v51_build_policy(_V56_BACKBONE_ROUTE, _V54_CONFIG) for _ in range(_ORAK_N)]
_ORAK_YARN = [_v51_build_policy(_V56_YARN_ROUTE, _V54_CONFIG) for _ in range(_ORAK_N)]
_ORAK_A887 = [_v51_build_policy(_V56_A887_ROUTE, _V54_CONFIG) for _ in range(_ORAK_N)]
_ORAK_ITEMS = ("MELON", "MILK", "STRAWBERRY", "WOOL")
_ORAK_SHOPS = {
    "BAKERY": ("EGG", "WHEAT"),
    "PIZZA_SHOP": ("MILK", "TOMATO", "WHEAT"),
    "BRUNCH_SPOT": ("EGG", "WHEAT", "STRAWBERRY"),
    "YARN_STORE": ("WOOL",),
    "ICE_CREAM_SHOP": ("STRAWBERRY", "MILK", "WHEAT"),
    "PET_CAFE": ("CARROT",),
    "SMOOTHIE_SHOP": ("STRAWBERRY", "MILK"),
    "FARMERS_MARKET": ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY"),
}


def _orak_get(v, k, d=None):
    if isinstance(v, dict):
        return v.get(k, d)
    if hasattr(v, "get"):
        return v.get(k, d)
    return getattr(v, k, d)


def _orak_phantom(obs, visible, idx):
    step = int(_orak_get(obs, "step", 0) or 0) + idx + 1
    pobs = dict(obs)
    pobs["step"] = step
    pobs["hour"] = step % 24
    pobs["day"] = step // 24
    if _v56_use_yarn(pobs):
        _ORAK_BB[idx](pobs, visible)
        _ORAK_A887[idx](pobs, visible)
        return _ORAK_YARN[idx](pobs, visible)
    if step >= _E032_SWITCH_STEP:
        _ORAK_BB[idx](pobs, visible)
        _ORAK_YARN[idx](pobs, visible)
        return _ORAK_A887[idx](pobs, visible)
    d = _ORAK_BB[idx](pobs, visible)
    _ORAK_YARN[idx](pobs, visible)
    _ORAK_A887[idx](pobs, visible)
    return d


def _orak_town_demand(obs, item, step):
    d = 1 if (item != "FERTILIZER" and step % 24 == 0) else 0
    if step % 4 != 0:
        return d
    for shp in list(_orak_get(_orak_get(obs, "town", {}) or {}, "unlocked_shops", []) or []):
        prods = _ORAK_SHOPS.get(shp, ())
        if item in prods:
            d += 2 if len(prods) == 1 else 1
    return d


def _orak_front_run(action, obs, preds):
    step = int(_orak_get(obs, "step", 0) or 0)
    private = _orak_get(obs, "private", {}) or {}
    shed = _orak_get(private, "shed", {}) or {}
    market = [list(o) for o in (action.get("market") or [])]
    units = [list(action.get("farmer") or ["PASS"])] +             [list(h or ["PASS"]) for h in (action.get("hands") or [])]
    for item, tgt in preds.items():
        if tgt <= 0 or _orak_town_demand(obs, item, step) > 0:
            continue
        stock = max(0, int(shed.get(item, 0) or 0))
        reserve = sum(max(0, int(u[2])) if len(u) >= 3 else 1
                      for u in units
                      if u and len(u) >= 2 and u[0] == "PICKUP" and u[1] == item)
        existing = sum(int(o[2]) for o in market
                       if len(o) >= 3 and o[0] == "SELL" and o[1] == item)
        qty = min(tgt, max(0, stock - reserve - existing))
        if qty <= 0:
            continue
        ext = next((o for o in market if len(o) >= 3 and o[0] == "SELL" and o[1] == item), None)
        if ext is not None:
            ext[2] = int(ext[2]) + qty
        elif len(market) < 10:
            market.append(["SELL", item, qty])
    action["market"] = market[:10]
    return action


_pre_orak_agent = agent

# ===== E031: テープオラクル ==================================================
# 2600-2800 帯の相手の 1/3 は yhay81 Three-Day Shop Router のテープ (開幕 53/48 買い占め、
# 公開位置は決定論的、市場行動は 719 手中 659-718 手が一致)。公開位置で識別し、
# 既知の売却予定 (プレミアム4品目) を K_T 手先まで先回りする (E019b の固定トレース先読みと同型)。
_TAPE_K = 4
_TAPE_POS = {3: [[4, 4], [[4, 4], [5, 4], [4, 4], [4, 5], [4, 4]]], 4: [[4, 4], [[4, 3], [5, 4], [4, 3], [3, 5], [4, 4]]], 5: [[4, 4], [[4, 3], [5, 4], [4, 2], [3, 4], [4, 4]]], 6: [[3, 4], [[4, 3], [5, 4], [4, 1], [3, 3], [4, 4]]], 7: [[3, 3], [[4, 2], [5, 4], [4, 0], [3, 2], [4, 4]]], 8: [[3, 3], [[4, 1], [5, 4], [4, 0], [3, 2], [4, 4]]], 9: [[3, 3], [[4, 1], [5, 4], [4, 0], [3, 2], [3, 4]]], 10: [[3, 3], [[4, 1], [5, 4], [3, 0], [2, 2], [3, 4]]], 11: [[3, 3], [[3, 1], [5, 4], [3, 0], [2, 1], [3, 4]]], 12: [[2, 3], [[3, 1], [5, 4], [3, 0], [2, 1], [3, 4]]]}
_TAPE_SELLS = {150: {'WOOL': 12}, 196: {'MILK': 12}, 226: {'WOOL': 8}, 249: {'MELON': 6}, 250: {'MELON': 24}, 251: {'MELON': 12}, 252: {'MELON': 6}, 253: {'MELON': 6}, 255: {'MELON': 6}, 258: {'MILK': 12}, 264: {'MELON': 12}, 269: {'MILK': 6}, 293: {'WOOL': 8}, 298: {'MILK': 6}, 323: {'MILK': 6}, 338: {'MILK': 6}, 339: {'MILK': 3}, 340: {'MILK': 6}, 341: {'MILK': 3}, 342: {'WOOL': 6}, 343: {'WOOL': 6}, 360: {'MILK': 3}, 375: {'MILK': 15, 'WOOL': 14}, 381: {'STRAWBERRY': 8}, 386: {'MILK': 3}, 397: {'STRAWBERRY': 4}, 400: {'WOOL': 18}, 403: {'STRAWBERRY': 12}, 407: {'MILK': 9}, 409: {'MILK': 3}, 417: {'MILK': 6}, 423: {'WOOL': 10}, 430: {'STRAWBERRY': 10}, 431: {'STRAWBERRY': 6}, 433: {'MILK': 6, 'WOOL': 4}, 440: {'WOOL': 6}, 451: {'STRAWBERRY': 10}, 454: {'STRAWBERRY': 14}, 457: {'WOOL': 6}, 466: {'WOOL': 4}, 470: {'MILK': 9}, 473: {'MILK': 3}, 475: {'STRAWBERRY': 4}, 477: {'STRAWBERRY': 6}, 478: {'STRAWBERRY': 6}, 491: {'MILK': 9, 'WOOL': 4}, 498: {'STRAWBERRY': 10}, 502: {'STRAWBERRY': 14}, 503: {'WOOL': 4}, 505: {'WOOL': 6}, 515: {'MILK': 9}, 517: {'STRAWBERRY': 8, 'MILK': 5}, 523: {'STRAWBERRY': 16, 'WOOL': 6}, 529: {'WOOL': 4}, 539: {'STRAWBERRY': 12, 'MILK': 9}, 541: {'STRAWBERRY': 6}, 542: {'MILK': 3}, 546: {'STRAWBERRY': 10, 'WOOL': 8}, 550: {'STRAWBERRY': 14}, 552: {'WOOL': 11}, 563: {'MILK': 6}, 565: {'MILK': 9}, 570: {'STRAWBERRY': 14}, 576: {'MILK': 27}, 577: {'STRAWBERRY': 1}, 584: {'WOOL': 12}, 586: {'WOOL': 6}, 587: {'STRAWBERRY': 12}, 589: {'STRAWBERRY': 2}, 600: {'WOOL': 3}, 601: {'MILK': 6}, 611: {'STRAWBERRY': 12}, 613: {'STRAWBERRY': 1, 'MILK': 9}, 617: {'STRAWBERRY': 1}, 620: {'WOOL': 3}, 632: {'WOOL': 8}, 634: {'WOOL': 1}, 635: {'STRAWBERRY': 12, 'MILK': 9}, 637: {'STRAWBERRY': 2}, 640: {'WOOL': 9}, 647: {'STRAWBERRY': 2}, 648: {'MILK': 15}, 649: {'STRAWBERRY': 10, 'WOOL': 3}, 650: {'STRAWBERRY': 2}, 654: {'STRAWBERRY': 2}, 656: {'WOOL': 4}, 660: {'WOOL': 8}, 673: {'MILK': 12}, 681: {'MILK': 12}, 685: {'STRAWBERRY': 19}, 688: {'WOOL': 12}, 707: {'MILK': 3}, 711: {'WOOL': 3}, 718: {'MILK': 12, 'STRAWBERRY': 5}}
_tape_state = {"hits": 0, "mode": None, "hits2": 0, "n13": False}
# E033: 第2テープ = 更新版 Three-Day Shop Router (開幕 13/8、v56 本体、step216 から C9S8 継続)。
# 2700 帯の主流系統 (a88722961e)。本体位置は v56 と同一なので「相手の step0 小麦買い 13」を
# 市場在庫 (10000 - 自分の先買い - 町消費 1 - 13) で識別し、位置一致と併せてラッチする。
_TAPE2_POS = {3: [[3, 3], [[4, 4], [4, 4], [4, 4], [4, 5], [4, 4]]], 4: [[2, 3], [[4, 3], [4, 4], [4, 3], [4, 4], [4, 4]]], 5: [[2, 3], [[4, 3], [4, 4], [4, 2], [4, 4], [4, 4]]], 6: [[2, 3], [[4, 3], [3, 4], [4, 1], [4, 4], [4, 4]]], 7: [[1, 3], [[4, 3], [3, 4], [4, 1], [3, 4], [3, 4]]], 8: [[1, 3], [[3, 3], [3, 4], [4, 1], [3, 3], [2, 4]]], 9: [[1, 3], [[3, 2], [3, 4], [3, 1], [3, 3], [1, 4]]], 10: [[2, 3], [[3, 2], [3, 4], [2, 1], [3, 3], [1, 4]]], 11: [[3, 3], [[3, 2], [3, 3], [1, 1], [3, 3], [1, 4]]], 12: [[3, 3], [[2, 2], [3, 2], [0, 1], [3, 3], [0, 4]]]}
_TAPE2_SELLS = {150: {'WOOL': 10}, 168: {'WOOL': 2}, 195: {'MILK': 12}, 226: {'WOOL': 8}, 249: {'MELON': 6}, 250: {'MELON': 24}, 251: {'MELON': 12}, 252: {'MELON': 6}, 253: {'MELON': 6}, 255: {'MELON': 6}, 258: {'MILK': 12}, 264: {'MELON': 12}, 269: {'MILK': 6}, 293: {'WOOL': 8}, 298: {'MILK': 6}, 323: {'MILK': 6}, 338: {'MILK': 6}, 339: {'MILK': 3}, 340: {'MILK': 6}, 341: {'MILK': 3}, 342: {'WOOL': 6}, 343: {'WOOL': 6}, 361: {'WOOL': 1}, 364: {'WOOL': 3}, 365: {'WOOL': 2}, 366: {'WOOL': 2}, 367: {'WOOL': 4}, 369: {'WOOL': 6}, 381: {'MILK': 7}, 382: {'MILK': 5}, 385: {'STRAWBERRY': 8}, 389: {'WOOL': 4}, 393: {'MILK': 8}, 395: {'STRAWBERRY': 4}, 397: {'MILK': 7}, 403: {'STRAWBERRY': 12}, 406: {'WOOL': 14}, 407: {'MILK': 3}, 409: {'WOOL': 4}, 417: {'MILK': 4}, 418: {'WOOL': 6}, 421: {'MILK': 2}, 422: {'MILK': 3}, 427: {'STRAWBERRY': 6}, 429: {'STRAWBERRY': 10}, 431: {'MILK': 3}, 433: {'MILK': 6, 'WOOL': 4}, 438: {'MILK': 3}, 440: {'WOOL': 6}, 451: {'STRAWBERRY': 10}, 454: {'STRAWBERRY': 14}, 457: {'WOOL': 6}, 462: {'MILK': 6}, 463: {'MILK': 3}, 466: {'WOOL': 4}, 472: {'MILK': 9}, 475: {'STRAWBERRY': 4}, 477: {'STRAWBERRY': 6}, 478: {'STRAWBERRY': 6}, 486: {'MILK': 6, 'WOOL': 6}, 487: {'MILK': 6, 'WOOL': 2}, 493: {'MILK': 9, 'WOOL': 4}, 498: {'STRAWBERRY': 10}, 502: {'STRAWBERRY': 14}, 505: {'WOOL': 10}, 510: {'MILK': 6, 'WOOL': 2}, 511: {'MILK': 6}, 517: {'MILK': 9, 'STRAWBERRY': 8}, 523: {'STRAWBERRY': 16}, 525: {'WOOL': 6}, 529: {'WOOL': 4}, 534: {'STRAWBERRY': 6, 'MILK': 6, 'WOOL': 6}, 535: {'STRAWBERRY': 6, 'MILK': 6, 'WOOL': 2}, 536: {'STRAWBERRY': 6}, 541: {'STRAWBERRY': 18, 'MILK': 9}, 546: {'STRAWBERRY': 10}, 548: {'WOOL': 8}, 550: {'STRAWBERRY': 14}, 552: {'WOOL': 11}, 558: {'MILK': 6}, 559: {'MILK': 6}, 560: {'MILK': 3}, 565: {'MILK': 6}, 570: {'STRAWBERRY': 14}, 576: {'MILK': 27}, 582: {'STRAWBERRY': 6, 'WOOL': 6}, 583: {'STRAWBERRY': 6, 'WOOL': 4}, 584: {'STRAWBERRY': 6, 'WOOL': 6}, 585: {'STRAWBERRY': 1, 'WOOL': 2}, 586: {'WOOL': 18}, 589: {'STRAWBERRY': 14}, 600: {'WOOL': 3}, 601: {'MILK': 6}, 606: {'STRAWBERRY': 6, 'MILK': 6}, 607: {'STRAWBERRY': 3, 'MILK': 3}, 613: {'STRAWBERRY': 14}, 614: {'MILK': 9}, 620: {'WOOL': 3}, 630: {'STRAWBERRY': 6, 'MILK': 6, 'WOOL': 6}, 631: {'STRAWBERRY': 6, 'MILK': 3, 'WOOL': 3}, 632: {'STRAWBERRY': 6}, 633: {'STRAWBERRY': 6}, 634: {'WOOL': 9}, 637: {'STRAWBERRY': 14, 'MILK': 9}, 640: {'WOOL': 9}, 648: {'MILK': 15}, 649: {'STRAWBERRY': 10, 'WOOL': 3}, 654: {'STRAWBERRY': 4}, 656: {'WOOL': 4}, 660: {'WOOL': 8}, 669: {'MILK': 3}, 673: {'MILK': 9}, 678: {'STRAWBERRY': 6, 'MILK': 3}, 679: {'STRAWBERRY': 6}, 680: {'STRAWBERRY': 6}, 681: {'STRAWBERRY': 4}, 683: {'MILK': 9}, 684: {'MILK': 3}, 685: {'STRAWBERRY': 22}, 688: {'WOOL': 12}, 707: {'MILK': 3}, 711: {'WOOL': 3}, 712: {'MILK': 3}, 718: {'MILK': 3}}


def _tape_observe(obs):
    step = int(_orak_get(obs, "step", 0) or 0)
    if step == 0:
        _tape_state["hits"] = 0; _tape_state["hits2"] = 0; _tape_state["n13"] = False; _tape_state["mode"] = None
    if step == 1:
        inv = int(((_orak_get(obs, "market", {}) or {}).get("inventory", {}) or {}).get("WHEAT", 0) or 0)
        drop = 10000 - inv - _E030_N  # 町消費 1 + 相手の step0 買い
        _tape_state["n13"] = 10 <= drop <= 16
    if _tape_state["mode"] is not None or step not in _TAPE_POS:
        return
    seat = 1 if int(_orak_get(obs, "player", 0) or 0) == 1 else 0
    farms = list(_orak_get(obs, "farms", []) or [])
    if len(farms) < 2:
        return
    of = farms[1 - seat]
    exp_f, exp_h = _TAPE_POS[step]
    if list(of.get("farmer") or []) == exp_f and [list(h) for h in (of.get("hands") or [])] == exp_h:
        _tape_state["hits"] += 1
    exp_f2, exp_h2 = _TAPE2_POS[step]
    if list(of.get("farmer") or []) == exp_f2 and [list(h) for h in (of.get("hands") or [])] == exp_h2:
        _tape_state["hits2"] += 1
    if step == 3:
        inv = int(((_orak_get(obs, "market", {}) or {}).get("inventory", {}) or {}).get("WHEAT", 0) or 0)
        # step3 の在庫 = 10000 - 町消費(1) - 相手の保持分(13-8=5) - 自分の保持分(_E030_N-25=5) ≈ 9989。
        # 相手 N=13 なら step1 時点で 10000-1-13-_E030_N。ここでは step1 の観測を持たないため
        # step3 では保持分の差で判定できない → n13 は step1 の在庫で判定する (下の分岐)
        pass
    if step == max(_TAPE_POS):
        if _tape_state["hits"] >= 7:
            _tape_state["mode"] = "tape"
        elif _tape_state["hits2"] >= 7 and _tape_state["n13"]:
            _tape_state["mode"] = "tape2"
        else:
            _tape_state["mode"] = "other"


def _tape_preds(step):
    preds = {}
    table = _TAPE2_SELLS if _tape_state["mode"] == "tape2" else _TAPE_SELLS
    for k in range(1, _TAPE_K + 1):
        t = step + k
        if t // 24 != step // 24:
            break
        for item, q in table.get(t, {}).items():
            if q > preds.get(item, 0):
                preds[item] = q
    return preds


def agent(obs, configuration=None):
    act = _pre_orak_agent(obs, configuration)
    try:
        visible = _v56_visible_configuration(configuration)
        step = int(_orak_get(obs, "step", 0) or 0)
        hour = step % 24
        _tape_observe(obs)
        preds = {}
        for idx in range(_ORAK_N):
            ph = _orak_phantom(obs, visible, idx)
            if step < 72 or hour + idx + 1 > 23:
                continue
            local = {}
            for o in (ph.get("market") or []):
                if isinstance(o, (list, tuple)) and len(o) >= 3 and o[0] == "SELL" and o[1] in _ORAK_ITEMS:
                    local[o[1]] = local.get(o[1], 0) + max(0, int(o[2]))
            for item, q in local.items():
                if q > preds.get(item, 0):
                    preds[item] = q
        if _tape_state["mode"] in ("tape", "tape2") and step >= 72:
            preds = _tape_preds(step)
        if preds:
            act = _orak_front_run(dict(act), obs, preds)
    except Exception:
        pass
    return act


_EAGER_ITEMS = ("STRAWBERRY", "MILK", "WOOL", "MELON")
_EAGER_FROM_STEP = 72
# E039: 位相eager。町の消費ティックは h%4==0 (h∈{0,4,8,12,16,20} で在庫減を確認)。
# ティック直後 (h%4∈{1,2}) は在庫が最も薄く価格が最も高い。eager の上乗せ分
# (front-run 本体は orak 層が即時に出すため競りは維持) だけをティック後に寄せる。
# d29 (step>=696) は売れ残り回避のため常時開放。
_EAGER_PHASED = True
_EAGER_OPEN_MOD = (1, 2)
_EAGER_ALWAYS_OPEN_STEP = 696
_EAGER_SHED_CAP_RELIEF = 80


def _eager_sell(act, obs):
    """E035a: 9941 系 (N30 ミラーで 0/8) の市場層を模倣 — プレミアム在庫は毎手すぐ売る (町需要ゲートなし)。"""
    step = int(_sweep_get(obs, "step", 0) or 0)
    if step < _EAGER_FROM_STEP:
        return act
    if _EAGER_PHASED and step < _EAGER_ALWAYS_OPEN_STEP and step % 4 not in _EAGER_OPEN_MOD:
        try:
            shed = _sweep_get(_sweep_get(obs, "private", {}) or {}, "shed", {}) or {}
            if sum(int(v or 0) for v in shed.values()) < _EAGER_SHED_CAP_RELIEF:
                return act
        except Exception:
            return act
    private = _sweep_get(obs, "private", {}) or {}
    shed = _sweep_get(private, "shed", {}) or {}
    market = [list(o) for o in (act.get("market") or [])]
    units = [list(act.get("farmer") or ["PASS"])] + [list(h or ["PASS"]) for h in (act.get("hands") or [])]
    for item in _EAGER_ITEMS:
        stock = int(shed.get(item, 0) or 0)
        reserve = sum(int(u[2]) if len(u) >= 3 else 1 for u in units if u and len(u) >= 2 and u[0] == "PICKUP" and u[1] == item)
        existing = sum(int(o[2]) for o in market if len(o) >= 3 and o[0] == "SELL" and o[1] == item)
        qty = stock - reserve - existing
        if qty <= 0:
            continue
        ext = next((o for o in market if len(o) >= 3 and o[0] == "SELL" and o[1] == item), None)
        if ext is not None:
            ext[2] = int(ext[2]) + qty
        elif len(market) < 10:
            market.append(["SELL", item, qty])
    act["market"] = market[:10]
    return act


# ===== E037: 終盤ニンジン差し替え (d1f058 系=Jesse の模倣) ==========================
# d1f058 (Jesse #2/Bohannn #6) は v56 同一ボディ (farm_mis 32/719) で、終盤 d25-28 の
# 同一スロット植栽だけが小麦→ニンジンに置換 (同位置・同時刻・同ユニットで作物のみ
# 相違を 30+ 箇所確認)。小麦・ニンジンは共に2日作物 (first_yield_day=2) でスロット
# 互換のため、同一スロット差し替えは位置・タイミングを変えない最小介入。
# 種は PLANT の per-crop atomic validation (超過分はその作物だけ全不発) のため、
# その手の差し替え数 <= 保有種数 のときのみ差し替え、足りなければ小麦のまま。
_CARROT_SWAP = True
_CARROT_SWAP_STEPS = (600, 700)  # d25h0〜d28h23
_CARROT_SEED_TARGET = 45
_CARROT_SEED_BUY_STEPS = (590, 600)  # d24h14〜d24h23 に事前購入
# E037b: ニンジン価格ゲート。終盤ニンジン価格は抽選依存 (PET_CAFE/FARMERS_MARKET
# の有無で $36〜$109)。pxC@595 >= 47 のときのみ差し替え (20シード較正で発火10戦
# 全勝 +$16k、非発火10戦は -$5.9k/+0.8k で回避が正解)。小麦 $48 に対する機会費用。
_CARROT_PX_MIN = 47


def _carrot_px(obs):
    try:
        return float(((_sweep_get(obs, "market", {}) or {}).get("prices", {}) or {}).get("CARROT", 0) or 0)
    except Exception:
        return 0.0


def _carrot_swap(act, obs):
    if not _CARROT_SWAP:
        return act
    step = int(_sweep_get(obs, "step", 0) or 0)
    if step < _CARROT_SWAP_STEPS[0] or step >= _CARROT_SWAP_STEPS[1]:
        return act
    if _carrot_px(obs) < _CARROT_PX_MIN:
        return act
    seeds = int((_sweep_get(obs, "private", {}) or {}).get("seeds", {}).get("CARROT", 0) or 0)
    farmer = list(act.get("farmer") or ["PASS"])
    hands = [list(h or ["PASS"]) for h in (act.get("hands") or [])]
    n_swap = sum(1 for u in [farmer] + hands if len(u) >= 2 and u[0] == "PLANT" and u[1] == "WHEAT")
    if n_swap <= 0 or seeds < n_swap:
        return act  # 種不足の手は小麦のまま (全不発を避ける)
    if len(farmer) >= 2 and farmer[0] == "PLANT" and farmer[1] == "WHEAT":
        farmer[1] = "CARROT"
    for h in hands:
        if len(h) >= 2 and h[0] == "PLANT" and h[1] == "WHEAT":
            h[1] = "CARROT"
    act["farmer"] = farmer
    act["hands"] = hands
    return act


def _carrot_seeds(act, obs):
    if not _CARROT_SWAP:
        return act
    step = int(_sweep_get(obs, "step", 0) or 0)
    if step < _CARROT_SEED_BUY_STEPS[0] or step >= _CARROT_SEED_BUY_STEPS[1]:
        return act
    if _carrot_px(obs) < _CARROT_PX_MIN:
        return act
    private = _sweep_get(obs, "private", {}) or {}
    have = int(private.get("seeds", {}).get("CARROT", 0) or 0)
    need = _CARROT_SEED_TARGET - have
    if need <= 0:
        return act
    farms = _sweep_get(obs, "farms", []) or []
    seat = 1 if int(_sweep_get(obs, "player", 0) or 0) == 1 else 0
    money = float((_sweep_get(farms[seat] if seat < len(farms) else {}, "money", 0) or 0))
    if money < need * 20 + 500:
        return act
    market = [list(o) for o in (act.get("market") or [])]
    if len(market) >= 10:
        return act
    market.append(["BUY_SEED", "CARROT", need])
    act["market"] = market[:10]
    return act


# ===== E038: フィードガード (脱走前日の救済) =====================================
# 実戦で再発する C5S4 崩壊 (d9 互角→d12 に4頭脱走、-30〜-43k) の対策。
# 解剖 (ep105772092): d10 に FEED 17回で 8頭未給餌 (重複給餌の誤配分)。
# ユニットは未給餌個体から 0-2歩にいながら PASS/別作業で素通りする。
# 同一体・同手数でも相手は全頭給餌する = 微小な位置ずれが割当を壊す。
# 介入は最小限: 午後に限り、今夜脱走する個体 (consecutive_unfed>=1 かつ
# 未給餌) へ、PASS 中のユニットのみを 1歩寄せる/FEED する。市場は不変。
# v1 は PASS 置換のみ (E018-M7 の教訓: 位置ドリフトを起こさない範囲)。
_FEED_GUARD = True
_FEED_HOUR_MIN = 12


def _feed_g(act, obs):
    if not _FEED_GUARD:
        return act
    try:
        step = int(_sweep_get(obs, "step", 0) or 0)
    except Exception:
        return act
    day, hour = step // 24, step % 24
    if day < 3 or day > 28 or hour < _FEED_HOUR_MIN:
        return act
    try:
        seat = 1 if int(_sweep_get(obs, "player", 0) or 0) == 1 else 0
        farms = list(_sweep_get(obs, "farms", []) or [])
        if seat >= len(farms):
            return act
        farm = farms[seat] or {}
        tiles = _sweep_get(farm, "tiles", []) or []
        if not tiles:
            return act
        private = _sweep_get(obs, "private", {}) or {}
        shed = private.get("shed", {}) or {}
        if int(shed.get("WHEAT", 0) or 0) <= 0:
            return act
# 救済対象: 今夜脱走する個体のみ (consecutive_unfed>=1 かつ未給餌 =
# 昨日も今日も逃すと今夜消える)。健常な夜の未給餌には触らない
# (tier2 はミラーで一貫 -$48 のため廃止)。
        targets = []
        for y, row in enumerate(tiles):
            for x, t in enumerate(list(row or [])):
                if not isinstance(t, dict) or not t.get("animal"):
                    continue
                if t.get("fed_today"):
                    continue
                unfed = int(t.get("consecutive_unfed", 0) or 0)
                if unfed >= 1:
                    targets.append((x, y))
        if not targets:
            return act
        positions = [_sweep_get(farm, "farmer")] + list(_sweep_get(farm, "hands", []) or [])
        farmer = list(act.get("farmer") or ["PASS"])
        hands = [list(h or ["PASS"]) for h in (act.get("hands") or [])]
        acts = [farmer] + hands
        while len(acts) < len(positions):
            acts.append(["PASS"])
        claimed = set()
        for i, pos in enumerate(positions):
            if i >= len(acts) or not pos:
                continue
            cur = acts[i][0] if acts[i] else "PASS"
            if cur != "PASS":
                continue
            ux, uy = int(pos[0]), int(pos[1])
            best = None
            for (tx, ty) in targets:
                if (tx, ty) in claimed:
                    continue
                d = abs(ux - tx) + abs(uy - ty)
                if best is None or d < best[0]:
                    best = (d, tx, ty)
            if best is None:
                continue
            d, tx, ty = best
            if d == 0:
                acts[i] = ["FEED"]
                claimed.add((tx, ty))
            elif d <= 23 - hour:
                # 1歩寄せる (今夜の給餌に間に合う個体のみ。h23は移動不可)
                if ux > tx:
                    acts[i] = ["WEST"]
                elif ux < tx:
                    acts[i] = ["EAST"]
                elif uy > ty:
                    acts[i] = ["NORTH"]
                else:
                    acts[i] = ["SOUTH"]
                claimed.add((tx, ty))
        act["farmer"] = acts[0]
        act["hands"] = acts[1:1 + max(0, len(positions) - 1)]
        return act
    except Exception:
        return act


# ===== E041: SELL を市場リストの先頭へ ==========================================
# エンジン (_process_market) は注文スロット i=0,1,.. の順に両者を処理する。v56 は
# HIRE/BUY を先頭に置き SELL が後ろに来るため、同じ手で売る相手 (2ca32a682f =
# v56 + SELL 先頭) に全単位を先に約定され、同数量でも牛乳・イチゴの実現価格が
# 7% 低かった (ep106219277 d24h2: イチゴ 19個 $7 vs 相手 $39)。
# 非 SELL 注文 (HIRE 等) は必ず残し、SELL は残り枠に詰める (切り詰め対象は元と同じ)。
_SELLS_FIRST = True


def _sells_first(act):
    if not _SELLS_FIRST:
        return act
    market = [list(o) for o in (act.get("market") or [])]
    sells = [o for o in market if o and o[0] == "SELL"]
    others = [o for o in market if not (o and o[0] == "SELL")]
    if not sells or len(others) >= 10:
        return act
    act["market"] = sells[: 10 - len(others)] + others
    return act


# ===== E050: ハイブリッド — YARN 店の無い抽選では step216 から PSR テープに農場を委ねる =====================
# PSR (Public State Router 74.5% = Mengfei Li LB#3 の録画、実戦署名 2ca32a682f) は非ヤーン抽選で我々に
# +5〜10k、ヤーン抽選では我々のヤーンルートが PSR に +12〜14k。我々の農場は PSR と step257 までタイル・
# 位置が同一 (実戦 6 戦で確認) なので、PSR 自身の接ぎ木条件 (前置き同一) を満たす。PSR の公開 NB ソースを
# 名前空間に閉じて実行し、毎手 act() を呼んで分岐状態 (226/360/433) を追従させる。委ねた後は PSR の市場も
# そのまま使う (SELL 先頭化のみ適用)。
_PSR_SOURCE = '"""Kaggriculture agent - route replay with a public-state router.\n\nWHAT THIS IS\n    The season is not invented turn by turn. The agent replays a recorded 720-turn action\n    stream from a strong ladder game, and at three points in the season decides which\n    recorded continuation to follow, using only what the observation already shows.\n\nWHY THE SWITCHES ARE SAFE\n    All four stored tails are byte-identical on every turn before the switch that selects\n    them, so at the moment of a switch the farm, the shed and the cash path are exactly\n    what the new tail was recorded with. Splices that do NOT have this property (taking a\n    six-day block from an unrelated game) were measured and are catastrophic: the farm\n    layout differs, so the tail waters and harvests empty tiles. The prefix guard in\n    _switch_ok is what separates the two cases, and it is enforced at runtime.\n\nTHE THREE DECISIONS (public state only - no seed, no opponent identity, no future shop)\n    t=226 (day  9.4)  a YARN_STORE has unlocked      -> wool-leaning tail\n    t=360 (day 15.0)  carrot price >= 42             -> carrot tail   (only under yarn)\n    t=433 (day 18.0)  milk market inventory >= 10067 -> milk tail     (only under main)\n\nTHE REPAIR LAYER\n    Three adjustments, each of which had to earn its place on 968 panel games:\n      weed_dig   - a unit ordered to do something the engine will ignore, standing on a\n                   weed, digs instead.\n      dead_stock - produce the rest of the route will never sell is sold in a spare market\n                   slot rather than dying in the shed at the buzzer.\n      clamp_sells- a SELL the shed cannot fill is dropped, freeing one of the only 10\n                   market slots a turn has. Worthless on the bare route and worth +7/-0\n                   once dead_stock is competing for those slots.\n    The three together were +19 wins and -0 losses across the 968-game panel. Everything\n    else tried - deferring unaffordable buys, sells-before-buys, hire-last, and the wider\n    no-op recovery that also fed/cared/collected - was neutral or worse and is absent.\n\nMEASURED\n    Panel: I take one seat of a real recorded ladder game and face the other seat\'s real\n    recorded route on that game\'s real seed, both seats of 484 episodes (968 games).\n    Opponents are the recorded play of leaderboard #1/#3/#4/#5 and of the 297 teams they\n    were drawn against. SEARCH and SCREEN were used to fit and to gate; HOLD was read once.\n\n                                    SEARCH   SCREEN     HOLD\n      best single route              65.1%    63.6%    62.0%\n      + public-state router          75.4%    73.5%    70.6%\n      + repair layer  (shipped)      77.0%    74.3%    74.5%\n\n    Against the four top-team routes alone, taking the seat their real opponent held:\n    HOLD 66.3% (108-55), where those real opponents themselves won 29.4%.\n\n    Against LIVE reacting agents on seeds no tape uses (120 games each, both seats), the\n    router is worth about as much as it is on tape:\n      top reacting agent #1     57.5% -> 70.0%\n      top reacting agent #2     73.3% -> 80.0%\n      top reacting agent #3     100.0% -> 100.0%\n      my older submissionv2/8   43.3% -> 56.7%\n    The bare route loses to submissionv2/8; the routed one beats it.\n\n    Rejected by the same measurement, and therefore absent: sells-before-buys (-17 games\n    on HOLD), hire-last (-13), deferring unaffordable buys, and the wider no-op recovery\n    that also fed, cared and collected fertilizer (-4 on HOLD; it overflows the 100-item\n    shed, and overflow is discarded).\n"""\nimport base64\nimport json\nimport zlib\n\nTURNS = 720\nBOARD = 10\nMAX_ORDERS = 10\nSHED_CAP = 100\nPRODUCTS = ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL",\n            "FERTILIZER")\nANIMALS = {"GOOSE": "COOP", "COW": "PASTURE", "SHEEP": "PASTURE"}\nMOVES = {"NORTH": (0, -1), "SOUTH": (0, 1), "EAST": (1, 0), "WEST": (-1, 0)}\nPASS = {"farmer": ["PASS"], "hands": [], "market": []}\n\nMAIN = "7015cc00acfa4922"\nYARN = "dc76e4003029ac51"\nYARN_CARROT = "ab9669b9abfbea4e"\nMILK_GLUT = "a84d06f1d12add7c"\n\n# (turn, feature, threshold, target tail)\nDECISIONS = (\n    (226, "shop_YARN_STORE", 1, YARN),\n    (360, "px_CARROT", 42, YARN_CARROT),\n    (433, "inv_MILK", 10067, MILK_GLUT),\n)\n\n_BLOB = (\n    "eNrtnVtvZNeRrP9LP/cDq3j3myxxbGFkt9CSTmHOgDDausDGmTEG9hgYYOD/fqgmWazaK/LLyFyb3ZLMJ1Ekm7X22uuSGRkZ8b+v"\n    "/vPdn//y6levLk82599+e3Ly7tsf3p1db7evXr/64e//8R+vfvXv//vqh3d//c/v/3r35asvP/nqq1e3r1/96d1fvvvb3TfuvvzP"\n    "d3/9f9//993X//7q19/82x++fPvms28+/frun+9+e/PJ3X83p7e3/3h9+Ed+/+bt17+N/8pXN1988fTPr29f3//hr25uPnv69uXi"\n    "27+7+eLN7+8+bPvj93/7+dubV+4XP/6RT37/+e8++fFDP32ze/V6O3z7q9/e3Hz54w8WT7K7+errwwe5m6DPP/3Xb758+Es//p2H"\n    "X3l66oNvHf8yzcJJ/slPf3//Z++HffzhT1/9+pvPv/jsD3dv9OtvfpwK+vjN44yMb3c5sC+/+OT3X+9fyNEIFx94ONL7v3Y8PvEY"\n    "d3/80xtvvuwB7z75+ubt4iUefox+h2Lkn36STeO2MKrh/d7/+ddyGhdzfjDi+y+e/90+remHuXt6aY8TPG6BlYYl3uDTJ/3Lj+fD"\n    "0ZSM87fqaG4+Gc6E4fXs3yVM2+JfPdvo4tdzNHv3v7XSKB6eX60fMYjFbK2075dXmXpPB/v94WdP2/3w1UUvKt3UT5Mv9rB6MeNr"\n    "yF/w/iwQf3D4Cv707IyNv734nWeYuuGr2al7+KXD9/9+Wlrz9jQ3+z8bT9vBd7JPnJ+t+/HUHur+O3Ky9j/rTNbxv4UZWevvH0zW"\n    "uuMOvqA/u4wzgqA5jXTzFXKzXNhjnJrv0yG2l6GSOO3z4+fhLjr4y/vbSZ1n9z+EvzdeQhBiPf3dMcxb/t03X3xx8+nXf/iXm7df"\n    "f/7F5/93GZvIn2N8ov5F6Rx7jC6ij9yvx6/efLN8C/sr9uAfw10/ZHsPfzK57B9/S491YjxnIogd58J4Pfsz4WmoEI94g9vmQcl+"\n    "TRZzj/QPP11kT8f/xJX22ds3Xx6f+fvdOXN2Hjz1Gkfxyif7uIF+QoP7aU/duqHBP9PgOlHE3F8LTjUOVe5O3gThO/xrJxW47hgK"\n    "PL9NAwWIbfKcclvIXr3AJkX3shBCJMmVSEoEafgX89RpnHJIMa0xjpM8jKeY3mWTKtIWAqzSgFpdsIXhwioWLysdHy1aNb7072Wz"\n    "SYNNH14EjQdh1xiw/PaTt/8nG/E4ofs3JF6VD02MM6uGuh/hKmv16ROOAudFVpzvMoIDe8tWhNdHN4FcEPv5l+9RXhhnunYT30r3"\n    "YD6Po/P6xWGqdpb/7tUfJIw2h2qOyhk8TsoE03UPQYWxcNaNeBbByGkfOSlGHyVkZSYMccIc66bIw5FSwFO4k+wwR321/Oj5LdWL"\n    "VLyLWhymnSCIh314yRh/3b5k1OhFRaSDsOsLcjyYnBuejuJwuFS0qL11MUkwhaXXriJSOXPGsZ28dRELUYzRiuUo8Bo+dvZPC0Ck"\n    "F8acBofT+EkUR8to5tSMZlJs+REtfHpl8dKpPX4af6q1PsYmHpYA2LwMfY+Bm2J9YhHyvBYsHv8Dsje0/0t7wNRC4RuxV+fvmtW3"\n    "I3bM4okKQdn5VFCmYrHjb9/N0ts3qiYxiRA1wiMn/OIdMQMJmR96cpvvFlGPqNB6totX9NXXbz/Z/frm7dt/E888vqanLWrGao3Y"\n    "VjxhKWZz71dxgeR/nXh/8o1MQXfqVnYCMZhUEazU0BYXdxpDFa7s1cIMEaEu143Dja2s+P0qGS7aaXDq6XsBAGPSutzo5JDtogrT"\n    "sBy80xKS8DBaW+d9qWhilXvd+3trvaq5xxAMBPh7E/MPH7SPrwqgkQj6z1cum50BQzG+Gk9vfwoVvfM1K3pj+HbWh9Iwesz37Fi5"\n    "fP6aoSAvdT7ppBJQ2Qf0JN4m2Ov67p38nGrsUvjTxRe2YoCo4s/h8uqUdlJm01q0WQ1ICnCyUr2IpuuJZvQQNBzsAPg2PiHTuJyd"\n    "RpkTYMFOuqn+tH6zKlsqlHjNypZ4hjxCEH9bRLqiaOosGdEQsmxkiBdGrVALfToq0I4W4039idLd3Hrn42YmrHZJMetW9OOg0GK7"\n    "xx1cQ+SlPilmPXIEJ86BbSFOGwPUwjM/E918uZwnSqVOxLcNALvZo3YZ0G00HhoR3O+BxMWvefeDelgc/dNxA+M/TcYvKPvx4PON"\n    "OfbMjR+Z/g58pHxm0RM3fKgiQ9ufagdE4o8f0P+r/8YIbXZv3twtps2Jw9lXTx6yTJLhPOUS+wGUCex0Fj787O7O+yxrtX76y5iR"\n    "Uqw5XlQjFT36nQ6H30udB9LNOBbxCCNStsKAw6aD8bRk0G5ZHXsadrY54CnaUe44rsNTf5xAlXOqSfUQqGW3jlyaY0vP+B1RuI4I"\n    "faXDJV6AR7SHo5KebDGXHUQxHWXNHqIxz9+vyiCiHndZ1gMVt9Uf/ulVStlZ5A59aNiRauOo2w7SJhKBGu09/UyVMY3cHJk7JdSk"\n    "mUZjS0GACJoVMEUleiNuQIfabqyu5Qmzi9cN1bUm2JL/BeNNjVMlVmbY2xzCC4bUwfVtZS2nlSfYZaVatgjlAx6T8yJC2lTr5QW0"\n    "JyOVfxyHfltiLuuvFUkQFB5BNL1dM1EmzKFSNlGxDyfL8jZ3VJQ2BbGkw0/2vxmm78Y/2dW7RcQkGg3ok0wi8Qn7+2D/s/0XYelg"\n    "jXLE06fou2H/i09fZOnAejn7YTyowrzon+lvp7m3CQnNp7dZahXnYsgA9WP0YjUmmDlksQT/ZmLYp+0jiRQJ9oTHJJOISc1rEFnG"\n    "rC3aCgQwzDVPUMmaPpXDw1qsp2QLws3AVZE52t3uxpjm4Mk7DDicC4sN2C71enz7xXbxZsp4B/TcI3JWCFs7bX/Q7+svfLE+KZvv"\n    "LQT6EDVJDeknSkNF+gO4VpuqNIwJ+R/xfCdlODNliGfIINatpt0hsqSnOGn/nTAEelaNrfELgXP4H+lpysbluvXTsl6l71ylLmd+"\n    "JaD4HDhgqgxi5gN93aUawONN8rvPv/jXV68vdFqCnDV9FB//Ub6E9mvn/vcXAsMBfG0UxZaRqSs5TCorFAoJPEogPDmwaKDLp0aF"\n    "XuDzx3K/9zOFpVis6DQSfLGSxEfMD8SdNrtysIy4vFFPK7TYHUlDcq7EgRUoylwmu9zRW5CyZSVMoF5zL3NvITbyCGzZKaVgqy9T"\n    "fp2M15kp5LodWpI/eeO0LnvCH+4MAyx0lLos99ZNpWDn64k4QjoimIvwUFuBtr8g49ZkfTOSwlCRRp6sNY9ULmp62YkArzNtVhCB"\n    "HxUhGYfH7MtqlI/KXeLg9ABnuTdwjayts3Vj4VI8YdMiUmFtMGTXBZKtcpOUNWVLyrEYN2SVCmQKFBSLUqmrtIoOYADzyMtdZ8W1"\n    "8aROQBNdkM6eZx9Xq6KvpwnLsn3MoBufhkl8qq19DwC0ZQO2cVH2Ia06mS5JAQV4/BGEHrYowet+nDRWRsdxPGUno+FMQw1ClCyT"\n    "eqgYUsJ0rIofNGl3dvU1rZe2v6pjrxZFGOv1XDmpdMhXVqjoULIy6Jj5VWTXAqB2QE1Myu+2YsREql6r5WPVQ3yrQpsTBRhi2qhc"\n    "CJPH4waBKyLvX+Vw5P4q+M2bN1/duAj103x4K5SqoA7iexSP4VGueV6tLtd+skmETbu0Aq0LY+HoOajzSgoE1yiMZmLmGHkZ+dGC"\n    "VlKI3+VyH3tG5Gr3F1m1jWx76++JMINL9ojqvAz18hqkFXiz9T3hrcMWeSHhCIrPg8YcP88hGsWYG2ZTh9MC+eFhC5ezDsWokYv0"\n    "kAaNmaHa3M4sxlSvOi86LLAnLSMP+Vlzyqvc54WFSi3RXrN+HuTeq+TXq1hU5TrEbf5mQnZ+CKYSqudpi6Rde7x1oYQ4TzyfJJy7"\n    "X434QsWPoRibu18ploqa9wkROBmXcFXUpfgFV8hhlLBMg0tQR6T3osYc/S7pxCQye37dTCjeYRbI3cRtZUFrhBili18jArCj3kjh"\n    "SSLSwrrACXr04OF9IeZYM3IOfl/vrDM+lM8jdvvTX5YUPjFei+B++A/U98JO5lOV9dCcbM/801sB2mJwam/wIwIsnCGdxiNuthVk"\n    "/v6W1l3P+j1CjDG2xKD0kb9gz1ucwU3Qz/X0zJZsroHuHWptHU8dP2/LElI+pnoScutMD58R/X+YNuPm9l7Xom340zeD7jfuNhC0"\n    "Vc1hSZvQU8yx1gsjspljZixy61AiY7V3sngV9AwceNk7xgVT4jtpzz8VB/XTVt8/yuIRkQCo+iiSB3Opsj26fCzf8PSksMo09c2+"\n    "fQ6nrkRzJ9ZT0qgs5KoJ5TyeDcJ3DOnYEXMa2wSs2Q7mc6xxjebMKYjjuKg7UAgBJ6KFtW6s20Fm9GhqPase7JRKfyQxV6AQtdEN"\n    "EsP3HYW365VhIw6rHRzlGZpJjsAkrZD1wNioSk9xWSMj0qYqK4g2KX7iyKowJaymmB/Y4iaOZ1H3sqcircgRJwFYNOIGUIV2Yzzu"\n    "PFLHjWYjMBs9qfYs/l3GjzENLhZxyIUBV/rV42Do0FYcNfYNTI6JUqrlCiIKW43lH0Ohzf5pe79lyw5JKCxo0p1mkbykSyWX/0q2"\n    "Qahy1ITDU/VoJKKnAl1xE/5KfCCRvaQHE1naiYJzy0SN9LPZhUWMYCQwul02q88yNCGI7CUbL/zTycmGM62QvFC3Ohs9zpw01Npv"\n    "9WJQ343JBmpTZ3KN3ES0MT7y1QIrWVORBWnoA6p3YtVhCjvKekUiJCLkfJHxNHI5JkW3LFAuHGkXu9QfTBa5nLePmoGhrH2yNOi+"\n    "sLQkIlVBb62K0dL9ke3SxYspYTTkronTKxCo8m2x7KEpOgY4QFGx86Wg51/m32w/Av/GEqs4L8AF0B3ido1tzmpFGGq4tLpWGjX9"\n    "hLp8E9btG+0n1LuZ3vt2gOC8LhS7PysK8S//sc3m4f7rBYW+onxGOu7YSlJoMJBLeVxNy721Tan5souzc7Pba6vAnQamQdlUIltY"\n    "+KYyapDfIqrwtPHYwfKRUUodv4NsBBcdG8dn0MgYjCGP9zYb2V6LduCOjUI9Me9kaNh1ACT5gsXTzmnxGe+itVARojnbb1C0c1qa"\n    "Ar57F1bZeriBPk5aHmMZYqdFsx2l/MrsAaYomOvR4aRntQBGkJrPWMim0rzCB1vClPYyEpUdZJ50xOkFTyEZVWGVx+Xrho4kdWWM"\n    "KWJe5F+tbj/bbWF2es347W7OdQn+8iPnh5N9CkY9vjrMEWa0WJ+QJuZnhGl5Jm5iFFwJqd7rGsOKUwr1asxkoFkxV1h7GsC5FNi5"\n    "6yauN6ZMwjjya/bxUylAS9oBWNgsCfiCTICqa8Kc2e5fS2cRQfDxdMO5q5tw01ILYZlMe2AdJVbd8CMoBiXZ7kruWhEsgeCcSDYF"\n    "HCPHLFxhPy9bzRquYnJzSexPIajipqB434jBSxJrVBHF9vFx/RWmJnVO8T3vx0PbB84KMzeuNxYO7TnG39SlGGCVAegsbzHSVEvP"\n    "OVhaKONCl9ZYlXv+NYYKLYovExO/0TfWzjjRjiCPEuzi9lQGyJGhqgUbyaDh1Ol5F9TKka2c+DHRihQNs6Lk9bMXJUXAKyGukPN9"\n    "ntkm+t3cKgk/AXn4Eg1fCtVj3oCM56TBeq5AkFDBxREUDUc0lL4fxOnih0PBCx7gtIIIlFINirLH7r6l38DcnIOgoe4djGdzxEOg"\n    "PSeY0/3U1GxENUXvoNR7EWSygl44dOosyrsXBsmO7L8OBgSTv3MXjfr5eqhDYcnezEjgRe9dbXSUU1fQu3jAcWW2a26UoIimDBKD"\n    "gkVYwLVMvE1LV3zA5VaQdiDj34NYuWFZnC28zAfBa4soecTZK4+05FMmhNxaU1oolLyINMzPE0MYbPqcw6xGEzhMhnZxmbWwaNoL"\n    "MVy2ytILdQkz4fkwe2wyDUgqPjGt8+Gvns879BXjUrSAYCK8hO7ilin8mMNjg3+MixUZYK7GfWFFktLnFLlXfJhciHYzdoHiuzyB"\n    "68Ztk251m82tk/CfF2q6sVrLuXPRRTl3ks899aDf/OY3D3RQkYxfxBNjJuXUwSUefdClBOxSymdBubJ5ZQrc7emcM19tovTVloml"\n    "4qWEdkl3CbnCJq9nkTCezSW5PoIvDmy9Ko4fbbsCUUmtuMPHNEaP/r5ixJXwC7j0ihI+hq2cXSVrPKeM20skru8YYmKvsV16yQZd"\n    "J060W8PE4hWIyWef/yahBSNy89rTSgKzkgNsq7S6raDO69juFvohP/V86XRh2KnKuckPrGZqUgV/2JWzneO3ni1leftU2ombNVj9"\n    "ogyYx2tSdltmlwnJpXnKwbw4TPqaKGG0HZtEXRSH8WosnWYxP6FC2gDiEQBSd2E2PFHK0lVyux1+U7iRdXRfLElojxRKYgiyuNWD"\n    "InQY6FGqrJursHniEhQxCMVYOb5Z0+HQv9MrNwIgiZkUbFr5l2hEq7efkY7KLH904OKqEOfJjBBK+gU0I8jz4Qi6PghcDxXurpYQ"\n    "RhThLvgEHQwD5ko9UPj0mJ7IDlS0Sr6pmxhRx3YBcwcd9+VhXqU7E685lMaP20Djmsv0xPkNj91LfbVJ5UNWXpXEouzdNGx1IIZj"\n    "0fAPvjhMT/xuf60PDtF31phGPSZOS29XF6aAMhVKbmXEqi7PnKlNaLABa+kZZrGrBJc468oyeXCaXJrqiujJ4FjLmT3+2zU3whFy"\n    "aHBeAJdriHoWMiGkH1QgV1YbS4ze5RTLbEyUDTPvlghQLiHWxuFGi9jqyMHVawEkJaVI2WmSWgMT9SFyjSxN7AS8ieBOIVPprAcQ"\n    "lXATzLSlwDln1XG5EOtHipvX72k1HBDFYDG81vSaAQF0U1V0XVDY0YBGK5iTTZ+sNHmhliZ2Sd0YBC0WR17yf+/rKT9qZpWb05Pr"\n    "GFFm5HgkjmUZo5L16z8AOnHdJMiPq07ZYQYtGRO69SM08R6CuAqLbDNOjRbZI+nIIEfp3QS4SsUz3k2Ij1SNFrcVXgRhIAm9FaIj"\n    "W2zvdqLp2wth+MLxIvxSLQvxEh8FYXi7UNNpKp2NYJbjr5hE5rbFWd6HrWAw0rOi6hIJprUAMt8efdzlcr4rSmmcYaCJLIMPkqe/"\n    "TO8PGBbHi6EhklYqL2VMGmK16TTTD9pM/Y2u6AUVY9WWJ4pBJAq6hsBLogJyODf6mMiWeUXrIosvqYuIk7uSXEJPQ9zrF0J72YSL"\n    "5hdq4fDdxbhORJUZgZ8p9kuDQM6UBpByiFtDagPMar9ikY7zW8tOJ1VZh7zvMO2/yFgCFIvr1JuvsOMPLzDfxLmIfYuazCqcBM2d"\n    "JDGdE18egr+iohHpLmks5+S2vdOy6GdUiVBqOHZhqdPAkdAiEF/Yk4cyyYj9L6Yj9IX6PoZGwiimoqoNNynCkMhKS8y0hEHcSxaG"\n    "VN/3sMTWwGM0E+Ks4pLlnebLpzvrwwJmqIHZKd6M0Hsidq36U0vRgAk2BHARMQLP+B2CgSJPsVUufNQfinrBM65oqgVx2gZi1VWT"\n    "xSO+l2tU3mvUTSV1I+9HIZCRxI5stbv9kcQCbWruk863bF3z6bxt9i+ZM88JizIdzxQAj9gLDa5Npmhz/AmJlF+BYFIpVfPkMuwl"\n    "lR/srjJ5btamfAwZLHUA6N8oLXeNXOdzPsq16RVISTaRl4k4HW5MCtkX3M4inRkb1+I9YJc3xUIqkPd2yCTh49KJWkgtedIfkOAE"\n    "YrH62KO8w2rD9eU9yezI5EsaOvMXed6xu8Em54DWps5sS9LACajHI8PiCI1R8RIU8FxRko2nFS0NEJ2xAP9gwZhR9/eG/AWQdF4R"\n    "GE768Le1qNZPPeKZqvLZxuV0lp2OI8YJ1ihV2+zFUNINNIpl8HpqGyBjZjOpv/ExgBpDfoPyZbtJpUJjmAVwrtbDa0h9I+1pTMpq"\n    "AMu0LmfcbAKDDiVDVHEtlXrsAkjYU4r1yRqUbA3cDJKDjtRWDzE+IrsJ+m8AVTcycTquccJyrqRRmHCDVGeUb2omBAm1tbUI2MwY"\n    "2EU2vaGUsnY8s7IsqVe8DwVkJiIxWicLgCN06wzbwiYp+V1Ud6xvR8Cj06jXq9gHa1utWlWSSeA3n0eXYz5FNzi5GjMIWokA3vjS"\n    "f6FyYBu785eIhN0S2MmHpbNlYomwYP15lAaD+KS1JHxiBMicZt0IN/UVIM4LsQ4rgrt+062nHtQGZeSiURi31sC6cRRP8mJNR9Vn"\n    "1OAemhEhjtenj6fx3O1ZHAUdqOmQe+lAG/bgL0iuVsf8IqQK2RoZ5P3TuITcHjykF4nnjA0lY3GlYGZ8cCMpkFQhvspzau5MLHmq"\n    "9w1iOwVrkZ8kY4YC2wikSZEYTva3dShma0Mx75kzmxWpMxalyHhOiv4dxyeJbpXQfuTgmhKMcID7jUkZJh+VScYoL/NYyM5tZ/Am"\n    "OJM2lPty3kFhU2ecNu7U0Z0xOaeunl1OzCoV6mMehFv0IzzJVCROw9BxI2LDgYgpKhDTo9pohfid7cdAs8eQldTrfxaAospb0484"\n    "rMxSwI+0oQyROPicNYrh40GeFc3HS8dVAvYZNAo+D7p6sqI3ITT1yrej1tFrnunq+MxL/oXoHVPzOPHiQ35GMiYDf4tqANTbXNEs"\n    "GFczWnNg+5NvnxxqWLZXdcowuXE6TPJO9IkF25iymILCaihReIByHP12E4fUtcs7lOPKVgWLpBVNilYEaogrXAMz8FpKSxsd1Bx5"\n    "NiNUphBxYpk7PJdWRI+9LSl3tUGA0Zp7kZTmaBqbxUS8h+NWp7ZGysdAXHKNlLPcosSET2I4wkl4memyTqvSpnKaonYggCjwHf82"\n    "Y+0JkbaZVoaYKPvDA5FqI5At6HVUR+6LPJigylqMFlZIix+u2ZCcJGbIQA8VdCnxXHMtQ/yoPNVB3WTKAqeypAukSuf2taTzynoZ"\n    "vjhO4tAex2O7vMtpdkXrGz6S+E2Kk/Cg8ytahngqfPQU7+d0lMsaIk7psMAX6eR0voQQKjFc5dKTAg3y2hQIpD0eg7OGxpnNecaZ"\n    "YzFKftVOcvE+WDtCId4sfuT6fLSDKGIZeTleQ5+p1DoDFsJB3lsg4CIB2VQOHfSOI2fIzWlt1XeuQ/eHtmuMp8gn8+yLRKyIOjg8"\n    "ZcawMJAn2BcVu9snhtowZDRporcibuAScyarrwozWeJCB3ZgPakqdpjJFFEyZgyrIYHR+3Kd1ZhKsUtv4nVzsFYyeG78S79IPZhY"\n    "/cVltxBebjYTHR0Hh7DKA/ayHbCXo2+hCXDkoLO2gMwifmDpHBaRsAkxJbjbs8LBE510Wws9EETKgVZHW6siyw4wVF+JIbDkhXMv"\n    "Ka6HzBR4keOW0DHW76YUCWN2BLv7EgKdLmqSHkIb6Q4XJ+AsjeG7V25MfKHfs1xWUMcokVd7xSXVr2u3x/hMOVMTMIcUU0dKg4q/"\n    "qcnvBCdGsqidoiQ2MrqNmBe3fjZIzRkqbiCJZx2mZ0ufp7rbxpptH/POskSRA2MZcg8m8ZIdA+d7e26Xa1aoDJuqUxRQUiaRDk1k"\n    "s9M8AbBD4gOSjb8m2S4B8B+r/+q2PHCJXoVJCe8u3ZkO9QX975KM1zoXmQmDsgVY26dejMcduhS8WJEGIwYCcAvl+eM/K7TiEe1F"\n    "OeHGMAv2wI6/no+szXERU2tjL8ryzv23K5NcwJAYvsgwt/BfrIK4HEMJodHuWWTu86F5L+cVtZcSk+W+K+gkmIFt+QGn+ocECI0K"\n    "rukMUNu4Y3zvefOMh5Mjro+3fm+46zihuya2iaNeSpRdxQSJbQZt/XF8AqjAl27VxJSpRY4fu1ogmC9dsATnaTKuPsiHQIAj/fUg"\n    "AGN5Z110FmmUn7CipUJYMhaqW+JoWIJcbX0j109P1BjWiiRrjQWdZLhgalJvDfk4C5xHTvQehnAXx8663ikeKJ830BvZXw/JlZ9L"\n    "qxZvKZOpk65vVa+BGUg4ahm+68lGRibT6dKGNjd2FYXQL/S3WYmcyCbZFdc3B3nezZRQWEVl2YOx3+0lgI0wcqnNaaahlDeYIQjj"\n    "zApEkT2Bmboo3EFP+a3TuSeodmMijZ576VB7dw1l/57nr+Hc0+8Cbui6GNhF9FdrQkbMT+Fv1hCWdHTDHZ3vymsNjVx+UFncixw0"\n    "YXzAlFhB8TMHZbknqFwOLJbrartQi6Eyrr2xkgiNQCh1kYrvFn3/htogKdLZJiuNwQUaaUU9hrDdbHzQgB5AXIA5wdkowshFYvxs"\n    "03wbbsH5usK+4q/E8o56yzgCrq8hUlQZfxZgFMd6qlcOPQgD9Yc/U6Ddii1Kwr4i85GC/XHGWuvxa1fxZxUZM0ZAmJTVV1KEyMmT"\n    "JCAiJfBeT5mZ7hzpUwOpqyOkOyG+HHeHjpejakNw7HMpyG/LXPvSi4UuKs8MqdaJg2LnpRbcIRHVa7aCBfUsnYO9lNsgHzyEN8E9"\n    "++RhCStqaDlZRr0XR0CmtY6Ns9kyJvN5tAaidW3clLsZ3Qr03FGpcl38iXhjmg4pgJYREyaz1BWWC/gbUAu2tzJackNWkJTbghEG"\n    "P0IOA/PReeN+n1KlMVzomRBWYrBTO1rFobOiD5FkcJQFXnInXpOichlRVM41DrO5/MgcldwneZu3yC6yk9ODSTgEoy6XKMrFLJ0l"\n    "Rle2BYM7kcMnosACiw+0ckMEJoXuyrWY8Zwl7yQ6/U194Ma+Us33oOc2Hs++004htxjXRnquTrspuYPv+SJiMJIXEt3BeRKg9sIl"\n    "F0yz90BUdycyS1JqkywK9IC8+6dv33QagRvrM23rGVkW4/XOpKWOCF5l6bUUeQ/mGB7M2lTuqnUCJVzGcUtHJQyn9BLJ1BnNZySL"\n    "q0ledx27bYOudkPUXdNcvJkHnITCmHawpo6usg5qtuoMS7IkJX7pyaFlFvRghATaXQerNNXn6MLULm8rfu8slEKxdt3JGY/LQsgT"\n    "2nRNd0Sxoh2emQzhV/TVG9tLFIZEkp1Y/R2Xik4nZMOSHSXuhXGMDDYWSprqYnJ3U50GEmusigevzmuiTNKhe4xfrNk5M/jePKeG"\n    "SQpb+lKvpzn9A8rUDemSI7mpgPRxFcAVZxMckONX8nAc/yiR4p/qx6UNZoFIYfGYvIYmRulh7slpcZO/iFILaqYzkAlHewXltuXd"\n    "UO+n4TNejJ1qrBE4HZjzvP+UVeQUI90mLJck1tDUOFSfZ094h5kEKOwcV4smDXlyP8QMhyh5Fo+1pjoUaFPLM5qE2RShnj5e5d4z"\n    "VFjnPu1K/hjX0DrLH5vfTaVTFTUeJhng6t3JJ4Fjjm8ekl+5O7J69jKda2wHaE71dA+z67Vn0dLjmyPxVCVqoJtWgko9jRUSlkKs"\n    "zDlY5nvxdjojvDZ6HToqUBWiIbVK0AayOBHqaKafPVdndQLqZQQ83I8tnpCSFAAs1vstKgX20FwTqUtkyLAdxd9rTlMPGTsqaahU"\n    "SXU9zx0BH7kzSLRo1GBOz9JpzAPRmVkvnGMqxtWza7OymRBZ4VxEMcji9y69FoPjaajRJFwAQpxKkimS2urKBepYsjyLG8gYbzjN"\n    "nYWhzVmAVDiVA+k27mFe3eXj8bPjMWAQXpZpZEF4xc85C7V/F2XcgwGKb+EVR7owLAt/PNI8LxvXNl6lqW2mYvz4V+1xmHpWWu22"\n    "70dS1ntcea4F3iLQNfSi003gnBzQrB1CN00lkv0aWW5OELtQUXYrvNkZx/EKO46Dbt5zj7fW5e20EZnnrRTZHC77w7zUstMSlmxB"\n    "8aaR/JHZH82ZC2UW6EQQUKeBRw3U4VDlSB7bYJIsUszsrOqI//KL958pIt6VHx233pQFMdIgCclcZUWoUoDaJqggnwCqk4tCNGlQ"\n    "Q0vK3W9hjDh1CfN3DB8eNx2xLtJ7FUOuhIrgcUHEr1eoM/4GT95TYVthPt/L0UDRddQncbtFvJA7kjwS48R/f/rsOMNjiHAPbJwm"\n    "5m7wRUSOLjQlbNnh5el4pD6YKZkMFJd0ZoE6HxpuLc86HoUCtqSw6iwAvKmAUlJEtmNkMvs8HNYiCJuYLo//mHSgDIFpSvUi8JVn"\n    "w1eEe0r/fPHmlBeX2LxigyTXixo6NbiAsokaI4gQuFyHSEhhDdYnW327x9fKj8e4TcSVMQsxzEPdP0Lwyx1wWFnOanWpiZ9VNq12"\n    "v2ULwRxLVvufrpTa0ygF0Uq091Xm1SVpmeShOAiemFPUVD3GhTbbgiYwKOvV55Y0KbUFSaWmvvM6wds7zn8F2fg5CxHvA3QDV6Fm"\n    "PS6Qx5D7MsVAdihaiE328bCfPr449XJjdmUOUs3HVVaTLcuAkY+11P0FlI6xYMLuFPPJ8iZvYHBnsC2nWXwyTO3TBZAV3ie/iLPi"\n    "0bkokjBU9fqBARD3YBR/smE1xdixtvhvNjC25JhaNHUcG9Q+9Iuc5LegA7xQ0l046fq6uoQxNMSOOrAp+nREFibagJOqVysxGtg4"\n    "1++Q9CmKNWPJw//Lqnkl18TJV5swlEVKqPskHDmJrtQ7+5k0ZrpV2QjSEOFvm7mci21UV+kKnj/cjPL10jNV61H605xRELLa5D1l"\n    "WJH8+Ggmq+ucTwY2udipKnnQJtghJCM4bMr2DWOaWMa0e629HGitItpRW9qM2SQoqBzQxHHZ9k4O5qlQ7cXVpMzBsjiFUl5nSaUT"\n    "RHSCLJYp6BAR7/+J5Pn2zZepLrbLdFnExte3hRHtB7JPqPbfUft//0NrRA8A8GFkfg+DiVLjUUnyPqQPio8DT/RhUAePNz7V+MX+"\n    "d2AK7r+AZzsfnk2VUc8upfGAo7hOqertP+7+77/f/fk/fvzB/77606tfvfru28uL789OTk5Pttfvvj3f3P35/3r31+//cvfrry5P"\n    "Nufffnty8u7bH96dXW+3dz97d/f97fbi9au//f2HH/78P+//jKexyuUxk+y3JM0hL25IpPf+3A8/+eT3n//uk/eV7t/e3Hzptnma"\n    "7b3okGRnCUtlDORVBqIfBeoisDrCyayIrbryH+P9Mn7hWwD7rerIyMI1iu697ZnD0ErwvcWdMFviFa7pZiNyyiZqYuKwJx7PhwG0"\n    "SvYIchCWjK1GLQXebH1PeOuwFZAtO3s2focsbNC6vxE6avkVpxBTZ2LYa28dilEfcXv1ShSAPyZVzsiHDzl+opPayAND8uChzmem"\n    "HKM0oq129JVKS3K4M0Jm8GG/37PSAYEj3cSirZjcEGhWwdSWCxmnhaerPEJbPso41aOA8rz1LPWvxhbLitptMTZ3v1Kacmre5eUp"\n    "p9MLw12poKTp3PGgPiZzt5G7jPLTaUAViUZpfDaeQS5cwoenC5xbI8QoXTE7HKf0ZniS9LJy3SOO/e4JejdfvPn9Q9P4Yo41wnDw"\n    "+3pnnfGhfB4y0Pd/Wc2BGq+Yl9HT9vAfqO+F3gSnKuuhOdme+ac3cG4OB8f6depfqGLPYJGCUhP0iBuLPPQ4kfe39NCPBu8RYgyy"\n    "MzJGfuG/G0t6YbN4rPGZWXYgN1gcnneYOn7envKLekz1JL/+5vMvPvvDXYj79Tdv42JU9mzLaTNubu917R/tfpyfvnnATofWWL3b"\n    "QLVauWklxp9PMcdaL4x6OAreOq/R6M6Pprx3Mi4ZbEXB2MveNC6ecn5bYbDvRSD2u33/KONTim48FE7Lno0eSbRNHT7lSc46HNfB"\n    "+LCWcbkWGEzuoMXs1dh+Y5Yw5vKu4R3CnccTQkDPaT7hwpYcGhdpKydN2IsvaNjGOgE97aZC9WjIkwrEitnsqUjZXE+kgNZxZk90"\n    "ah98BY2Pm8AAbBMpMC2+f9iFeb0yfsTxdVtfe0BN+izYu4X82au4Xsdc2dtSfWPQRDmYefi2CTuR6Nfypkon9QRqm35CzRiJkLUY"\n    "JCPSqWiwIAnuGhMOoRdAGp/94txxyHERmeUuJW4WM+Sk/urfdUzFqNvh8Sly3NIvIwdDd9sIxzSUt4VZU7X853egLeMv/xgTnRVy"\n    "yvZbtuxQLIwcPfrTzKYjtVWersGUBtnExXPdz7C/VQr9LJ7X1cL23oFqhoy14MODaRR+Evk1t5t16NE7atFEDsboh5Cuo+eaZcta"\n    "yx4v/NPJyYYzrZC8jP8k8W5aY/6RYCuOGmZGm5lvgeXKMWbaNhhsT7DSpgU2qaBOoueIV4kx+S00hZomBLfISPBNBSuu4C2Bb6B8"\n    "CyGrWJ1PvP6SRSNRlOQ6EJ7ipfvC8ureW1W11qoYLd0f2S5dvJgSRqNKMSPuQnIpaaOrA5OltBexDIpWa61fX5OIs/0IRBw2OGP6"\n    "CVuOh81NOfJyVqvG1NyYdzf1UHvctQmH+SYs4DssnoJP7qxGce11VVSUjYDh+B/btJ6CSPJVSYstrFbpRRZzTOaF36VSPXL0e6qM"\n    "M2urQKIGysHqyu74pjKOUD5jhKeNxw6Wj4ya6vidXIbKQMfG8Rl8MgZjyqJIDi3ZXot24O5IA66iYuq1HwBbvqAjt3N6fca7aC1U"\n    "hPjO9hsc0YUY86sZYWdNPLbELHtnl2bMPdYSmTIwylZ57hTXVlDYo8PpOQSWxR05fsQ4RhCyLm5zdxmJyo5jiFRKI21VIkpq6pJK"\n    "edcfaDmVFK8sDaypuv1s24XZ8jXjf70JDLAvP3J+ONmwYNTjq8MkW2Sn18Tiqc16HMccU04ZO/T4AmwZY/OV/LEzSAjAnQDO5cLO"\n    "XTemQ6kK7uLIr9jzC6GRdBoRMWToY7t6/uUg/Zowly7a9P7B/kA1RBtPp5pRZamJEdJSQ/F1EiFwGvTDPDZpOlY+nIJxatX8stzV"\n    "Pto4OCeSTV0vbbayY2erWedVTHHu2aByHZTifSMG71mfipWFfeTj+ltRALmgnjoe2j5wVpi5qn10S1Rjd1PXZIBVBqCzvMVIyTXX"\n    "CY+XFuq50KU1VuWef42hVIviy8TEb8O33sg40Q4qjxLs4vZUBmh6O1CWGhogNVNR06hopZw40K+1i5LXz16UdBVhQ873eaoebrd1"\n    "qyT8xHYmzrPpZcyV5A22GUjiWVcvECRUcHEE5fKagyvU0Q+Hghc8wGkFESilGpbfgniN1NzszrlI89jtNp7NEQ+B9pxgTgPhSn/m"\n    "hh7T+5rsRZDJCnrh0KmzKO9eGCQ7hReIAcHk2wLU81LYlAoWlmyuglAXLJUbPSa/hYLJwwOOK7Ndc6MERTRlkCoULMICrmXibVrD"\n    "4gMut4LGQ6BuuIyVbwKZiYmFl6nQem0Rz2NKKyMWt4OEHEN7UAMlLyIN8/PEEAabPucwq9EEDpOhXVxmLSya9kIMl62y9EKBwsx1"\n    "Kcwem0wD6YCC4jcZcVXAXz0Hd+grxqVoAcFEeInSaSowq9SYIAsDFysywJKLx6ejq6rzyuTeZm+2OXQntXZLuweRetRW/YGLuoMc"\n    "YkInvOnJdR9+zKXRO2366lIH4ggWjFKTYe55XvtmLunXbKMcOyvEuxiVGI7OYeaRTg0PxeUFASwWXB2jp2o4oQ0sMNiqaTGMh2xh"\n    "FhMdwNy7pFB3GOsfs7Nro1ACwfKFjaguvbxOzQ6BaDYhTIZlS/tytk0NcafmipVSOdGjN1dE6Hdz4/YNGrqQfa6CIgFReWtctmk6"\n    "7CKvC2kVo8HkcD4fTbgDh5NwzSI+02t3xkTncMzQ19VfyMD+afe2toRWyRyhN8hsDVCYIe7dUeHvXsXrnIwp7nU2DS2w0Q1kPJOt"\n    "A4924biedznW0zXyoT/dXLj0kB0qU+6w5itOoHR7oQcMW4PFnCZmj8hEmXvVjMZBKDCux6yfyCZfHWpkXQWjzWzUhcKZq3gjewQg"\n    "/DoebmUluK0THYG0jFfQwnkt1paFPRgk9MKt8PHr9YR7pJrfZosnJ9+Gey5U8EuuxRWJ5Sd4x6TDI0gR/p0xlg+57pVyL0nbwBfj"\n    "m4WGs9ZRTgMbi3qpf6rdkNYS9uBOdcolfXYyEq8qOZMI0OofnbkIYtcDqm07U+uaPVBH94G+r46v5jr7ROXN70z27/TQXrLpD5AE"\n    "OwW7aVYortV4MK4z+wfQIFRiWDINswpBrWjZbFJP+syrvYaItauA9QxMwMO6W+rdmq74m4KShoxcjUTV0qbC0mYJywDRsRLDOv34"\n    "xDUFnVmDbVDoLh6p2Dv4ZATvxuQMgb15VjbxJxYYylW4maEW4jqSL1GXq9sCHYn8ZEj4r4Z6TKeZD9Huxe2KCz7pmheLLci7fX7O"\n    "uNyZ1zxKwR8cWvc63WPgS905aiuZ2f3oyZJtEABQHtHr5B2MPgssxtjoRrck/6SkaKbgDq3+Uw0MPmFBr1cpG5HBKZaDqD906Thw"\n    "kDNfl9kb3uQuUt7rfnP+x8BZQPUee1qjlg+7bz+H/6+fk8TBfR5NBobHXukxIkZqACZ6pFKXUjcKyLwlbU3U06QWMt5bdaU/R24y"\n    "tbCxHbELRlnEG29CFTwOJFmYjJZKn7KFqo2h7nESkLSHG1dOJd9JACAIrt06BPTsUkxeqHv2K98zbeSiYcnjimZNTCiniMvczCbl"\n    "yVMiNCWrhigfNBhbgjvqjajtTc4i5Trho8LQMllbLDwDdCIgLt09KEPRo2Z55fGsIwXEx2gjVydeQm9B9919MUz7j9l9C27cvf/I"\n    "wnwD6eN4gZDIjXq+4+aIthlybXHj0kzJZf2JDxAUsn/0el8TBBElwTv1COwrNWT1cly9kOPS+ECfEATvanITPaV+t/I5jlfhH9Cl"\n    "MmINRQrMj4eTPhTKUoW+vgRqP8QHs4bNPI/D4cEvVvAWLPJM5Pgvfl4QyQgIEwAQAyNWl0SSnp/fZk0/z9/1gnh2iKuc5ZAQONo5"\n    "ex3TBO+6IRgHWzeX9JwKJybJHSg/QBXAp7siVf0NmEGdq5RKTGnFijgsHXprxtdHYcUs0/Dtaw+jijG4bAeJMmoJshuHdxy67dju"\n    "DBcZu1HNfdLVni1jPnm3qRSV1vgwZ55b7lVfUiZ6KMhB07IQMRElUS8sqKPONSFEhA0KWNPAjehY/SkfwwFLEEHWiJEwVuF2TNeJ"\n    "SZtfYPAgZSK64MON6TKFxog3KxQjtBLvAdvShqvH9fKOfhndqIUEoictEXewZHYAI+eSL4jQ9YFMLnCQv5MsMYTPOEsyYfwg6nwU"\n    "Z7al4uAE1MCk8swto+zbM4JJNp4W8ZxOpf2DBWNGEcgQBwSIIiv2p4rWh+hILp18aYgWzlTpjJTL6Sw7HaFiR4UKT096MZR0AxH6"\n    "JVWKup7PmNmkqiM/4X6ghZoIYsyNVp+KuGcJnLkeelkv1oNrZttqSFoDUJnW3byz+jhK0ipQzZkbK5eZqdEmDXds4nlBQtbTIGtR"\n    "VfARDa5Tt0PSVwPhBhBYzpUsCvNtKCJF6SZX3HvNQelrV/bNJTbLGsoKHZewLEnqEVyCgt1UIEbrZIFvhP6k1KOAiEZibL64hs5u"\n    "u6DuSEmMgEinbRNgn/piV8tYlV8SOM6Xx8kxoKIhnlyeGSStmoVufPXDUDyxjeX5SyRvixyjFR+mzpbJmBLgviJmlxOwtJaEGGzS"\n    "JpD1gVHcNNXfKdZhRXPY71LO/tIkSCMXjcK8uQMIi1h58SZPlcfFMsqQL5oqMbDPiGYkcw0i9dgfOXIYyLeOe/IdyTXmedV6UCKy"\n    "Rbp8hUwp1BB8Q3YzAmBWRtxrY4u0xjPjgx1JwaQK+VWeU4oNg6Go3jeI9RTcVX6S7BiKdB0JWPZZAZyyBM1sizpjV+thMxZ9yHhO"\n    "S54VakIS7Sqh/7HRg6/AAQe43x2VYfRR2YRVSwtiE6mPRwOtSUnXvqJ5UOjUKWhRAWG6bugiNtjY0UGXxo1YEuhI+B/UlofciDQM"\n    "HTcidp2JmKKCOT22UVfMDrL9KKfueFAla8pZRIoqcU2dz1xdGU2jEw8KlYMefM4axfHxIM+K6OOlo7OgGUaNwtNHqBK6/JVYe71X"\n    "iskz0UYrrWnjSE7YrNPqIyF6x1Q9Trz4kPcRnISQJ9Bgsc8sxxp0+Ml7XsfVjBI+6BjlO0gLMk6+HnBVp4wT6j+jWuxi387I5dSn"\n    "LKakqMnMsZnh4RuUE2qngYgnVSOkUtecBBTy0izVGNC+ygWIO1bPKFJuCptloTKFiBPL3OG9tCJ67GNJuawNQowMnUJdUvDNtQTo"\n    "Gr2NCQfpp6jXIhttTG1YXwF3W852nwFb2dx2WiXRIZK4qzFNpqcHMGLQ0hGRnBsxKfaHB7awRtCaFtz7I2e4ugGgrEVn4db6+OFm"\n    "+3wT8RN10oXixJRkrrmWIVa07HFieKOUH1SWdIFQ6dy0Vn94dcoLwreJ7jnojuYdTrMrWiMckQ5uUoiEB51f0azsbfoq9aRP6qu5"\n    "oGTS4oZ08jcBPqVNfNqzIgiyqSHJa1EgQBaNKBK3n5tEdJ/vmOQZuyc56Z7JLF6h2+y+lEiczosqEaPIy+dyhYb4Rurp/Ch2kYYT"\n    "Cmc89vl4sMRjcfTsIEY/irHObteQZHJEk1+7vk1yNVUVQC4Cn+i4so+i1Z5plikcvrmo2PiOMjWj6guN2BSXKtFhbPVa0nvJjkXi"\n    "KpVGW5Gszegu6uhEak9EEVlNAtcRcMkBt5rmzs9WzSXWbnH5KoSAm+1CR2fB1eiAtz341gPGso3O75P1aCw7u+SZ6NywKoTNaCnh"\n    "1Z6hOZ7eFX37JqsGehdt8Yks5Mf4e6US/5LYzc2huB5s55oG5IUuuFi3wkAcK/h9TYBOW7QlLdpLoaFmnxUOvXph4gz0nqaygtxF"\n    "iX3aqw7lPpCrUN2QYKXmPMrLZPKZrOXBO7umpxOcGMmidqqK2JrotlYa6kCERIwXBktQCXS3svR5qruNqdn2Me8sh639sIZOK4Ku"\n    "pEaSmK08Mt6K0spNHI+1RDzOivGj2EBqutA/Bk4774DEitwsXSVA82OtdfYFw/bQNSgrqAbS567QCZhlt9a5yFQWFCLA+jxlqo87"\n    "VBAB1uKxiIEAtEI5PQkHpzuQeCtKbBZUgKmJdfz1fGRtkorvb2TBbva/XZml4ijgeq9B9gZZKrrHjIw27nKMHlxE6MH2ESJYGaMp"\n    "U1rOK6ouJZLKA6ayCabgrPyEU41BAohGZdZ0CqgfPJKDKZ1OcL9SoWbtcSVnU6m86bF0DKETPoJwK6MUjYCdsuKw+QRQVy9dqzJv"\n    "KxS51J039qVANN9bw2JiNZ1Wn+Ro+rOrSNWtv7yzPjiL9slPOOdf7ToQd+TOsLC42vpGBp+eqDGuFVnWGgs6SXFNJ2UPXfk4C9y1"\n    "3DKWgnxFLVOMQAvd7uNkzovh8TML5crPpVWLt5TJv0nXtyrYwAwkzLMM4PWEIJ/6zItLGxrVFIxBpDPSad6tSTmUyyJbzA7czFLM"\n    "nXuFdVCWXRT73V5C2Agkl2qbZh5KCYIZgjDQrFAU2dWX6YXCHRS53Lxmt/ORGWHUUayh9u4atPwhtpkHCaTDTvp4G8osJdKIvRIE"\n    "Vwmcm9b3I6pc0Jla6wh9XH5QeduLHBTh9N+URkHRMh9FuTwAUY4OtutnAE/EOgND2aKmYqqdWwsDx0Jg1RlU0z9uGswYqWhWVE8I"\n    "+8PGBw24AFT4n9OLjaKJXNLFzyzNt+FWl68rVCvT+BaDQiPara8h0j8ZfxbgEcdyqFcOFyh3Br2q8GnFFiVdXvTBpTjFIVLu3Hi8"\n    "76Zg6ydm5f+OzWywkiL0TZ4kAesogfJ6wsp050iXGUhTHdnbCe3kuL9zvBxVIwG0vkKmXelwKl5FIxZf6IPyrIxqvTSoVV5qoh2S"\n    "Tr1mK7hPiZEyroiAjkUv/PEhvAluoWnjElY80HJijOosjtxLax0bZ7NlK+aTZg306tq4KXczKhPomKPS4rpUE5HENPdRgCoj/ktW"\n    "pyssF7AnoCZqb2W0xIGsICk39SK8fYQXBpqj88b9BqRsjCO8QLbN5HjXEIGvytC2vJlt+ElmKqdrUU4uI8rJqcZdNpcfmXOS+xtv"\n    "8/ZWiY5cDh0+p8HkbOdhlG3Bh04k64lWrwDYAwnbEGpJp6tcYBkPVPI4omPelO01pEsMugfJrI3nsO+IU0gixrWRHqDTrkfu4Hv2"\n    "hRh15NVBd3CeMqe9cMms0uwoECXbiRSSBNQkNQKtGu/+6ds3nVbexvpMm3VG6sR4lTMTqaNNV1l6LaHcgzmGB7M2lbtqnaAIl3Hc"\n    "qFGJtymPRIp0xt0ZKeBqktddx24zoCuzEPXMNBdv5tUmMS/mEqwpb6scfZoNOMOSLCl8X3rKZZlTPPgTgczWwSqtSmnYeLRLxorf"\n    "O2uaUCmybriMx2Uh5Ands6b7nFh8Ds9MxuorsueN7SUqQCKhTiz5jmtCp+kee/i1FbaYuCjGQTPMWChmqpvK3V51skcshyoevEob"\n    "Ix5UX6Zk8cUHaJAZyBDPKViS4pi+WOtpzgKBunVDp+RIQSryO75uNtlMtdQEdhNM/5D63zFDDb2G0sPdU8LiVn4RtRaESGcgFI7+"\n    "CqJry7uivr35iBdjp+JqhEoHHjrvP2UVJcRIjAnrJImlM3UH1efZk9dhCgFqMsdloknfnNy2MAn3S1bDY41phpaaMKpCyrfNnN3F"\n    "i9lDMSsMcp9WJX+MS6W1yjelTnZTi5RjQ/LctrLI1939qqJxR8kTvSmTIvYytWu2mXpyhdkd6lVEvYXSJJQj21QlbaCMVoJNPRUV"\n    "ko5C3GxO7sjstdvp5PDa6GXoyDxVyIXUCpFaahRpEPyj52qbTsC9jHGHW7RFDFLKALGEr/VLVBDsYbomXpdIjGGnid9vabTrkOmi"\n    "Un1KBVHX88OZ8IMhEjRqJqeH6DTOgYjMrFXNMf3iajXQIkIv2OiHnGouothj8XuXXkPB8TRMcSXEySNJIKmzrVyHjlPKs5h0jPGE"\n    "051ZGNqcM0eFKDkwaeMm5NXNNx4/Ox4DhdhlncUFa8oQPT8LxXs7FVtmoI7L2/ehPzMysXFh422Z2lYqao99mx7HoGellW5bcXBJ"\n    "7XHRuQZ0iyDWEHtO179zaECjdYjINFVE9itkuS8LhrDd+GVnHMTTm40Dat5uj7fV5e20L5hndRQ5DC6bvayUsdPelew+8ZqFal1m"\n    "QTRn8JNZjlPlX+3/FuePztqxYyXJ/6pmwK2Gz7qkDRWeuVxekwIdN9OUny+SFwmIrL1uhcyrxY6y7UlRfO6Ni14J6iuJLqNQnnN+"\n    "5hJe7njpP24oWprpdYhxUsIL8Jga4tcrxBZ/9ybvqbB9MNHuZVWgojpKgritG16cHKmri3Hmhk/PCgA8Xu73iMNp4pIGX0TU5ULL"\n    "QOKY8sD2er2Zph+gbKPzsNR+4Bih6PTw/IOOU6FzLfGpekke7yngdxTh5hgxzD4Ph7WIryamyyMnJu0hQ3CZCuwQKMqz4WuwPSVt"\n    "vot3ylFL7FKxTZFLOA21GFxA2USNAUSINK5D6qOoBguGre7Z41vlx1PcZsnKkIXo36HSHiHr5fY0LPVmBbTUI6+QkCYCYwVjPi7F"\n    "tEWSy4V3explgl/ipNfm1aVGmVSeONhdf05RxfQY0NlsCyq8oGVHuu3b24IApDb8qNS4d5hHfsjZz8bP+Yd4FSDStwp36nFtPAbb"\n    "lynKMQ7NpZXDujn6eIc8lb0SuYXX0x/YlVZZVxgBox5rra+9gsahF/zNnbo7Gc+kga49sW2hy+KTYbJ/kk0u7pTNmlBBnEtfWIqY"\n    "W119H1QSij85/UA/2cDYSkAyxNrs/udLRZp2lNXPne8z85w3MrJ5RhKe4ARgb0mgsUW9jbVAXTPrpTae11rZfj1LFbGkryGIgdfU"\n    "Lc/YwwG3PnyQ9vbJNc/ZxqLDkhwTmvGLeDKqvcJ5T5Fe/tH3VeIxHDRdHC9am7SCEYGsC4Dp2DbLq2MUsVaGSZKkuKvlcEaqAigB"\n    "ZU0eVbmOcEtlkBBLsRfd9ZBFg3PLYwo2zUk1tDoK5VXTknxt2FZcvp+9ffNlcRLEuhj+2v4LRVZN4vi8m+1qe+uPidKb8Zf2A3cF"\n    "qgd64cNfOBjK/m+OQxknLPodAFYvUCXtkU8cORleVDKg23+8/+U/vfrVq3d/vL64uP7j9bs//vDH79+dfX/3Z//r3V+//8vdr736"\n    "7tvLi+/PTk5OT7bX774939z97N3d908vTl6/+tvff/jhz/9z97fo/WXM5BVSrYWI3sbKsc7Xs2KUGQPJqMkO6sVSOA1f8qwYHkG1"\n    "4kmHnA+yMnlcQuGySfMgFWr3TSYBuXtolETu2ItZPN4RyeyYfYvEpQoJtqbsq1wZE2w2k5g6frRtdaGgQnUUcRdcGnfWiCtkL9Cm"\n    "Fq9ZMCItjZsO3b64RGKFI1rUaqTAY+yEcpmyWC7gOC7e41dzceQ3GNLzYZajW/y8EBHtshTFV04TjduWaUItGSVpAlKCTLigayjy"\n    "j71DsJqp1Q5sBddZxUGiVqmRCSZArn/f7LbOc367GURWR0ATvyRPl2mW03BMOlS+Met9OaRgrrJl8I/iKvZU83KhJEf66zgue6+V"\n    "wKlcTLXgHnnUzfSYKHq3xmOGWPAuQO9r4i8l4gI9FcXELhudwUj3Je0x6sn/kj+pGCvHN2sKfPp3euVGYIyxAryCwj/aSzbY7q0W"\n    "8o+OUFwVIjyZC6oUlxOWgqZeSjS/QhG8o+T4ZBqsIDhQqdJHD4t5iOxvzzWnaugFadwUTJ5GxCNs71uBiS6PCol3jb2fLXVjb+LS"\n    "+VKHd+n2Xm1S+TRl2R/TXLwTnid3MLnxZDaHPvlCy2dAmJ216Yq4hWwNJ0vNriobd5KVl2Z80qdo5bklYLLLC59D+ENxZbA8nCgS"\n    "Z10sycPGcyUNIcMkbECHGhbKOciZJWzBx6x2tsR4syZc0DNFynbduxAZfrfVyunI/Bjxp+hiy7kandZoyx1+fK10JuLqtZCQ05xe"\n    "HuA27tqVi2OIEwrV+/jMquOYiOIUspJWqzwKXViZZCrU6Zyz6rgM+47IWQopCpbFJrUfLYbXml4zIBjP2JaCGjbQ98n0mk1ne1ZO"\n    "NvaAYmNRTnWXy3iMHTdn2Cxz5vY8JDe0K0dY1eZLRbRZ4u4D4BPXTRtBS0FRog5nUxL9hzVxB5Y47xgn1ogdSa9P3k7aQ1apcsY7"\n    "DDGTaiv+tkKKIFwkES+DiIlukWeQ96awhi8hL+ovFbIQQ/GREca2CwWdZid2T7ExidYxVumpO7IKEEmxYuw/B5qlQnxCZwurVS0x"\n    "yzrnkgEJNAURBI3jxWCnBqTt5Su2lRQederpB3LoRlVZS6wF5FaJiF8gTsi6mHspLpZzo4+JbJlXaPdZgLm6zUzCtOhR0szFhtIw"\n    "jo1Y7/DdOaaKYbfFMnvtUF98ssOuqH0gMMLQfqA2wKzwawk01TLWioIaid8rpOIiowhQLK7TcV/I9+K2QHsT5yL2UWom6/KP1UV8"\n    "j4CUkzQwN1NbKiRZDiSLYbV3mu3SMioQdIpNaSe9IOm0NfL3tKGseX7RiIJU1LaF4HNaBUbJOTpzxSDCADjItD3RJzIhiQedpPP1"\n    "PP92RSU0IcyufAl6CIAZVWAiipeg1fmPUelSmXENnTkajAi2M3qHIKBUmwf9ux3FfcZwim+BmGk5dDF1QVds70zxmEwumUUD2kyK"\n    "XVY9RCyQag5+bWxIg6Wghierniz1lMQc6pPkfUoXt72Z59xEYD+pAblomm8qnjtyDHpb+gV5syusNLmuznUKXIg4XJ6btSkf4wHL"\n    "5RL6NErLHXu1S/ZUieBm2OceVKuAIB1uTFvU7aSv6pbKxLSqm2IhFbh7O1MItBu1kEHvpAw7IQdEYvVhRnmHrSuySdWdMl0Sm+8C"\n    "G13w1I64kpLVps5siqVKNA2w1faapaL83zrcso0nt62Dl3Pa3xHr9Gz9iL4AFjYrYsBJv/22FtX6qYfnPe3Q2cbldJadjiOcOf6I"\n    "iSEuhHSW25aiqIjPaWy5NixlKNtNKx8DhTFUNShftltSKoyFEmHkYvRLWBGvsYy1QUGDKmgAy7QuZ9xsAm4OpUFUHW3sJJgaK4vY"\n    "i6tWTGRRuNYZuBkkB52nrV5hfESMrApvANU10DIqLWfCcq6kUZhw38SbKMo3NemBfL/bmgOx+H5CJLKZDKWUNU+SxsWQZUm9On0o"\n    "FDMRidE6WQAcgwQLGShYULDNyNfMERvmJWfvUPYzLNX1qvXBYlfLWBVgEjzO59DlIFBtqSc2dCnIbyMZyeaYxKj9JRLphRIO5ePU"\n    "2TKx1Few9jxqgkHA0loSPimCrfKwO6FhGSvOi8SE2W+S2TXl/1dCaeSiQYeqTJ6PLuGoejOnLxo2J5Knujx9VFzjrBevh3FUcqAm"\n    "RO6tA9/fg79AAt41yYmIJmSLYxy9rrCI4DtfmxEAUotAWsMWZY1nxkc7ao64qz4nWOgkyiDyX0LpmdbbT5ofQ5FuhNqk0Axn/9s6"\n    "NrNlt+vnxGYsApHxnJQOjLCJR02qwf/IvzW1F+EA95uSun4JY5SX2Y9n57YzeBOtKRgEZgFgUOnUKagNRHV0aEy+qStklzO1SpV7"\n    "T3efqoAEMJlSxGkYOm5EbDYQMUUFc3qUGa2QvrP9GGj4GHqSgT3ZJCJFpbj8aRMGX5TIoipew7/VM4Swq+PjQZ5V0cdLx5UA9ik1"\n    "Ck8POnqyKjghNPVSuKPe0Wuc6er6zGv9hehdwbgRUFMkJMxyIVHQwlIHoL7miobBuJrRMRpbn25cCmosXtle1Snl5MbpLsm70CcW"\n    "bGPKYk4Kq6NE4QHKc/RbTRyW1y7vTo5LXRUsklY0KVwRqCGucA3MwGspLW0pbwM8qkIn5A61CufPZYf40orosZMlJbM2GDFagy+S"\n    "1nyETZRtvNkkJps1fLdXVkf5GHBLro5ylhuTmNhJjEU42e4zYCubysmJuoEAmMB3/JuLNSZEiibiWwZSkJ9dJyBXFBcKuhzVkRfs"\n    "jU9mxFTKdBZWR4sfrtl4nCRhSD8P1XMpyVxzLUOsqB3uQxWTKZ+bypIuMCqdm9aSzVvJgJXxtMDeKYq9dnmL0+yK1ghHJO+bFCLh"\n    "QedXtAznVKhYss5s8ofKWiFOmbDADenkb75UECouXOWykwL58XoUCJA9HoOzhsaZzUnG6o5JnrF7kov3wRoRCt1mkSPXzKMdRBGj"\n    "yMvnGjpMpb6Zce8qdlHTIA7Zx6Zq6LLisLmKLBVOa6u+cx26P7StYQLlvddpnUWm2ReJThF1dHiijDvHoF3n144/z1hwHYeM5kz0"\n    "osSlXCLOZOXVcajIjQ5swHoqVeNoHRexccCmQlFGAorIJJPeOPCFQExyaG6kzvxsmS1E3Ih1XlxmC2Hlpc6izXaEWA6/dXRiXBXN"\n    "c9YWj1mED6yJwwISNvelhGx7Ljh4epM8a6H/gfg30OZo61RkyQFG6iuRAZYUcO4jxfWQGf8uUtwSOMY63ZQhYciOtf6+fECng5pk"\n    "h9AqukO7CehJY/TuVRYT7+f3hJYVlDFKPNVeHUn16tqdMD4pzpT+yxHF1HXSYN1vatI7wYmRLGqn/ohNjG4TpiEkRJjFeGGwWpXA"\n    "gStLn6e628KabR/zzrK0jwNPGXIIJuGSHePmewtul1ZWKAKbilMUP1LWkA5NZK7TlABwQuIDkj2/JoktAe4fi/zqDjxwgl6FNAnv"\n    "Lt2ZDssFre+S7NY6F5n0gpIFWMmnTPVxhwrKwFqMFzEQgFYopx//WaHrjhguyvA2hlSw3XX89XxkbTqLmFobZ1Fud+6/XZnPAgCK"\n    "BbckXUQF/ooPsBxDCpsIJjiLTHw+NMvlvKL0UuKtPEAoF6GzU8fzqN0rJBBnlG9Np4BaxB13e8+DZzydHBF9vPZ7w13H7tw1sE3c"\n    "9FJS7CpmR2wxaOuM4xNABb50rSbmSy0i/NjBAtF86YYlPE8Tb/VJPkQCHOqvhwEYyzvrmLMIovyEFSEVApOxUN1SRsMS5GrrG7l+"\n    "eqLGuFZkWWss6CTFBfOSehvIx1ngPHKi9zCGuzh21vVI8VD5vFneSP96UK78XFq1eEuZTJ10fauCDcxAwlHLAF5PMzIymE6XNrS0"\n    "sX0ohH6hj81K5EQ2yK64uznQ826mhsKKKct+i/1uLyFsBJKzdwrnoZQ3mCEIA80KRZH9f5m0KNxBTwmu06UnqHZjJo3eeulQe3cN"\n    "pf+eua9h0tPv+G1ouJRII/ZKsGyKGACZorNULmjASi41InL5QZVwL3KshFEBU0QF5c0ccOXoGLvWJsorYyrEiYNeck99MVXZrYWB"\n    "46r10IakQ7sxuED7rKizEHaSjYd+wAWgwv+csmwUTeTiL35mab4Nt7p8XaFa8VdieUd9ZBztNtbQsPtITjHAI46FU68cLhAG5Q9/"\n    "pnNHKXANPJW4pwyy01o/X7tkP6u0mJX/wwSsvpIi9E2eJAHrKIHyehLMyXEjPWkgU3U0cieElqEZNPZMIDKiJSJdaYeq3UYiWSk0"\n    "TXnGR7XGGxQ2L3XcDnmnXrYV6Kfn1BxsJ2i/GpNnb4J7rshD2wOqCLi5MUq5ONowpahK8aPa+tMl3qwBYF0bl+VuRpIC/XVUZlzX"\n    "dSKemKY/ClxlhIDJGHWF5cKSdNR07S2OlpiQlWblLmCEuo8gw0B2dF6634aUjZFiQYJGDDZqS4Z4srvHVFcBlBLFOppklNOIi3Ku"\n    "kZfN5Ucmo+RmyNu8FXZJR7kMOnouZ2kqMZKyHXsmtwUjO5HCJ1q/AnYPJHBDACYFnfplF3JNIREMGnSqyevtLAH5jqcOESh9R51C"\n    "XjGujfRAnXZNcgff8z/EQCSvGbqD85Q9G/XCMUYw+wxEIbeeVYpLcqxByNgGvR7vnuXtm06Db2N9pi0848SOVzvzkzradpWl1xLa"\n    "PZhjeDBrU7mrtiQZiF21QAzLJ5tAeiziZYyekRiuJrl3TtnZVicK5zyhHnwz6yNtMWOGwZryuMoRqNmWMyzJkkL4pad8llnNg78R"\n    "yHQdrNJUiqOLUrsUrfi9syYKqRbWHZvxuCyEPKH71nT3E4vX4ZnJCH5FNr2xvVDsZtG9QXDeQaXoNN1jD7+2whajXNuE9AslTgWC"\n    "uturTgHBp1yWv6pksmQ6Z+GNlP9RRioGf5vn1CtJMUxf1fU0J4FA2bokU3IdABjbk4EFEiE+ZxOkkON38nBAHwulPOJH29wgKjCx"\n    "YKoItTKCcJx0MPJHiPpa3PYvYtmCvKl/3nuyji0pNzI99xps+OAXY6cqbIRdB+awDapfyNvXwk1YUGG+O94ZzQyAImtdDxWrNS4c"\n    "ccT32lsQ4/hzN8QMrihZGI/lqDXy7Yw1YfZDqMc8Dtzr8GaFcO6zsLjJ1tV9WQWs5cMhj2+XM06hsZVfzm8FXBGQJMvtkdW8l2lf"\n    "rfhHnOysLwfvect8FtdKk4KO/FSV0IGWWglS9XRXSGwKxQicA6cE+MoCyE5njtdG+0NHGarCRxxT+6FpQm4gizehjmz62XM1Wyfg"\n    "X8bTw23a4hIpmQHAbL3fIvninjypiegl0mTYoeLvNThnRVoxpj9KLipVUl3PcmfCcobY0yjLnJ6l01AIgjazbjjrarGG+XrJUYgs"\n    "cS6iSGTxe5deP0I2GSWexSi8repQsj1nqPsDL8XMvPPkaVMTxqFuwjEEcVpApwYrELQED42GkQWqA3s37n1e3R3k8bPjMWCkXtZ3"\n    "xMYVxfU5y05glelA8sO813ETsJr8YqQxQJkwpoir4x3ZqQmn4lfAzZ3uj+M4+Ky0U2yvkaS++LhqXYu9RSRtiFSnG8g5h6BBPASH"\n    "muon+5lfbmwQ2FBhvBc/pYtkZxz33gY241jsfkTlhcrYpxyeImPFZeeal82Cs15UtVak7GSfiuWAVJXMl2nO9SjzYSc6gzoyPCKj"\n    "jj2Nk1wkdWoUXqo4K4fiv/ziBjXlzbvCqONunPJBRtIm4ayrrAhVqVDbBLXtE7h3clGQDKkYYHT1hSKm1tbHqUt4ymOM8bjpCAhP"\n    "L1/a39lGEucWtYb0fJn9DZ68p8K2whA1nVIupgKGIZk2jgxJ020R44erZ7eeeYwR9nwI9JiDLyLidqFh4hCeeDr5ZlU5ULfSeTLq"\n    "tHCcYKKeog85ToUyttS36jwDvIOAtFJEzmPkM/s8HNYivJqYLo+HmXTCDCFnytwgcJdnwxehe8r+fMHolI6XOMtihybXoxpyObiA"\n    "sokaY4MQF12Hv0gBC9Y/W73Dx1fIj0Q3mxAsoxFiuodSgzP2B1Snzip/qSVgISlN9NQKPoRcQGprQpdZA/Y0yri7RLavzatL+jK5"\n    "SHHUuv6comjrMeSz2RZEh0G6jz0BC3qX2t+kUpzfYUL4IWffNn9IUiIweK24zhrg/8PaeAytL1MYYxyay5eHdXP08ZbCf/JK5BZe"\n    "T2hhN2WL4SpAYIxjrfW1V5DHnp1Q8qQ28bxxwp3Ytq5n8ckwjz/PJjffKWtyHXTmvLm2FEBPNTVgaPZY7SfbD/RvNvgOzx1fKd85"\n    "pKeVuf5H5jhuEZcI8kfP6q+KkUoi+UImzK5CVShTgV7SYZVIt0HICOjpk/Ox97UAk4Bq6Xepx9/MU7Mwez3rd6rsRfN8/H9pz3dn"\n    "EN7sUleKbADrgmR6djMAbwVFMb+h3n1FnoYJScbxFLukgOqW8FZEuUtHTlOtBmp3Jxgd5c+wQmji5DnTqlXuLIFLC7idAfWeCH1v"\n    "33zZ1fzB6PL6tsBLH5FeIlRXZkJ8qlQtjj93P0OLL/Dptxs3DcUB7j+S+mwrmcO+/jWEnQ8fdTCM8cOfGFvDnNTyl0EX73Fcp1fd"\n    "1q3jNfD+l//06lev3l2dfXdy8cPmu8323XffXX5792f/691fv//L3a+9ujzZnH/77cnJu29/eHd2vd3e/ezd3ffPLy9fv/rb33/4"\n    "4c//c/e3fjnWBQcOBaMBxMN3bn7zm1Wk915MDF5MDF5MDF5MDDomBqc/GxODxcDPb19cDV5cDV5cDV5cDV5cDV5cDV5cDV5cDV5c"\n    "DT6Gq4GszX5UY4Nqtfhn4G3gaPj/8zocjAjXe2Tl4oOaHZy/mB28mB28mB28mB28mB28mB28mB28mB28mB28mB28mB28mB387M0O"\n    "XrwN/om9DRyO+8f0M5j0tfS/yNPnDVoTvIckrqSBQMm/oGVbkN424ChwnF4zJT1EeDYh7NPIlkp0eXGJxByNgiYoDCuiKBMQnvNr"\n    "6mYENHPlW2wMLRbfKTZvYq8/DyotZGKQ35hHqlzWZzJPRI3K04UV6Ma91mkqM7zlZZzRgL2XMWBC8DeZJLupfsH6Y6gan6k4JwGk"\n    "R1Zn7LOCUoUmhdNsAWK+hSytHB53x4JmpUytPK0oh0ZSnyOtsL0WxuJprvXo1JSONl4CS9UOXm+uYlRbQpPqkvXVv803b2rFxQzL"\n    "Cp1CSK5A1WKkBmFWsCCQdKeGc9dKL204/q4GmzjegleF+9RoAsxxSpxDXSwm/BzfbIUsgMmeJ1WsjSic7L82Xzgh4+ehR8T429G0"\n    "NzueQiWjyBNkaLSwJCgiqWDgz1oZfCHNf1HfX0N9f4ynalSAf1bt/bHEtLb2/vZFe/9Fe/9Fe/+fSnt/86K9/7PR3q/I3a+gxH/9"\n    "i1Di3/yCZfdLDJoPIcL/Ot0NL7r8K+nyN86dF6X+X55Sf2fD/QS1+zP0lVphV9DuT4PTX4iaf6kQv4qa/3Jmz24n9f03L/r+QZJ1"\n    "8QvV/b9+kf1/kf1/kf1/kf1/kf1/kf1/kf1/kf3/mcj+v4j8v4j8v4j8v4j8v4j8R8n86WVN5P9ZeBQBz2D7y1H27/y1TeO0et9z"\n    "sVFiDR/MCKArz0/Mj4InwIruAB/08yPiZhKhKAChcMHMmAUEH2P5G0Sa5eUu0sQ8wIuDGY+ZNQ+IJKUc9f5onuYcBYJXRK3MMEUT"\n    "jgIZkhMNOVDJi4Wz78/FSEfotgLZOa8ndEqI9FfmBOfxLWXU8cJQSOvNeUGGMH5hNIY/gUghqq/s+PtlFqq3cmoOLCTHtcriyf1X"\n    "dAvz86wf+Vkj3LLAdasLZ1dDJhGHT0eAqvx2IfiRvB0naNMWCgJT2H8seAU844jGjxefOvLaxWQZA9pe5T4GQKZP7QvG38HhnG6l"\n    "lv4afga3//j/YDJN7Q=="\n)\n\n\n_ROUTES = None\n\n\ndef routes():\n    """Decode lazily: only MAIN is stored whole, the rest as (parent, turn, suffix)."""\n    global _ROUTES\n    if _ROUTES is None:\n        p = json.loads(zlib.decompress(base64.b64decode(_BLOB)).decode())\n        out = {p["main"]: p["full"]}\n        for t in p["tails"]:\n            out[t["h"]] = out[t["parent"]][:t["at"]] + t["suffix"]\n        _ROUTES = out\n    return _ROUTES\n\n\ndef _shed_adjacent(x, y, board=BOARD):\n    h = board // 2\n    return (x, y) in ((h - 1, h - 1), (h, h - 1), (h - 1, h), (h, h))\n\n\ndef _feature(obs, name):\n    if name == "shop_YARN_STORE":\n        return (obs.get("town", {}).get("unlocked_shops") or []).count("YARN_STORE")\n    if name == "px_CARROT":\n        return obs["market"]["prices"].get("CARROT", 0)\n    if name == "inv_MILK":\n        return obs["market"]["inventory"].get("MILK", 0)\n    return 0\n\n\ndef _noop(act, tile, inv, seeds, x, y, board=BOARD):\n    """True when the engine will certainly ignore this action (kaggriculture.py::\n    _apply_unit_action). Only used to decide whether a turn is free to reuse."""\n    if not act:\n        return True\n    op = act[0]\n    if op in MOVES:\n        dx, dy = MOVES[op]\n        return not (0 <= x + dx < board and 0 <= y + dy < board)\n    if op == "PASS":\n        return True\n    if op == "DROP":\n        return (not _shed_adjacent(x, y, board)) or (not inv)\n    if op == "PICKUP":\n        return not _shed_adjacent(x, y, board)\n    if op == "PLACE":\n        item = act[1] if len(act) > 1 else None\n        if (item in ANIMALS and isinstance(tile, dict)\n                and tile.get("kind") == ANIMALS[item] and tile.get("animal") is None):\n            return inv.get(item, 0) <= 0\n        if _shed_adjacent(x, y, board):\n            return inv.get(item, 0) <= 0\n        return True\n    if tile == "LOCKED":\n        return True\n    isd = isinstance(tile, dict)\n    kind = tile.get("kind") if isd else None\n    animal = isd and tile.get("animal") is not None\n    if op == "PLANT":\n        return tile is not None or seeds.get(act[1] if len(act) > 1 else None, 0) <= 0\n    if op == "WATER":\n        return kind != "PLANT" or bool(tile.get("watered_today"))\n    if op == "HARVEST":\n        return (not isd) or tile.get("yield_units", 0) <= 0\n    if op == "FERTILIZE":\n        return kind != "PLANT" or inv.get("FERTILIZER", 0) <= 0\n    if op == "DIG":\n        return tile is None or animal\n    if op in ("BUILD_COOP", "BUILD_PASTURE"):\n        return tile is not None\n    if op == "FEED":\n        return (not animal) or bool(tile.get("fed_today")) or inv.get("WHEAT", 0) <= 0\n    if op == "COLLECT_FERTILIZER":\n        return (not animal) or (not tile.get("fertilizer_available"))\n    if op == "CARE":\n        return (not animal) or bool(tile.get("cared_today"))\n    return True\n\n\nclass Agent:\n    def __init__(self):\n        self.R = routes()\n        self.cur = MAIN\n        self._fs = None\n        self._fs_for = None\n\n    # ---- how much of each product does the rest of the route still intend to sell? ----\n    def future_sells(self, item, step):\n        if self._fs_for != self.cur:\n            r = self.R[self.cur]\n            fs = dict((p, [0] * (len(r) + 1)) for p in PRODUCTS)\n            for t in range(len(r) - 1, -1, -1):\n                add = {}\n                for o in (r[t].get("market") or []):\n                    if o and o[0] == "SELL" and o[1] in fs:\n                        add[o[1]] = add.get(o[1], 0) + int(o[2])\n                for p in fs:\n                    fs[p][t] = fs[p][t + 1] + add.get(p, 0)\n            self._fs = fs\n            self._fs_for = self.cur\n        a = self._fs.get(item)\n        return a[step] if a and step < len(a) else 0\n\n    def _switch_ok(self, target, turn):\n        """A switch is legal only onto a tail identical to the current one so far."""\n        a, b = self.R[self.cur], self.R[target]\n        if a is b:\n            return False\n        for t in range(turn):\n            if a[t] != b[t]:\n                return False\n        return True\n\n    def act(self, obs):\n        s = obs.get("step")\n        step = int(s) if s is not None else int(obs.get("day", 0)) * 24 + int(obs.get("hour", 0))\n        me = int(obs.get("player", 0))\n        farm = obs["farms"][me]\n        priv = obs["private"]\n        tiles = farm["tiles"]\n        seeds = priv.get("seeds") or {}\n        invs = priv.get("inventories") or []\n        shed = dict(priv.get("shed") or {})\n        prices = obs["market"]["prices"]\n        day = int(obs.get("day", step // 24))\n        board = len(tiles) or BOARD\n\n        for (turn, feat, thr, target) in DECISIONS:\n            if turn == step and target != self.cur and self._switch_ok(target, turn):\n                if _feature(obs, feat) >= thr:\n                    self.cur = target\n\n        route = self.R[self.cur]\n        base = route[step] if step < len(route) else PASS\n        acts = [list(base.get("farmer") or ["PASS"])] + [list(h) for h in (base.get("hands") or [])]\n        market = [list(o) for o in (base.get("market") or [])]\n        positions = [tuple(farm["farmer"])] + [tuple(p) for p in farm["hands"]]\n\n        # ---- weed_dig: a wasted turn spent standing on a weed becomes a DIG ----\n        for i in range(min(len(acts), len(positions))):\n            x, y = positions[i]\n            if not (0 <= x < board and 0 <= y < board):\n                continue\n            tile = tiles[y][x]\n            inv = invs[i] if i < len(invs) else {}\n            if (isinstance(tile, dict) and tile.get("kind") == "WEED"\n                    and _noop(acts[i], tile, inv, seeds, x, y, board)):\n                acts[i] = ["DIG"]\n\n        # ---- projected shed: a same-turn DROP/PLACE lands before market processing ----\n        proj = dict(shed)\n        room = SHED_CAP - sum(proj.values())\n        for i in range(min(len(acts), len(positions))):\n            if room <= 0:\n                break\n            x, y = positions[i]\n            inv = invs[i] if i < len(invs) else {}\n            if not inv or not _shed_adjacent(x, y, board):\n                continue\n            a = acts[i]\n            if a and a[0] == "DROP":\n                for it, n in inv.items():\n                    take = min(n, room)\n                    if take > 0:\n                        proj[it] = proj.get(it, 0) + take\n                        room -= take\n            elif a and a[0] == "PLACE" and len(a) > 1 and a[1] not in ANIMALS:\n                it = a[1]\n                take = min(int(a[2]) if len(a) > 2 else 1, inv.get(it, 0), room)\n                if take > 0:\n                    proj[it] = proj.get(it, 0) + take\n                    room -= take\n\n        # ---- clamp_sells: a SELL the shed cannot fill burns one of only 10 slots ----\n        # SELL draws from the shed alone, and the projection above already credits the\n        # goods a same-turn DROP/PLACE will put there, so this only drops orders that\n        # really cannot fill.\n        avail = dict(proj)\n        kept = []\n        for o in market:\n            if o and o[0] == "SELL":\n                have = avail.get(o[1], 0)\n                if have <= 0:\n                    continue\n                n = min(int(o[2]), have)\n                if n <= 0:\n                    continue\n                avail[o[1]] = have - n\n                kept.append(["SELL", o[1], n])\n            else:\n                kept.append(o)\n        market = kept\n\n        # ---- dead_stock: sell what the rest of the route will never get to ----\n        planned = {}\n        for o in market:\n            if o and o[0] == "SELL":\n                planned[o[1]] = planned.get(o[1], 0) + int(o[2])\n        extra = []\n        for it in PRODUCTS:\n            have = proj.get(it, 0) - planned.get(it, 0)\n            if have <= 0:\n                continue\n            surplus = have if day >= 29 else have - self.future_sells(it, step + 1)\n            if surplus > 0 and prices.get(it, 0) > 1:\n                extra.append(["SELL", it, surplus])\n        extra.sort(key=lambda o: -prices.get(o[1], 0) * int(o[2]))\n\n        return {"farmer": acts[0], "hands": acts[1:],\n                "market": (market + extra)[:MAX_ORDERS]}\n\n\n_A = None\n\n\ndef agent(obs):\n    """A crash here forfeits the game, so any failure degrades to a legal PASS."""\n    global _A\n    try:\n        s = obs.get("step")\n        step = int(s) if s is not None else int(obs.get("day", 0)) * 24 + int(obs.get("hour", 0))\n        if _A is None or step == 0:\n            _A = Agent()\n        return _A.act(obs)\n    except Exception:\n        try:\n            hands = obs["farms"][int(obs.get("player", 0))].get("hands") or []\n        except Exception:\n            hands = []\n        return {"farmer": ["PASS"], "hands": [["PASS"] for _ in hands], "market": []}\n\n'
_PSR_NS = {"__name__": "_psr_embedded"}
exec(compile(_PSR_SOURCE, "_psr_embedded", "exec"), _PSR_NS)
_PSR_STATE = {"agent": None}
_HYBRID_FROM_STEP = 216


def _psr_act(obs):
    step = int(_sweep_get(obs, "step", 0) or 0)
    if step == 0 or _PSR_STATE["agent"] is None:
        _PSR_STATE["agent"] = _PSR_NS["Agent"]()
    return _PSR_STATE["agent"].act(obs)




# ===== E052: 開幕の現金防衛 (PSR 新版 31578b90c3 の荒らし対策) ===========================================
# 31578b90c3 は step4〜13 に「小麦 29 買い→即売り」を毎手打ち、v56 ボディの「小麦 1 売り/1 買い」往復を
# 高値買い・安値売りにして d0 の現金を $24→$4 まで削る。加えて自分はメロン種 12 個を一括せず植え付け
# 直前に 1〜2 個ずつ買って $900 の余裕を持つ。この $40〜100 の差で s89 の牛が買えず C3S8 に崩壊 (実戦 6/6)。
# (A) d0 の 1 個往復を除去 (在庫は不変)。(B) メロン種を植え付け (route idx 4,6,7,9,9,12,12,13,15,15,16,19) の
#     1 手前に分散購入 (市場は農場処理の後なので前の手に買う)。
_OPEN_CHURN_GUARD = True
_OPEN_MELON_DEFER = False
_OPEN_MELON_BUYS = {3: 1, 5: 1, 6: 1, 8: 2, 11: 2, 12: 1, 14: 2, 15: 1, 18: 1}  # obs.step -> qty (計 12)


def _open_guard(act, obs):
    step = int(_sweep_get(obs, "step", 0) or 0)
    if step > 18:
        return act
    market = [list(o) for o in (act.get("market") or [])]
    if _OPEN_CHURN_GUARD and 2 <= step <= 10:
        market = [o for o in market if not (len(o) >= 3 and o[1] == "WHEAT" and int(o[2]) == 1 and o[0] in ("SELL", "BUY_PRODUCT"))]
    if _OPEN_MELON_DEFER:
        if step == 1:
            market = [o for o in market if not (len(o) >= 3 and o[0] == "BUY_SEED" and o[1] == "MELON")]
        q = _OPEN_MELON_BUYS.get(step)
        if q:
            market = [["BUY_SEED", "MELON", q]] + market
    act["market"] = market[:10]
    return act




def agent_entry(obs, configuration=None):
    """kaggle_environments はファイル内で最後に定義された callable をエージェントとして使う
    (dict 挿入順。`agent` の再定義は位置を変えないため、E022c 以降は `_pre_orak_agent`
    = オラクル抜きの層が本番で動いていた)。最後に新しい名前で定義して全層を通す。"""
    act = agent(obs, configuration)
    try:
        act = _open_guard(dict(act), obs)
    except Exception:
        pass
    try:
        psr_act = _psr_act(obs)
        step = int(_sweep_get(obs, "step", 0) or 0)
        if step >= _HYBRID_FROM_STEP and not _v56_use_yarn(obs):
            return _sells_first(dict(psr_act))
    except Exception:
        pass
    try:
        act = _feed_g(dict(act), obs)
        act = _carrot_swap(dict(act), obs)
        act = _carrot_seeds(act, obs)
        act = _eager_sell(dict(act), obs)
        return _sells_first(act)
    except Exception:
        return act

